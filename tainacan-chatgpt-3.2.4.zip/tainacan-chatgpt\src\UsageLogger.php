<?php
namespace Tainacan\ChatGPT;

/**
 * Logger de uso e estatísticas
 *
 * Registra todas as análises realizadas para acompanhamento
 * de uso, custos e auditoria.
 */
class UsageLogger {

    private string $table_name;
    private static bool $table_checked = false;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'tainacan_chatgpt_logs';
    }

    /**
     * Registra uma entrada de log
     */
    public function log(array $data): bool {
        $options = \Tainacan_ChatGPT::get_options();

        // Verifica se log está habilitado (padrão: true se não definido)
        // Usa array_key_exists para distinguir entre false e não definido
        if (array_key_exists('log_enabled', $options) && !$options['log_enabled']) {
            return true;
        }

        // Garante que a tabela existe
        $this->maybe_create_table();

        global $wpdb;

        $defaults = [
            'user_id' => get_current_user_id(),
            'item_id' => null,
            'collection_id' => null,
            'attachment_id' => 0,
            'document_type' => 'unknown',
            'model' => 'gpt-4o',
            'provider' => 'openai',
            'tokens_used' => 0,
            'cost' => 0,
            'status' => 'success',
            'error_message' => null,
            'created_at' => current_time('mysql'),
        ];

        $data = wp_parse_args($data, $defaults);

        // Garante que provider está definido
        if (empty($data['provider'])) {
            $data['provider'] = $this->detect_provider_from_model($data['model']);
        }

        $result = $wpdb->insert(
            $this->table_name,
            $data,
            ['%d', '%d', '%d', '%d', '%s', '%s', '%s', '%d', '%f', '%s', '%s', '%s']
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            if ($result === false) {
                error_log('[TainacanChatGPT] Failed to insert log: ' . $wpdb->last_error);
                error_log('[TainacanChatGPT] Table: ' . $this->table_name);
                error_log('[TainacanChatGPT] Data: ' . print_r($data, true));
            } else {
                error_log('[TainacanChatGPT] Log recorded successfully. Tokens: ' . ($data['tokens_used'] ?? 0));
            }
        }

        return $result !== false;
    }

    /**
     * Cria tabela de logs se não existir
     */
    private function maybe_create_table(): void {
        if (self::$table_checked) {
            return;
        }

        global $wpdb;

        $table_exists = $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $this->table_name)
        );

        if (!$table_exists) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[TainacanChatGPT] Creating logs table: ' . $this->table_name);
            }

            $charset_collate = $wpdb->get_charset_collate();

            $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                user_id bigint(20) unsigned NOT NULL,
                item_id bigint(20) unsigned DEFAULT NULL,
                collection_id bigint(20) unsigned DEFAULT NULL,
                attachment_id bigint(20) unsigned NOT NULL,
                document_type varchar(50) NOT NULL,
                model varchar(50) NOT NULL,
                provider varchar(50) NOT NULL DEFAULT 'openai',
                tokens_used int(11) DEFAULT 0,
                cost decimal(10,6) DEFAULT 0,
                status varchar(20) NOT NULL DEFAULT 'success',
                error_message text DEFAULT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY user_id (user_id),
                KEY item_id (item_id),
                KEY collection_id (collection_id),
                KEY provider (provider),
                KEY created_at (created_at)
            ) $charset_collate;";

            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);

            // Verifica se a tabela foi criada
            $table_created = $wpdb->get_var(
                $wpdb->prepare("SHOW TABLES LIKE %s", $this->table_name)
            );

            if (defined('WP_DEBUG') && WP_DEBUG) {
                if ($table_created) {
                    error_log('[TainacanChatGPT] Logs table created successfully');
                } else {
                    error_log('[TainacanChatGPT] Failed to create logs table. Last error: ' . $wpdb->last_error);
                }
            }
        }

        // Verifica se precisa adicionar coluna provider (migração)
        $this->maybe_add_provider_column();

        self::$table_checked = true;
    }

    /**
     * Obtém estatísticas gerais
     */
    public function get_stats(string $period = 'month'): array {
        global $wpdb;

        $date_condition = $this->get_date_condition($period);

        // Total de análises
        $total = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE status = 'success' {$date_condition}"
        );

        // Total de tokens
        $tokens = $wpdb->get_var(
            "SELECT SUM(tokens_used) FROM {$this->table_name} WHERE status = 'success' {$date_condition}"
        );

        // Custo total
        $cost = $wpdb->get_var(
            "SELECT SUM(cost) FROM {$this->table_name} WHERE status = 'success' {$date_condition}"
        );

        // Erros
        $errors = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE status = 'error' {$date_condition}"
        );

        // Por tipo de documento
        $by_type = $wpdb->get_results(
            "SELECT document_type, COUNT(*) as count
            FROM {$this->table_name}
            WHERE status = 'success' {$date_condition}
            GROUP BY document_type",
            ARRAY_A
        );

        // Por modelo
        $by_model = $wpdb->get_results(
            "SELECT model, COUNT(*) as count, SUM(tokens_used) as tokens, SUM(cost) as cost
            FROM {$this->table_name}
            WHERE status = 'success' {$date_condition}
            GROUP BY model",
            ARRAY_A
        );

        // Por provedor
        $by_provider = $wpdb->get_results(
            "SELECT provider, COUNT(*) as count, SUM(tokens_used) as tokens, SUM(cost) as cost
            FROM {$this->table_name}
            WHERE status = 'success' {$date_condition}
            GROUP BY provider",
            ARRAY_A
        );

        // Por coleção
        $by_collection = $wpdb->get_results(
            "SELECT collection_id, COUNT(*) as count
            FROM {$this->table_name}
            WHERE status = 'success' AND collection_id IS NOT NULL {$date_condition}
            GROUP BY collection_id
            ORDER BY count DESC
            LIMIT 10",
            ARRAY_A
        );

        // Usuários ativos
        $active_users = $wpdb->get_var(
            "SELECT COUNT(DISTINCT user_id) FROM {$this->table_name} WHERE status = 'success' {$date_condition}"
        );

        return [
            'total_analyses' => (int) $total,
            'total_tokens' => (int) $tokens,
            'total_cost' => (float) $cost,
            'total_errors' => (int) $errors,
            'success_rate' => $total > 0 ? round(($total / ($total + $errors)) * 100, 1) : 0,
            'by_type' => $this->format_by_type($by_type),
            'by_model' => $by_model,
            'by_provider' => $this->format_by_provider($by_provider),
            'by_collection' => $this->format_by_collection($by_collection),
            'active_users' => (int) $active_users,
            'avg_tokens_per_analysis' => $total > 0 ? round($tokens / $total) : 0,
            'avg_cost_per_analysis' => $total > 0 ? round($cost / $total, 6) : 0,
        ];
    }

    /**
     * Obtém histórico de uso
     */
    public function get_history(int $limit = 50, int $offset = 0, array $filters = []): array {
        global $wpdb;

        $where = ['1=1'];
        $params = [];

        if (!empty($filters['user_id'])) {
            $where[] = 'user_id = %d';
            $params[] = $filters['user_id'];
        }

        if (!empty($filters['collection_id'])) {
            $where[] = 'collection_id = %d';
            $params[] = $filters['collection_id'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'status = %s';
            $params[] = $filters['status'];
        }

        if (!empty($filters['document_type'])) {
            $where[] = 'document_type = %s';
            $params[] = $filters['document_type'];
        }

        if (!empty($filters['date_from'])) {
            $where[] = 'created_at >= %s';
            $params[] = $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $where[] = 'created_at <= %s';
            $params[] = $filters['date_to'];
        }

        $where_clause = implode(' AND ', $where);

        $query = "SELECT * FROM {$this->table_name}
                  WHERE {$where_clause}
                  ORDER BY created_at DESC
                  LIMIT %d OFFSET %d";

        $params[] = $limit;
        $params[] = $offset;

        $results = $wpdb->get_results(
            $wpdb->prepare($query, $params),
            ARRAY_A
        );

        // Adiciona informações extras
        foreach ($results as &$row) {
            $row['user_name'] = $this->get_user_name($row['user_id']);
            $row['collection_name'] = $this->get_collection_name($row['collection_id']);
            $row['item_title'] = $this->get_item_title($row['item_id']);
        }

        return $results;
    }

    /**
     * Obtém total de registros (para paginação)
     */
    public function get_total(array $filters = []): int {
        global $wpdb;

        $where = ['1=1'];
        $params = [];

        if (!empty($filters['user_id'])) {
            $where[] = 'user_id = %d';
            $params[] = $filters['user_id'];
        }

        if (!empty($filters['collection_id'])) {
            $where[] = 'collection_id = %d';
            $params[] = $filters['collection_id'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'status = %s';
            $params[] = $filters['status'];
        }

        $where_clause = implode(' AND ', $where);

        if (empty($params)) {
            return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE {$where_clause}");
        }

        return (int) $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$this->table_name} WHERE {$where_clause}", $params)
        );
    }

    /**
     * Obtém uso por dia (para gráficos)
     */
    public function get_daily_usage(int $days = 30): array {
        global $wpdb;

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(created_at) as date,
                        COUNT(*) as analyses,
                        SUM(tokens_used) as tokens,
                        SUM(cost) as cost
                 FROM {$this->table_name}
                 WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
                       AND status = 'success'
                 GROUP BY DATE(created_at)
                 ORDER BY date ASC",
                $days
            ),
            ARRAY_A
        );

        return $results;
    }

    /**
     * Limpa logs antigos
     */
    public function cleanup(int $days_to_keep = 90): int {
        global $wpdb;

        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table_name}
                 WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
                $days_to_keep
            )
        );
    }

    /**
     * Exporta logs para CSV
     */
    public function export_csv(array $filters = []): string {
        $logs = $this->get_history(10000, 0, $filters);

        $csv = "ID,Data,Usuário,Coleção,Item,Tipo,Modelo,Tokens,Custo,Status,Erro\n";

        foreach ($logs as $log) {
            $csv .= sprintf(
                "%d,%s,%s,%s,%s,%s,%s,%d,%.6f,%s,%s\n",
                $log['id'],
                $log['created_at'],
                $log['user_name'],
                $log['collection_name'] ?? '-',
                $log['item_title'] ?? '-',
                $log['document_type'],
                $log['model'],
                $log['tokens_used'],
                $log['cost'],
                $log['status'],
                str_replace(["\n", "\r", ","], [" ", " ", ";"], $log['error_message'] ?? '')
            );
        }

        return $csv;
    }

    /**
     * Condição SQL para período
     */
    private function get_date_condition(string $period): string {
        switch ($period) {
            case 'today':
                return "AND DATE(created_at) = CURDATE()";
            case 'week':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case 'month':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            case 'year':
                return "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
            case 'all':
            default:
                return "";
        }
    }

    /**
     * Formata dados por tipo
     */
    private function format_by_type(array $data): array {
        $formatted = [];
        $labels = [
            'image' => __('Imagens', 'tainacan-chatgpt'),
            'pdf' => __('PDFs', 'tainacan-chatgpt'),
            'text' => __('Textos', 'tainacan-chatgpt'),
            'unknown' => __('Outros', 'tainacan-chatgpt'),
        ];

        foreach ($data as $row) {
            $formatted[] = [
                'type' => $row['document_type'],
                'label' => $labels[$row['document_type']] ?? $row['document_type'],
                'count' => (int) $row['count'],
            ];
        }

        return $formatted;
    }

    /**
     * Formata dados por provedor
     */
    private function format_by_provider(array $data): array {
        $formatted = [];
        $labels = [
            'openai' => 'OpenAI (ChatGPT)',
            'gemini' => 'Google Gemini',
            'deepseek' => 'DeepSeek',
            'ollama' => 'Ollama (Local)',
        ];

        foreach ($data as $row) {
            $provider = $row['provider'] ?? 'openai';
            $formatted[] = [
                'provider' => $provider,
                'label' => $labels[$provider] ?? $provider,
                'count' => (int) $row['count'],
                'tokens' => (int) ($row['tokens'] ?? 0),
                'cost' => (float) ($row['cost'] ?? 0),
            ];
        }

        return $formatted;
    }

    /**
     * Formata dados por coleção
     */
    private function format_by_collection(array $data): array {
        foreach ($data as &$row) {
            $row['name'] = $this->get_collection_name($row['collection_id']);
            $row['count'] = (int) $row['count'];
        }

        return $data;
    }

    /**
     * Obtém nome do usuário
     */
    private function get_user_name(int $user_id): string {
        $user = get_userdata($user_id);
        return $user ? $user->display_name : __('Usuário desconhecido', 'tainacan-chatgpt');
    }

    /**
     * Obtém nome da coleção
     */
    private function get_collection_name(?int $collection_id): ?string {
        if (!$collection_id || !class_exists('\Tainacan\Repositories\Collections')) {
            return null;
        }

        $collections_repo = \Tainacan\Repositories\Collections::get_instance();
        $collection = $collections_repo->fetch($collection_id);

        return $collection ? $collection->get_name() : null;
    }

    /**
     * Obtém título do item
     */
    private function get_item_title(?int $item_id): ?string {
        if (!$item_id) {
            return null;
        }

        return get_the_title($item_id) ?: null;
    }

    /**
     * Detecta provedor a partir do nome do modelo
     */
    private function detect_provider_from_model(string $model): string {
        if (strpos($model, 'gpt') !== false) {
            return 'openai';
        }
        if (strpos($model, 'gemini') !== false) {
            return 'gemini';
        }
        if (strpos($model, 'deepseek') !== false) {
            return 'deepseek';
        }
        // Modelos comuns do Ollama
        $ollama_models = ['llama', 'mistral', 'mixtral', 'phi', 'gemma', 'qwen', 'codellama', 'vicuna', 'llava', 'bakllava', 'moondream'];
        foreach ($ollama_models as $ollama_model) {
            if (strpos($model, $ollama_model) !== false) {
                return 'ollama';
            }
        }
        return 'openai';
    }

    /**
     * Verifica e adiciona coluna provider se não existir
     */
    public function maybe_add_provider_column(): void {
        global $wpdb;

        $column_exists = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM {$this->table_name} LIKE %s",
                'provider'
            )
        );

        if (empty($column_exists)) {
            $wpdb->query(
                "ALTER TABLE {$this->table_name} ADD COLUMN provider varchar(50) NOT NULL DEFAULT 'openai' AFTER model"
            );

            // Atualiza registros existentes
            $wpdb->query("UPDATE {$this->table_name} SET provider = 'openai' WHERE model LIKE '%gpt%'");
            $wpdb->query("UPDATE {$this->table_name} SET provider = 'gemini' WHERE model LIKE '%gemini%'");
            $wpdb->query("UPDATE {$this->table_name} SET provider = 'deepseek' WHERE model LIKE '%deepseek%'");
            $wpdb->query("UPDATE {$this->table_name} SET provider = 'ollama' WHERE model LIKE '%llama%' OR model LIKE '%mistral%' OR model LIKE '%phi%' OR model LIKE '%gemma%' OR model LIKE '%qwen%'");

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[TainacanChatGPT] Added provider column to logs table');
            }
        }
    }
}
