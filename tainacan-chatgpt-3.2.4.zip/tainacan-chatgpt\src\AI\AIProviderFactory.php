<?php
namespace Tainacan\ChatGPT\AI;

use Tainacan\ChatGPT\AI\Providers\OpenAIProvider;
use Tainacan\ChatGPT\AI\Providers\GeminiProvider;
use Tainacan\ChatGPT\AI\Providers\DeepSeekProvider;
use Tainacan\ChatGPT\AI\Providers\OllamaProvider;

/**
 * Factory para criação de provedores de IA
 *
 * Gerencia a criação e configuração dos provedores de IA disponíveis.
 *
 * @package Tainacan_ChatGPT
 * @since 3.2.0
 */
class AIProviderFactory {

    /**
     * Provedores registrados
     */
    private static array $providers = [];

    /**
     * Registra os provedores padrão
     */
    public static function init(): void {
        self::register('openai', OpenAIProvider::class);
        self::register('gemini', GeminiProvider::class);
        self::register('deepseek', DeepSeekProvider::class);
        self::register('ollama', OllamaProvider::class);

        // Permite que outros plugins registrem provedores
        do_action('tainacan_chatgpt_register_providers');
    }

    /**
     * Registra um novo provedor
     */
    public static function register(string $id, string $class): void {
        if (!is_subclass_of($class, AIProviderInterface::class)) {
            throw new \InvalidArgumentException(
                sprintf('Provider class %s must implement AIProviderInterface', $class)
            );
        }
        self::$providers[$id] = $class;
    }

    /**
     * Cria uma instância do provedor
     */
    public static function create(string $provider_id, array $options = []): ?AIProviderInterface {
        if (empty(self::$providers)) {
            self::init();
        }

        if (!isset(self::$providers[$provider_id])) {
            return null;
        }

        $class = self::$providers[$provider_id];
        $provider = new $class();
        $provider->configure($options);

        return $provider;
    }

    /**
     * Cria o provedor configurado nas opções do plugin
     */
    public static function create_from_options(): ?AIProviderInterface {
        $options = \Tainacan_ChatGPT::get_options();
        $provider_id = $options['ai_provider'] ?? 'openai';

        // Monta as opções para o provedor
        $provider_options = [
            'api_key' => self::get_api_key_for_provider($provider_id, $options),
            'model' => self::get_model_for_provider($provider_id, $options),
            'max_tokens' => $options['max_tokens'] ?? 2000,
            'temperature' => $options['temperature'] ?? 0.1,
            'timeout' => $options['request_timeout'] ?? 120,
        ];

        return self::create($provider_id, $provider_options);
    }

    /**
     * Obtém a chave API para o provedor
     */
    private static function get_api_key_for_provider(string $provider_id, array $options): string {
        $key_map = [
            'openai' => 'api_key',
            'gemini' => 'gemini_api_key',
            'deepseek' => 'deepseek_api_key',
            'ollama' => 'ollama_url',
        ];

        $key_name = $key_map[$provider_id] ?? 'api_key';
        return $options[$key_name] ?? '';
    }

    /**
     * Obtém o modelo para o provedor
     */
    private static function get_model_for_provider(string $provider_id, array $options): string {
        $model_map = [
            'openai' => 'model',
            'gemini' => 'gemini_model',
            'deepseek' => 'deepseek_model',
            'ollama' => 'ollama_model',
        ];

        $model_key = $model_map[$provider_id] ?? 'model';
        return $options[$model_key] ?? '';
    }

    /**
     * Retorna lista de provedores disponíveis
     */
    public static function get_available_providers(): array {
        if (empty(self::$providers)) {
            self::init();
        }

        $available = [];

        foreach (self::$providers as $id => $class) {
            $provider = new $class();
            $available[$id] = [
                'id' => $id,
                'name' => $provider->get_name(),
                'models' => $provider->get_available_models(),
                'default_model' => $provider->get_default_model(),
                'supports_vision' => $provider->supports_vision(),
            ];
        }

        return $available;
    }

    /**
     * Retorna informações de um provedor específico
     */
    public static function get_provider_info(string $provider_id): ?array {
        $providers = self::get_available_providers();
        return $providers[$provider_id] ?? null;
    }

    /**
     * Verifica se um provedor existe
     */
    public static function provider_exists(string $provider_id): bool {
        if (empty(self::$providers)) {
            self::init();
        }

        return isset(self::$providers[$provider_id]);
    }

    /**
     * Testa conexão com um provedor
     */
    public static function test_provider(string $provider_id, string $api_key, string $model = ''): array {
        $provider = self::create($provider_id, [
            'api_key' => $api_key,
            'model' => $model,
        ]);

        if (!$provider) {
            return [
                'success' => false,
                'message' => __('Provedor não encontrado.', 'tainacan-chatgpt'),
            ];
        }

        return $provider->test_connection();
    }
}
