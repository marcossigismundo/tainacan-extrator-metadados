<?php
/**
 * Plugin Name: Tainacan ChatGPT
 * Plugin URI: https://github.com/tainacan/tainacan-chatgpt
 * Description: Extração automatizada de metadados no Tainacan utilizando IA (OpenAI, Gemini, DeepSeek). Suporta análise de imagens, documentos PDF, extração EXIF e prompts personalizados por coleção.
 * Version: 3.2.4
 * Author: Sigismundo
 * Author URI: https://seu-site.com
 * Text Domain: tainacan-chatgpt
 * Domain Path: /languages
 * License: GPL v2 or later
 * Requires Plugins: tainacan
 * Requires at least: 6.5
 * Tested up to: 6.7
 * Requires PHP: 8.0
 *
 * @package Tainacan_ChatGPT
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define constantes do plugin
define('TAINACAN_CHATGPT_VERSION', '3.2.4');
define('TAINACAN_CHATGPT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TAINACAN_CHATGPT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TAINACAN_CHATGPT_DOMAIN', 'tainacan-chatgpt');
define('TAINACAN_CHATGPT_DB_VERSION', '1.0.0');

/**
 * Autoloader do plugin
 */
spl_autoload_register(function ($class) {
    $prefix = 'Tainacan\\ChatGPT\\';
    $base_dir = TAINACAN_CHATGPT_PLUGIN_DIR . 'src/';
    $lib_dir = TAINACAN_CHATGPT_PLUGIN_DIR . 'lib/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);

    // Primeiro tenta no diretório src/
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($file)) {
        require $file;
        return;
    }

    // Depois tenta no diretório lib/ (bibliotecas embutidas)
    $file = $lib_dir . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($file)) {
        require $file;
        return;
    }
});

// Carrega autoloader do Composer se existir
if (file_exists(TAINACAN_CHATGPT_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once TAINACAN_CHATGPT_PLUGIN_DIR . 'vendor/autoload.php';
}

/**
 * Classe principal do plugin
 */
final class Tainacan_ChatGPT {

    private static ?Tainacan_ChatGPT $instance = null;

    /**
     * Singleton
     */
    public static function get_instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Construtor
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Inicializa hooks
     */
    private function init_hooks(): void {
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);

        add_action('plugins_loaded', [$this, 'load_textdomain']);
        add_action('plugins_loaded', [$this, 'init'], 20);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_settings_link']);

        // Integração com WP Consent API
        $this->init_consent_api();
    }

    /**
     * Ativação do plugin
     */
    public function activate(): void {
        if (version_compare(PHP_VERSION, '8.0', '<')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                __('Tainacan ChatGPT requer PHP 8.0 ou superior.', 'tainacan-chatgpt'),
                __('Erro de Ativação', 'tainacan-chatgpt'),
                ['back_link' => true]
            );
        }

        $this->create_tables();
        $this->set_default_options();

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Desativação do plugin
     */
    public function deactivate(): void {
        global $wpdb;

        // Limpa transients
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_tainacan_chatgpt_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_tainacan_chatgpt_%'");

        flush_rewrite_rules();
    }

    /**
     * Cria tabelas do plugin
     */
    private function create_tables(): void {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Tabela de logs de uso
        $table_logs = $wpdb->prefix . 'tainacan_chatgpt_logs';
        $sql_logs = "CREATE TABLE IF NOT EXISTS $table_logs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            item_id bigint(20) unsigned DEFAULT NULL,
            collection_id bigint(20) unsigned DEFAULT NULL,
            attachment_id bigint(20) unsigned NOT NULL,
            document_type varchar(50) NOT NULL,
            model varchar(50) NOT NULL,
            tokens_used int(11) DEFAULT 0,
            cost decimal(10,6) DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'success',
            error_message text DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY item_id (item_id),
            KEY collection_id (collection_id),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Tabela de prompts por coleção
        $table_prompts = $wpdb->prefix . 'tainacan_chatgpt_collection_prompts';
        $sql_prompts = "CREATE TABLE IF NOT EXISTS $table_prompts (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            collection_id bigint(20) unsigned NOT NULL,
            prompt_type varchar(20) NOT NULL DEFAULT 'image',
            prompt_text text NOT NULL,
            metadata_mapping text DEFAULT NULL,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY collection_prompt (collection_id, prompt_type),
            KEY is_active (is_active)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_logs);
        dbDelta($sql_prompts);

        update_option('tainacan_chatgpt_db_version', TAINACAN_CHATGPT_DB_VERSION);
    }

    /**
     * Define opções padrão
     */
    private function set_default_options(): void {
        $default_options = [
            // Provedor de IA
            'ai_provider' => 'openai',

            // OpenAI
            'api_key' => '',
            'model' => 'gpt-4o',

            // Google Gemini
            'gemini_api_key' => '',
            'gemini_model' => 'gemini-1.5-pro',

            // DeepSeek
            'deepseek_api_key' => '',
            'deepseek_model' => 'deepseek-chat',

            // Ollama (Local)
            'ollama_url' => 'http://localhost:11434',
            'ollama_model' => 'llama3.2',

            // Configurações gerais
            'default_image_prompt' => $this->get_default_image_prompt(),
            'default_document_prompt' => $this->get_default_document_prompt(),
            'max_tokens' => 2000,
            'temperature' => 0.1,
            'request_timeout' => 120,
            'cache_duration' => 3600,
            'extract_exif' => true,
            'auto_map_metadata' => false,
            'consent_required' => true,
            'log_enabled' => true,
            'cost_tracking' => true,
        ];

        $existing = get_option('tainacan_chatgpt_options', []);
        update_option('tainacan_chatgpt_options', wp_parse_args($existing, $default_options));
    }

    /**
     * Prompt padrão para imagens
     */
    private function get_default_image_prompt(): string {
        return <<<PROMPT
Você é um especialista em catalogação museológica e arquivística. Analise esta imagem e extraia metadados detalhados.

## Instruções:
1. Analise cuidadosamente todos os elementos visuais
2. Identifique técnicas artísticas, materiais e estilos
3. Estime períodos históricos quando possível
4. Descreva o estado de conservação visível
5. Para CADA campo, inclua a evidência de onde a informação foi extraída

## Retorne um JSON com os seguintes campos (cada campo deve ter "valor" e "evidencia"):
{
    "titulo": {
        "valor": "Título descritivo da obra/objeto",
        "evidencia": "Descrição de qual elemento visual ou texto levou a esta conclusão"
    },
    "autor": {
        "valor": "Nome do autor/criador (ou 'Desconhecido')",
        "evidencia": "Assinatura visível, estilo característico, ou 'Não identificado na imagem'"
    },
    "data_criacao": {
        "valor": "Data ou período estimado",
        "evidencia": "Elementos que indicam a época (estilo, materiais, técnica, inscrições)"
    },
    "tecnica": {
        "valor": "Técnica(s) utilizada(s)",
        "evidencia": "Características visuais que identificam a técnica"
    },
    "materiais": {
        "valor": ["lista", "de", "materiais"],
        "evidencia": "Texturas, cores e características que indicam os materiais"
    },
    "dimensoes_estimadas": {
        "valor": "Dimensões aproximadas",
        "evidencia": "Elementos de referência usados para estimar (objetos conhecidos, proporções)"
    },
    "estado_conservacao": {
        "valor": "Bom/Regular/Ruim - descrição",
        "evidencia": "Sinais visíveis de desgaste, danos ou boa preservação"
    },
    "descricao": {
        "valor": "Descrição visual detalhada",
        "evidencia": "Elementos principais observados na imagem"
    },
    "estilo_artistico": {
        "valor": "Estilo ou movimento artístico",
        "evidencia": "Características formais que indicam o estilo"
    },
    "palavras_chave": {
        "valor": ["palavras", "chave", "relevantes"],
        "evidencia": "Temas e elementos principais identificados"
    },
    "observacoes": {
        "valor": "Outras observações relevantes",
        "evidencia": "Detalhes adicionais notados"
    }
}

Responda APENAS com o JSON, sem texto adicional.
PROMPT;
    }

    /**
     * Prompt padrão para documentos
     */
    private function get_default_document_prompt(): string {
        return <<<PROMPT
Você é um especialista em análise documental e bibliográfica. Analise este documento e extraia metadados estruturados.

## Instruções:
1. Identifique o tipo de documento (artigo, relatório, tese, etc.)
2. Extraia informações bibliográficas completas
3. Identifique temas e áreas de conhecimento
4. Resuma o conteúdo principal
5. Para CADA campo, inclua a evidência de onde a informação foi extraída (página, seção, trecho do texto)

## Retorne um JSON com os seguintes campos (cada campo deve ter "valor" e "evidencia"):
{
    "titulo": {
        "valor": "Título do documento",
        "evidencia": "Local onde o título foi encontrado (capa, cabeçalho, página X)"
    },
    "autor": {
        "valor": ["Nome dos autores"],
        "evidencia": "Local onde os autores foram identificados (capa, página X, seção de autoria)"
    },
    "tipo_documento": {
        "valor": "Artigo/Relatório/Tese/Livro/etc",
        "evidencia": "Elementos que indicam o tipo (estrutura, formatação, declarações explícitas)"
    },
    "ano_publicacao": {
        "valor": "Ano",
        "evidencia": "Local onde a data foi encontrada"
    },
    "instituicao": {
        "valor": "Instituição relacionada",
        "evidencia": "Menções à instituição no documento"
    },
    "resumo": {
        "valor": "Resumo do conteúdo (máx. 500 caracteres)",
        "evidencia": "Seções principais que fundamentam o resumo"
    },
    "palavras_chave": {
        "valor": ["palavras", "chave"],
        "evidencia": "Seção de palavras-chave ou temas recorrentes identificados"
    },
    "area_conhecimento": {
        "valor": "Área principal",
        "evidencia": "Indicadores da área (terminologia, metodologia, referências)"
    },
    "idioma": {
        "valor": "Idioma do documento",
        "evidencia": "Idioma identificado no texto"
    },
    "referencias_principais": {
        "valor": ["Referências importantes citadas"],
        "evidencia": "Seção de referências ou citações no texto"
    },
    "metodologia": {
        "valor": "Metodologia utilizada (se aplicável)",
        "evidencia": "Seção de metodologia ou descrição dos métodos"
    },
    "observacoes": {
        "valor": "Outras observações",
        "evidencia": "Elementos adicionais notados no documento"
    }
}

Responda APENAS com o JSON, sem texto adicional.
PROMPT;
    }

    /**
     * Integração com WP Consent API
     */
    private function init_consent_api(): void {
        // Registra plugin na Consent API
        $plugin = plugin_basename(__FILE__);
        add_filter("wp_consent_api_registered_{$plugin}", '__return_true');

        // Registra informações de cookies/dados
        add_action('wp_enqueue_scripts', function() {
            if (function_exists('wp_add_cookie_info')) {
                wp_add_cookie_info(
                    'tainacan_chatgpt_cache',
                    __('Cache de análises IA', 'tainacan-chatgpt'),
                    'functional',
                    __('Armazena resultados de análises para evitar chamadas repetidas à API', 'tainacan-chatgpt'),
                    false,
                    false,
                    false
                );
            }
        });
    }

    /**
     * Verifica consentimento do usuário
     */
    public static function has_consent(): bool {
        $options = get_option('tainacan_chatgpt_options', []);

        // Se consentimento não é requerido, retorna true
        if (empty($options['consent_required'])) {
            return true;
        }

        // Verifica via WP Consent API
        if (function_exists('wp_has_consent')) {
            return wp_has_consent('functional');
        }

        // Fallback: sempre permite para admins
        return current_user_can('manage_options');
    }

    /**
     * Carrega traduções
     */
    public function load_textdomain(): void {
        load_plugin_textdomain(
            'tainacan-chatgpt',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages/'
        );
    }

    /**
     * Inicializa componentes do plugin
     */
    public function init(): void {
        // Verifica se Tainacan está ativo
        if (!class_exists('\Tainacan\Repositories\Items')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>';
                echo esc_html__('Tainacan ChatGPT requer o plugin Tainacan ativo.', 'tainacan-chatgpt');
                echo '</p></div>';
            });
            return;
        }

        // Inicializa página administrativa
        if (class_exists('\Tainacan\Pages')) {
            \Tainacan\ChatGPT\AdminPage::get_instance();
        }

        // Inicializa componentes
        new \Tainacan\ChatGPT\API();
        new \Tainacan\ChatGPT\ItemFormHook();

        // Inicializa gerenciador de prompts por coleção
        new \Tainacan\ChatGPT\CollectionPrompts();
    }

    /**
     * Link de configurações
     */
    public function add_settings_link(array $links): array {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            admin_url('admin.php?page=tainacan_chatgpt'),
            __('Configurações', 'tainacan-chatgpt')
        );
        array_unshift($links, $settings_link);
        return $links;
    }

    /**
     * Obtém opções do plugin
     */
    public static function get_options(): array {
        return get_option('tainacan_chatgpt_options', []);
    }

    /**
     * Obtém uma opção específica
     */
    public static function get_option(string $key, mixed $default = null): mixed {
        $options = self::get_options();
        return $options[$key] ?? $default;
    }
}

// Inicializa o plugin
Tainacan_ChatGPT::get_instance();
