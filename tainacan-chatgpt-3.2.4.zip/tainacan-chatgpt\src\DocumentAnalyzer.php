<?php
namespace Tainacan\ChatGPT;

use Tainacan\ChatGPT\AI\AIProviderFactory;
use Tainacan\ChatGPT\AI\AIProviderInterface;
use Tainacan\ChatGPT\PdfParser\PdfParser;
use Tainacan\ChatGPT\PdfParser\PdfToImage;

/**
 * Analisador de documentos usando múltiplos provedores de IA
 *
 * Analisa imagens e documentos extraindo metadados via IA.
 * Suporta OpenAI, Google Gemini e DeepSeek.
 *
 * @since 3.2.0 - Suporte a múltiplos provedores de IA
 */
class DocumentAnalyzer {

    private array $options;
    private ?int $collection_id = null;
    private ?int $item_id = null;
    private ExifExtractor $exif_extractor;
    private CollectionPrompts $collection_prompts;
    private UsageLogger $logger;
    private ?AIProviderInterface $provider = null;

    /**
     * Tipos MIME suportados
     */
    private array $supported_image_types = [
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
    ];

    private array $supported_document_types = [
        'application/pdf',
        'text/plain',
        'text/html',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ];

    public function __construct() {
        $this->options = \Tainacan_ChatGPT::get_options();
        $this->exif_extractor = new ExifExtractor();
        $this->collection_prompts = new CollectionPrompts();
        $this->logger = new UsageLogger();
    }

    /**
     * Define contexto da análise
     */
    public function set_context(?int $collection_id = null, ?int $item_id = null): self {
        $this->collection_id = $collection_id;
        $this->item_id = $item_id;
        return $this;
    }

    /**
     * Obtém o provedor de IA configurado
     */
    private function get_provider(): ?AIProviderInterface {
        if ($this->provider === null) {
            $this->provider = AIProviderFactory::create_from_options();
        }
        return $this->provider;
    }

    /**
     * Analisa um anexo
     */
    public function analyze(int $attachment_id, bool $include_exif = true): array|\WP_Error {
        // Obtém provedor
        $provider = $this->get_provider();

        if (!$provider) {
            return new \WP_Error(
                'no_provider',
                __('Nenhum provedor de IA configurado. Acesse Tainacan > Extrator IA para configurar.', 'tainacan-chatgpt')
            );
        }

        if (!$provider->is_configured()) {
            return new \WP_Error(
                'no_api_key',
                sprintf(
                    __('Chave API do %s não configurada. Acesse Tainacan > Extrator IA para configurar.', 'tainacan-chatgpt'),
                    $provider->get_name()
                )
            );
        }

        // Verifica consentimento
        if (!\Tainacan_ChatGPT::has_consent()) {
            return new \WP_Error('no_consent', __('Consentimento necessário para usar funcionalidades de IA.', 'tainacan-chatgpt'));
        }

        $file_path = get_attached_file($attachment_id);
        $mime_type = get_post_mime_type($attachment_id);

        if (!$file_path) {
            return new \WP_Error(
                'file_not_found',
                __('Caminho do arquivo não encontrado no WordPress. O anexo pode ter sido removido.', 'tainacan-chatgpt')
            );
        }

        // Normaliza o caminho do arquivo (corrige problemas de barras e _x_)
        $file_path = $this->normalize_file_path($file_path);

        if (!file_exists($file_path)) {
            return new \WP_Error(
                'file_not_found',
                sprintf(
                    __('O arquivo físico não existe no servidor. Esperado em: %s', 'tainacan-chatgpt'),
                    $file_path
                )
            );
        }

        // Detecta coleção se não foi definida
        if (!$this->collection_id && $this->item_id) {
            $this->collection_id = $this->get_item_collection($this->item_id);
        }

        $result = [];
        $document_type = 'unknown';
        $extraction_method = null;

        // Análise baseada no tipo
        if (in_array($mime_type, $this->supported_image_types)) {
            $document_type = 'image';

            // Extrai EXIF primeiro
            if ($include_exif && ($this->options['extract_exif'] ?? true)) {
                $exif_data = $this->exif_extractor->extract($file_path);
                if (!empty($exif_data['data'])) {
                    $result['exif'] = $exif_data['data'];
                    $result['exif_summary'] = $this->exif_extractor->get_summary($exif_data);
                }
            }

            // Análise com IA
            $ai_result = $this->analyze_image($attachment_id, $file_path, $mime_type);
            $extraction_method = 'vision';

        } elseif ($mime_type === 'application/pdf') {
            $document_type = 'pdf';
            $pdf_result = $this->analyze_pdf_smart($file_path);
            $ai_result = $pdf_result['result'];
            $extraction_method = $pdf_result['method'];

        } elseif (in_array($mime_type, ['text/plain', 'text/html'])) {
            $document_type = 'text';
            $ai_result = $this->analyze_text(file_get_contents($file_path));
            $extraction_method = 'text';

        } else {
            return new \WP_Error(
                'unsupported_type',
                sprintf(__('Tipo de arquivo não suportado: %s', 'tainacan-chatgpt'), $mime_type)
            );
        }

        // Verifica erro na análise IA
        if (is_wp_error($ai_result)) {
            $this->log_analysis($attachment_id, $document_type, 'error', $ai_result->get_error_message());
            return $ai_result;
        }

        // Combina resultados
        $result['ai_metadata'] = $ai_result['metadata'] ?? $ai_result;
        $result['document_type'] = $document_type;
        $result['extraction_method'] = $extraction_method;
        $result['tokens_used'] = $ai_result['usage']['total_tokens'] ?? 0;
        $result['model'] = $ai_result['model'] ?? '';
        $result['provider'] = $ai_result['provider'] ?? $provider->get_id();
        $result['analyzed_at'] = current_time('mysql');

        // Log de sucesso
        $cost = $provider->calculate_cost($ai_result['usage'] ?? [], $result['model']);
        $this->log_analysis($attachment_id, $document_type, 'success', null, $result['tokens_used'], $cost, $result['model']);

        return $result;
    }

    /**
     * Registra análise no log
     */
    private function log_analysis(
        int $attachment_id,
        string $document_type,
        string $status,
        ?string $error_message = null,
        int $tokens_used = 0,
        float $cost = 0,
        string $model = ''
    ): void {
        $provider = $this->get_provider();

        $this->logger->log([
            'user_id' => get_current_user_id(),
            'item_id' => $this->item_id,
            'collection_id' => $this->collection_id,
            'attachment_id' => $attachment_id,
            'document_type' => $document_type,
            'model' => $model ?: ($provider ? $provider->get_default_model() : 'unknown'),
            'provider' => $provider ? $provider->get_id() : 'openai',
            'tokens_used' => $tokens_used,
            'cost' => $cost,
            'status' => $status,
            'error_message' => $error_message,
        ]);
    }

    /**
     * Análise inteligente de PDF com múltiplos fallbacks
     */
    private function analyze_pdf_smart(string $file_path): array {
        $provider = $this->get_provider();

        // Método 1: Extração de texto (mais rápido e barato)
        $text = $this->extract_pdf_text($file_path);

        if (!is_wp_error($text) && !empty(trim($text)) && strlen(trim($text)) > 100) {
            $result = $this->analyze_text($text);
            return [
                'result' => $result,
                'method' => 'text_extraction',
            ];
        }

        // Método 2: Conversão para imagem e análise visual (se provedor suporta)
        if ($provider && $provider->supports_vision()) {
            $visual_result = $this->analyze_pdf_visually($file_path);

            if (!is_wp_error($visual_result)) {
                return [
                    'result' => $visual_result,
                    'method' => 'visual_analysis',
                ];
            }
        }

        // Se ambos falharam, retorna erro mais informativo
        $error_msg = __('Não foi possível analisar o PDF. ', 'tainacan-chatgpt');

        if (is_wp_error($text)) {
            $error_msg .= $text->get_error_message() . ' ';
        } else {
            $error_msg .= __('O PDF não contém texto extraível. ', 'tainacan-chatgpt');
        }

        if ($provider && !$provider->supports_vision()) {
            $error_msg .= sprintf(
                __('O provedor %s não suporta análise visual de imagens.', 'tainacan-chatgpt'),
                $provider->get_name()
            );
        }

        return [
            'result' => new \WP_Error('pdf_analysis_failed', trim($error_msg)),
            'method' => 'failed',
        ];
    }

    /**
     * Analisa PDF visualmente (para PDFs escaneados)
     */
    private function analyze_pdf_visually(string $file_path): array|\WP_Error {
        $provider = $this->get_provider();

        if (!$provider || !$provider->supports_vision()) {
            return new \WP_Error(
                'vision_not_supported',
                __('O provedor atual não suporta análise visual.', 'tainacan-chatgpt')
            );
        }

        try {
            $converter = new PdfToImage();
            $converter->setDpi(150)
                      ->setQuality(85)
                      ->setMaxPages(3);

            $images = $converter->convert($file_path);

            if (empty($images)) {
                return new \WP_Error(
                    'conversion_failed',
                    __('Não foi possível converter o PDF para imagem. Instale Imagick ou Ghostscript.', 'tainacan-chatgpt')
                );
            }

            // Obtém prompt
            $prompt = $this->get_prompt('document');

            if (empty($prompt)) {
                return new \WP_Error('no_prompt', __('Nenhum prompt configurado para análise de documentos.', 'tainacan-chatgpt'));
            }

            $pageCount = count($images);
            $promptWithContext = $prompt . "\n\n" . sprintf(
                __('O documento tem %d página(s). Analise o conteúdo visual de todas as páginas fornecidas.', 'tainacan-chatgpt'),
                $pageCount
            );

            // Prepara imagens para o provedor
            $image_data = [];
            foreach ($images as $image) {
                $image_data[] = [
                    'data' => "data:{$image['mime']};base64,{$image['base64']}",
                    'mime' => $image['mime'],
                ];
            }

            $result = $provider->analyze_images($image_data, $promptWithContext);

            // Limpa arquivos temporários
            foreach ($images as $image) {
                if (isset($image['path']) && file_exists($image['path'])) {
                    @unlink($image['path']);
                }
            }

            return $result;

        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[TainacanChatGPT] Visual analysis error: ' . $e->getMessage());
            }
            return new \WP_Error('visual_analysis_error', $e->getMessage());
        }
    }

    /**
     * Analisa imagem
     */
    private function analyze_image(int $attachment_id, string $file_path, string $mime_type): array|\WP_Error {
        $provider = $this->get_provider();

        if (!$provider) {
            return new \WP_Error('no_provider', __('Provedor de IA não configurado.', 'tainacan-chatgpt'));
        }

        if (!$provider->supports_vision()) {
            return new \WP_Error(
                'vision_not_supported',
                sprintf(
                    __('O provedor %s não suporta análise de imagens. Use extração de texto ou escolha outro provedor.', 'tainacan-chatgpt'),
                    $provider->get_name()
                )
            );
        }

        // Sempre usa base64 para garantir que a API consiga acessar a imagem
        // URLs locais (localhost, 127.0.0.1, IPs privados) não são acessíveis pelas APIs externas
        $image_url = wp_get_attachment_url($attachment_id);
        $image_data = null;
        $use_base64 = true;

        // Verifica se é uma URL pública acessível (não localhost/local)
        if ($image_url && $this->is_public_url($image_url) && $this->is_url_accessible($image_url)) {
            $use_base64 = false;
            $image_data = $image_url;
        }

        if ($use_base64) {
            $image_content = @file_get_contents($file_path);

            if ($image_content === false) {
                return new \WP_Error('file_read_error', __('Não foi possível ler o arquivo de imagem.', 'tainacan-chatgpt'));
            }

            $base64 = base64_encode($image_content);

            if (empty($base64)) {
                return new \WP_Error('base64_error', __('Erro ao codificar imagem em base64.', 'tainacan-chatgpt'));
            }

            $image_data = "data:{$mime_type};base64,{$base64}";

            // Debug: Tamanho do base64
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $base64_size = strlen($base64);
                $mb_size = round($base64_size / 1024 / 1024, 2);
                error_log("[TainacanChatGPT] Base64 size: {$base64_size} bytes ({$mb_size} MB)");
            }
        }

        // Obtém prompt
        $prompt = $this->get_prompt('image');

        if (empty($prompt)) {
            return new \WP_Error('no_prompt', __('Nenhum prompt configurado para análise de imagens.', 'tainacan-chatgpt'));
        }

        // Debug: Log do prompt
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("[TainacanChatGPT] Image prompt length: " . strlen($prompt));
        }

        return $provider->analyze_image($image_data, $prompt);
    }

    /**
     * Analisa texto
     */
    private function analyze_text(string $text): array|\WP_Error {
        $provider = $this->get_provider();

        if (!$provider) {
            return new \WP_Error('no_provider', __('Provedor de IA não configurado.', 'tainacan-chatgpt'));
        }

        // Sanitiza o texto para UTF-8 válido
        $text = $this->sanitize_utf8_string($text);

        // Limita tamanho do texto
        $max_chars = 32000;
        if (mb_strlen($text, 'UTF-8') > $max_chars) {
            $text = mb_substr($text, 0, $max_chars, 'UTF-8');
            $text .= "\n\n[Documento truncado devido ao tamanho]";
        }

        // Obtém prompt
        $prompt = $this->get_prompt('document');

        if (empty($prompt)) {
            return new \WP_Error('no_prompt', __('Nenhum prompt configurado para análise de documentos.', 'tainacan-chatgpt'));
        }

        return $provider->analyze_text($text, $prompt);
    }

    /**
     * Obtém prompt (customizado ou padrão)
     *
     * Verifica primeiro se há mapeamento de campos customizado na admin,
     * e gera um prompt dinâmico baseado nesses campos para que a IA
     * retorne exatamente os campos mapeados.
     */
    private function get_prompt(string $type): string {
        // Primeiro, verifica se há mapeamento customizado salvo na admin
        if ($this->collection_id) {
            $custom_mapping = get_option('tainacan_chatgpt_mapping_' . $this->collection_id, []);

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[TainacanChatGPT] get_prompt: collection_id={$this->collection_id}, type={$type}");
                error_log("[TainacanChatGPT] Custom mapping found: " . (empty($custom_mapping) ? 'NO' : 'YES - ' . count($custom_mapping) . ' fields'));
            }

            if (!empty($custom_mapping)) {
                $prompt = $this->generate_prompt_from_mapping($custom_mapping, $type);
                if (!empty($prompt)) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log("[TainacanChatGPT] Using dynamic prompt from mapping. Length: " . strlen($prompt));
                    }
                    return $prompt;
                }
            }

            // Se não há mapeamento customizado, tenta prompt da coleção
            $prompt = $this->collection_prompts->get_effective_prompt($this->collection_id, $type);
            if (!empty($prompt)) {
                return $prompt;
            }
        }

        $key = $type === 'image' ? 'default_image_prompt' : 'default_document_prompt';
        return $this->options[$key] ?? '';
    }

    /**
     * Gera prompt dinâmico baseado no mapeamento de campos
     *
     * Cria um prompt que instrui a IA a retornar JSON com exatamente
     * os campos definidos no mapeamento, usando as chaves corretas.
     */
    private function generate_prompt_from_mapping(array $mapping, string $type): string {
        if (empty($mapping)) {
            return '';
        }

        // Monta lista de campos esperados
        $fields_list = [];
        $json_example = [];

        foreach ($mapping as $ai_field => $data) {
            if (!empty($data['metadata_id'])) {
                $field_name = $data['metadata_name'] ?? $ai_field;
                $fields_list[] = "- **{$ai_field}**: {$field_name}";
                $json_example[$ai_field] = "valor para {$field_name}";
            }
        }

        if (empty($fields_list)) {
            return '';
        }

        $fields_text = implode("\n", $fields_list);
        $json_text = json_encode($json_example, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        if ($type === 'image') {
            return <<<PROMPT
Você é um especialista em análise e catalogação de imagens de acervos culturais. Analise esta imagem cuidadosamente e extraia informações para os campos especificados abaixo.

## Campos para Extrair:
{$fields_text}

## Instruções:
1. Analise a imagem detalhadamente
2. Extraia informações relevantes para CADA campo listado
3. Se não conseguir identificar um campo, use null
4. Para campos com múltiplos valores, use array
5. Seja preciso e objetivo

## Formato de Resposta:
Retorne APENAS um JSON válido com esta estrutura (use EXATAMENTE estas chaves):
{$json_text}

IMPORTANTE: Use EXATAMENTE as chaves mostradas acima (como "titulo", "autor", etc.). Responda SOMENTE com o JSON, sem texto adicional.
PROMPT;
        } else {
            return <<<PROMPT
Você é um especialista em análise documental e catalogação. Analise este documento e extraia informações para os campos especificados abaixo.

## Campos para Extrair:
{$fields_text}

## Instruções:
1. Leia o documento completamente
2. Extraia informações para CADA campo listado
3. Se não encontrar informação para um campo, use null
4. Para campos com múltiplos valores, use array
5. Seja preciso nas citações

## Formato de Resposta:
Retorne APENAS um JSON válido com esta estrutura (use EXATAMENTE estas chaves):
{$json_text}

IMPORTANTE: Use EXATAMENTE as chaves mostradas acima (como "titulo", "autor", etc.). Responda SOMENTE com o JSON, sem texto adicional.
PROMPT;
        }
    }

    /**
     * Extrai texto de PDF usando múltiplos métodos
     */
    private function extract_pdf_text(string $file_path): string|\WP_Error {
        // Método 1: Parser embutido do plugin
        try {
            $parser = new PdfParser();
            $text = $parser->parseFile($file_path)->getText();

            if (!empty(trim($text))) {
                return $text;
            }
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[TainacanChatGPT] PdfParser error: ' . $e->getMessage());
            }
        }

        // Método 2: smalot/pdfparser (se instalado via Composer)
        if (class_exists('\Smalot\PdfParser\Parser')) {
            try {
                $parser = new \Smalot\PdfParser\Parser();
                $pdf = $parser->parseFile($file_path);
                $text = $pdf->getText();

                if (!empty(trim($text))) {
                    return $text;
                }
            } catch (\Throwable $e) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('[TainacanChatGPT] Smalot PdfParser error: ' . $e->getMessage());
                }
            }
        }

        // Método 3: pdftotext (poppler-utils) - Linux/Mac
        if (function_exists('shell_exec') && !$this->is_windows()) {
            $escaped_path = escapeshellarg($file_path);
            $output = @shell_exec("pdftotext {$escaped_path} - 2>/dev/null");

            if (!empty($output)) {
                return $output;
            }
        }

        // Método 4: pdftotext no Windows
        if ($this->is_windows() && function_exists('shell_exec')) {
            $escaped_path = escapeshellarg($file_path);
            $paths = [
                'pdftotext',
                'C:\\Program Files\\poppler\\bin\\pdftotext.exe',
                'C:\\poppler\\bin\\pdftotext.exe',
            ];

            foreach ($paths as $pdftotext) {
                $output = @shell_exec("\"{$pdftotext}\" {$escaped_path} - 2>nul");
                if (!empty($output)) {
                    return $output;
                }
            }
        }

        // Método 5: Extração básica via regex
        $text = $this->basic_pdf_text_extract($file_path);
        if (!empty(trim($text))) {
            return $text;
        }

        return new \WP_Error(
            'pdf_extract_failed',
            __('Não foi possível extrair texto do PDF. O documento pode ser uma imagem escaneada.', 'tainacan-chatgpt')
        );
    }

    /**
     * Extração básica de texto de PDF
     */
    private function basic_pdf_text_extract(string $file_path): string {
        $content = file_get_contents($file_path);
        $text = '';

        if (preg_match_all('/stream\s*\n(.*?)\nendstream/s', $content, $matches)) {
            foreach ($matches[1] as $stream) {
                $decoded = @gzuncompress($stream);
                if ($decoded === false) {
                    $decoded = @gzinflate($stream);
                }
                if ($decoded === false) {
                    $decoded = $stream;
                }

                if (preg_match_all('/\((.*?)\)/', $decoded, $text_matches)) {
                    $text .= implode(' ', $text_matches[1]) . ' ';
                }
            }
        }

        return trim($text);
    }

    /**
     * Verifica se URL é acessível
     */
    private function is_url_accessible(string $url): bool {
        $response = wp_remote_head($url, ['timeout' => 5]);

        if (is_wp_error($response)) {
            return false;
        }

        return wp_remote_retrieve_response_code($response) === 200;
    }

    /**
     * Verifica se é uma URL pública (não localhost/local)
     */
    private function is_public_url(string $url): bool {
        $parsed = parse_url($url);

        if (!$parsed || empty($parsed['host'])) {
            return false;
        }

        $host = strtolower($parsed['host']);

        // Lista de hosts locais que APIs externas não conseguem acessar
        $local_hosts = [
            'localhost',
            '127.0.0.1',
            '::1',
            '0.0.0.0',
        ];

        if (in_array($host, $local_hosts)) {
            return false;
        }

        // Verifica IPs privados (RFC 1918)
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            // 10.0.0.0 - 10.255.255.255
            if (preg_match('/^10\./', $host)) {
                return false;
            }
            // 172.16.0.0 - 172.31.255.255
            if (preg_match('/^172\.(1[6-9]|2[0-9]|3[0-1])\./', $host)) {
                return false;
            }
            // 192.168.0.0 - 192.168.255.255
            if (preg_match('/^192\.168\./', $host)) {
                return false;
            }
        }

        // Verifica domínios locais comuns
        $local_domains = ['.local', '.localhost', '.test', '.example', '.invalid', '.lan'];
        foreach ($local_domains as $domain) {
            if (str_ends_with($host, $domain)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Verifica se é Windows
     */
    private function is_windows(): bool {
        return strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
    }

    /**
     * Obtém coleção de um item
     */
    private function get_item_collection(int $item_id): ?int {
        if (!class_exists('\Tainacan\Repositories\Items')) {
            return null;
        }

        $items_repo = \Tainacan\Repositories\Items::get_instance();
        $item = $items_repo->fetch($item_id);

        if ($item && method_exists($item, 'get_collection_id')) {
            return $item->get_collection_id();
        }

        return null;
    }

    /**
     * Sanitiza uma string para UTF-8 válido
     */
    private function sanitize_utf8_string(string $string): string {
        if (mb_check_encoding($string, 'UTF-8')) {
            $string = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $string);
            return $string;
        }

        $encodings = ['ISO-8859-1', 'Windows-1252', 'ASCII'];

        foreach ($encodings as $encoding) {
            $converted = @mb_convert_encoding($string, 'UTF-8', $encoding);
            if ($converted !== false && mb_check_encoding($converted, 'UTF-8')) {
                return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $converted);
            }
        }

        $string = mb_convert_encoding($string, 'UTF-8', 'UTF-8');
        $string = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $string);
        $string = preg_replace('/[\x80-\xFF](?![\x80-\xBF])|(?<![\xC0-\xFF])[\x80-\xBF]/', '', $string);

        return $string;
    }

    /**
     * Normaliza caminho de arquivo para funcionar em Windows e Linux
     */
    private function normalize_file_path(string $file_path): string {
        $file_path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $file_path);

        if (file_exists($file_path)) {
            return $file_path;
        }

        $fixed_path = preg_replace('/([\/\\\\])_x_(\d+)([\/\\\\])/', '$1$2$3', $file_path);

        if ($fixed_path !== $file_path && file_exists($fixed_path)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[TainacanChatGPT] Fixed file path from: {$file_path} to: {$fixed_path}");
            }
            return $fixed_path;
        }

        if (DIRECTORY_SEPARATOR === '\\') {
            $alt_path = str_replace('/', '\\', $file_path);
            if (file_exists($alt_path)) {
                return $alt_path;
            }

            $alt_fixed = str_replace('/', '\\', $fixed_path);
            if (file_exists($alt_fixed)) {
                return $alt_fixed;
            }
        }

        if (DIRECTORY_SEPARATOR === '/') {
            $alt_path = str_replace('\\', '/', $file_path);
            if (file_exists($alt_path)) {
                return $alt_path;
            }

            $alt_fixed = str_replace('\\', '/', $fixed_path);
            if (file_exists($alt_fixed)) {
                return $alt_fixed;
            }
        }

        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'];

        if (preg_match('/tainacan-items[\/\\\\](\d+)[\/\\\\](?:_x_)?(\d+)[\/\\\\](.+)$/', $file_path, $matches)) {
            $collection_id = $matches[1];
            $item_id = $matches[2];
            $file_name = $matches[3];

            $correct_path = $base_dir . DIRECTORY_SEPARATOR . 'tainacan-items' . DIRECTORY_SEPARATOR .
                           $collection_id . DIRECTORY_SEPARATOR . $item_id . DIRECTORY_SEPARATOR . $file_name;

            if (file_exists($correct_path)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("[TainacanChatGPT] Found file at corrected path: {$correct_path}");
                }
                return $correct_path;
            }
        }

        return $file_path;
    }

    /**
     * Obtém tipos de arquivo suportados
     */
    public function get_supported_types(): array {
        return [
            'images' => $this->supported_image_types,
            'documents' => $this->supported_document_types,
        ];
    }

    /**
     * Verifica se tipo é suportado
     */
    public function is_supported(string $mime_type): bool {
        return in_array($mime_type, array_merge($this->supported_image_types, $this->supported_document_types));
    }

    /**
     * Verifica capacidades disponíveis
     */
    public static function get_capabilities(): array {
        $capabilities = [
            'text_extraction' => [
                'name' => __('Extração de Texto', 'tainacan-chatgpt'),
                'available' => true,
                'methods' => ['built_in_parser'],
            ],
            'visual_analysis' => [
                'name' => __('Análise Visual (PDF)', 'tainacan-chatgpt'),
                'available' => false,
                'methods' => [],
            ],
            'exif_extraction' => [
                'name' => __('Extração EXIF', 'tainacan-chatgpt'),
                'available' => function_exists('exif_read_data'),
            ],
        ];

        $backends = PdfToImage::getAvailableBackends();

        if (!empty($backends['imagick']['available']) && !empty($backends['imagick']['supports_pdf'])) {
            $capabilities['visual_analysis']['available'] = true;
            $capabilities['visual_analysis']['methods'][] = 'imagick';
        }

        if (!empty($backends['ghostscript']['available'])) {
            $capabilities['visual_analysis']['available'] = true;
            $capabilities['visual_analysis']['methods'][] = 'ghostscript';
        }

        if (class_exists('\Smalot\PdfParser\Parser')) {
            $capabilities['text_extraction']['methods'][] = 'smalot_pdfparser';
        }

        if (function_exists('shell_exec')) {
            $output = @shell_exec('pdftotext -v 2>&1');
            if ($output && stripos($output, 'pdftotext') !== false) {
                $capabilities['text_extraction']['methods'][] = 'pdftotext';
            }
        }

        return $capabilities;
    }
}
