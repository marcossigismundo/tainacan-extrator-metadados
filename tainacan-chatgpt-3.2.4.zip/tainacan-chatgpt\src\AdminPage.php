<?php
namespace Tainacan\ChatGPT;

/**
 * Página administrativa do plugin usando Tainacan Pages API (1.0+)
 */
class AdminPage extends \Tainacan\Pages {
    use \Tainacan\Traits\Singleton_Instance;

    /**
     * Slug da página
     */
    protected function get_page_slug(): string {
        return 'tainacan_chatgpt';
    }

    /**
     * Inicialização
     */
    public function init() {
        parent::init();

        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_ajax_tainacan_chatgpt_test_api', [$this, 'ajax_test_api']);
        add_action('wp_ajax_tainacan_chatgpt_clear_cache', [$this, 'ajax_clear_cache']);
        add_action('wp_ajax_tainacan_chatgpt_get_stats', [$this, 'ajax_get_stats']);
        add_action('wp_ajax_tainacan_chatgpt_export_logs', [$this, 'ajax_export_logs']);
        add_action('wp_ajax_tainacan_chatgpt_get_collection_metadata', [$this, 'ajax_get_collection_metadata']);
        add_action('wp_ajax_tainacan_chatgpt_save_mapping', [$this, 'ajax_save_mapping']);
        add_action('wp_ajax_tainacan_chatgpt_get_mapping', [$this, 'ajax_get_mapping']);
        add_action('wp_ajax_tainacan_chatgpt_auto_detect_mapping', [$this, 'ajax_auto_detect_mapping']);
    }

    /**
     * Registra menu administrativo
     */
    public function add_admin_menu() {
        $page_suffix = add_submenu_page(
            $this->tainacan_root_menu_slug,
            __('Extrator IA', 'tainacan-chatgpt'),
            '<span class="icon">' . $this->get_chatgpt_icon() . '</span>' .
            '<span class="menu-text">' . __('Extrator IA', 'tainacan-chatgpt') . '</span>',
            'manage_options',
            $this->get_page_slug(),
            [$this, 'render_page'],
            10
        );

        add_action('load-' . $page_suffix, [$this, 'load_page']);
    }

    /**
     * Ícone SVG personalizado
     */
    private function get_chatgpt_icon(): string {
        return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
            <path d="M22.282 9.821a5.985 5.985 0 0 0-.516-4.91 6.046 6.046 0 0 0-6.51-2.9A6.065 6.065 0 0 0 4.981 4.18a5.985 5.985 0 0 0-3.998 2.9 6.046 6.046 0 0 0 .743 7.097 5.98 5.98 0 0 0 .51 4.911 6.051 6.051 0 0 0 6.515 2.9A5.985 5.985 0 0 0 13.26 24a6.056 6.056 0 0 0 5.772-4.206 5.99 5.99 0 0 0 3.997-2.9 6.056 6.056 0 0 0-.747-7.073zM13.26 22.43a4.476 4.476 0 0 1-2.876-1.04l.141-.081 4.779-2.758a.795.795 0 0 0 .392-.681v-6.737l2.02 1.168a.071.071 0 0 1 .038.052v5.583a4.504 4.504 0 0 1-4.494 4.494z"/>
        </svg>';
    }

    /**
     * Carrega CSS
     */
    public function admin_enqueue_css() {
        wp_enqueue_style(
            'tainacan-chatgpt-admin',
            TAINACAN_CHATGPT_PLUGIN_URL . 'assets/css/admin.css',
            [],
            TAINACAN_CHATGPT_VERSION
        );
    }

    /**
     * Carrega JavaScript
     */
    public function admin_enqueue_js() {
        wp_enqueue_script(
            'tainacan-chatgpt-admin',
            TAINACAN_CHATGPT_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            TAINACAN_CHATGPT_VERSION,
            true
        );

        // Lista de coleções para prompts personalizados
        $collections = $this->get_collections_list();

        wp_localize_script('tainacan-chatgpt-admin', 'TainacanChatGPTAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tainacan_chatgpt_admin_nonce'),
            'collections' => $collections,
            'texts' => [
                'testing' => __('Testando API...', 'tainacan-chatgpt'),
                'success' => __('Conexão bem-sucedida!', 'tainacan-chatgpt'),
                'error' => __('Falha na conexão. Verifique sua chave API.', 'tainacan-chatgpt'),
                'clearing' => __('Limpando cache...', 'tainacan-chatgpt'),
                'cacheCleared' => __('Cache limpo com sucesso!', 'tainacan-chatgpt'),
                'saving' => __('Salvando...', 'tainacan-chatgpt'),
                'saved' => __('Salvo com sucesso!', 'tainacan-chatgpt'),
                'confirmReset' => __('Tem certeza que deseja resetar para o prompt padrão?', 'tainacan-chatgpt'),
                'generating' => __('Gerando sugestão...', 'tainacan-chatgpt'),
            ]
        ]);
    }

    /**
     * Obtém lista de coleções
     */
    private function get_collections_list(): array {
        if (!class_exists('\Tainacan\Repositories\Collections')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[TainacanChatGPT] Collections class not found');
            }
            return [];
        }

        $collections_repo = \Tainacan\Repositories\Collections::get_instance();
        $collections = $collections_repo->fetch([], 'OBJECT');

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[TainacanChatGPT] Fetched collections count: ' . (is_array($collections) ? count($collections) : 'not array'));
        }

        $list = [];

        if (!$collections || !is_array($collections)) {
            return $list;
        }

        foreach ($collections as $collection) {
            $list[] = [
                'id' => $collection->get_id(),
                'name' => $collection->get_name(),
            ];
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[TainacanChatGPT] Collections list: ' . print_r($list, true));
        }

        return $list;
    }

    /**
     * Registra configurações
     */
    public function register_settings() {
        register_setting('tainacan_chatgpt_options', 'tainacan_chatgpt_options', [$this, 'validate_options']);
    }

    /**
     * Valida opções
     */
    public function validate_options($input) {
        $options = get_option('tainacan_chatgpt_options', []);

        // Provedor de IA
        if (isset($input['ai_provider'])) {
            $valid_providers = ['openai', 'gemini', 'deepseek', 'ollama'];
            $options['ai_provider'] = in_array($input['ai_provider'], $valid_providers)
                ? $input['ai_provider']
                : 'openai';
        }

        // Campos de texto (API keys e modelos)
        $text_fields = [
            'api_key',           // OpenAI
            'model',             // OpenAI
            'gemini_api_key',    // Gemini
            'gemini_model',      // Gemini
            'deepseek_api_key',  // DeepSeek
            'deepseek_model',    // DeepSeek
            'ollama_url',        // Ollama
            'ollama_model',      // Ollama
        ];
        foreach ($text_fields as $field) {
            if (isset($input[$field])) {
                $options[$field] = sanitize_text_field($input[$field]);
            }
        }

        // Campos de texto longo (prompts)
        $textarea_fields = ['default_image_prompt', 'default_document_prompt'];
        foreach ($textarea_fields as $field) {
            if (isset($input[$field])) {
                $options[$field] = wp_kses_post($input[$field]);
            }
        }

        // Campos numéricos
        $numeric_fields = ['max_tokens', 'request_timeout', 'cache_duration'];
        foreach ($numeric_fields as $field) {
            if (isset($input[$field])) {
                $options[$field] = absint($input[$field]);
            }
        }

        // Temperature (float)
        if (isset($input['temperature'])) {
            $options['temperature'] = max(0, min(2, floatval($input['temperature'])));
        }

        // Checkboxes
        $checkbox_fields = ['extract_exif', 'auto_map_metadata', 'consent_required', 'log_enabled', 'cost_tracking'];
        foreach ($checkbox_fields as $field) {
            $options[$field] = !empty($input[$field]);
        }

        return $options;
    }

    /**
     * Renderiza conteúdo da página
     */
    public function render_page_content() {
        $options = get_option('tainacan_chatgpt_options', []);
        $logger = new UsageLogger();
        $stats = $logger->get_stats('month');

        include TAINACAN_CHATGPT_PLUGIN_DIR . 'templates/admin-page.php';
    }

    /**
     * Testa conexão com API
     */
    public function ajax_test_api() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $provider = sanitize_text_field($_POST['provider'] ?? 'openai');
        $options = get_option('tainacan_chatgpt_options', []);

        // Determina qual chave e modelo usar baseado no provedor
        switch ($provider) {
            case 'gemini':
                $api_key = $options['gemini_api_key'] ?? '';
                $model = $options['gemini_model'] ?? 'gemini-1.5-pro';
                break;
            case 'deepseek':
                $api_key = $options['deepseek_api_key'] ?? '';
                $model = $options['deepseek_model'] ?? 'deepseek-chat';
                break;
            case 'ollama':
                $api_key = $options['ollama_url'] ?? 'http://localhost:11434';
                $model = $options['ollama_model'] ?? 'llama3.2';
                break;
            case 'openai':
            default:
                $api_key = $options['api_key'] ?? '';
                $model = $options['model'] ?? 'gpt-4o';
                break;
        }

        // Ollama não precisa de API key, mas precisa de URL
        if ($provider !== 'ollama' && empty($api_key)) {
            wp_send_json_error(__('Chave API não configurada. Salve as configurações primeiro.', 'tainacan-chatgpt'));
        }

        if ($provider === 'ollama' && empty($api_key)) {
            $api_key = 'http://localhost:11434';
        }

        // Usa a factory para testar o provedor
        $result = \Tainacan\ChatGPT\AI\AIProviderFactory::test_provider($provider, $api_key, $model);

        if ($result['success']) {
            wp_send_json_success(['message' => $result['message']]);
        } else {
            wp_send_json_error(['message' => $result['message']]);
        }
    }

    /**
     * Limpa cache
     */
    public function ajax_clear_cache() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        global $wpdb;
        $deleted = $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_tainacan_chatgpt_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_tainacan_chatgpt_%'");

        wp_send_json_success(sprintf(
            __('Cache limpo! %d entradas removidas.', 'tainacan-chatgpt'),
            $deleted
        ));
    }

    /**
     * Obtém estatísticas
     */
    public function ajax_get_stats() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $period = sanitize_text_field($_POST['period'] ?? 'month');
        $logger = new UsageLogger();

        wp_send_json_success([
            'stats' => $logger->get_stats($period),
            'daily' => $logger->get_daily_usage(30),
        ]);
    }

    /**
     * Exporta logs
     */
    public function ajax_export_logs() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $logger = new UsageLogger();
        $csv = $logger->export_csv();

        wp_send_json_success(['csv' => $csv]);
    }

    /**
     * Obtém metadados de uma coleção
     */
    public function ajax_get_collection_metadata() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $collection_id = absint($_POST['collection_id'] ?? 0);

        if (empty($collection_id)) {
            wp_send_json_error(__('ID da coleção não fornecido.', 'tainacan-chatgpt'));
        }

        if (!class_exists('\Tainacan\Repositories\Metadata')) {
            wp_send_json_error(__('Tainacan não está ativo.', 'tainacan-chatgpt'));
        }

        $metadata_repo = \Tainacan\Repositories\Metadata::get_instance();
        $metadata = $metadata_repo->fetch_by_collection(
            new \Tainacan\Entities\Collection($collection_id),
            [],
            'OBJECT'
        );

        $list = [];
        foreach ($metadata as $meta) {
            $list[] = [
                'id' => $meta->get_id(),
                'name' => $meta->get_name(),
                'slug' => $meta->get_slug(),
                'type' => $meta->get_metadata_type(),
            ];
        }

        wp_send_json_success($list);
    }

    /**
     * Salva mapeamento de campos para uma coleção
     */
    public function ajax_save_mapping() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $collection_id = absint($_POST['collection_id'] ?? 0);
        $mapping = isset($_POST['mapping']) ? json_decode(stripslashes($_POST['mapping']), true) : [];

        if (empty($collection_id)) {
            wp_send_json_error(__('ID da coleção não fornecido.', 'tainacan-chatgpt'));
        }

        // Salva o mapeamento como option
        $option_key = 'tainacan_chatgpt_mapping_' . $collection_id;
        update_option($option_key, $mapping);

        wp_send_json_success(__('Mapeamento salvo com sucesso!', 'tainacan-chatgpt'));
    }

    /**
     * Obtém mapeamento de campos para uma coleção
     */
    public function ajax_get_mapping() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $collection_id = absint($_POST['collection_id'] ?? 0);

        if (empty($collection_id)) {
            wp_send_json_error(__('ID da coleção não fornecido.', 'tainacan-chatgpt'));
        }

        $option_key = 'tainacan_chatgpt_mapping_' . $collection_id;
        $mapping = get_option($option_key, []);

        wp_send_json_success($mapping);
    }

    /**
     * Auto-detecta mapeamento baseado nos metadados da coleção
     */
    public function ajax_auto_detect_mapping() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $collection_id = absint($_POST['collection_id'] ?? 0);

        if (empty($collection_id)) {
            wp_send_json_error(__('ID da coleção não fornecido.', 'tainacan-chatgpt'));
        }

        if (!class_exists('\Tainacan\Repositories\Metadata')) {
            wp_send_json_error(__('Tainacan não está ativo.', 'tainacan-chatgpt'));
        }

        $metadata_repo = \Tainacan\Repositories\Metadata::get_instance();
        $metadata = $metadata_repo->fetch_by_collection(
            new \Tainacan\Entities\Collection($collection_id),
            [],
            'OBJECT'
        );

        // Mapeamento de campos comuns da IA para metadados Tainacan
        $ai_field_mappings = [
            'titulo' => ['titulo', 'title', 'nome', 'name'],
            'descricao' => ['descricao', 'description', 'desc', 'resumo', 'abstract'],
            'autor' => ['autor', 'author', 'autores', 'authors', 'criador', 'creator', 'dccreator'],
            'data' => ['data', 'date', 'data_criacao', 'created_date', 'dcdate', 'ano', 'year'],
            'assunto' => ['assunto', 'subject', 'tema', 'topic', 'palavras-chave', 'keywords', 'dcsubject'],
            'tipo' => ['tipo', 'type', 'categoria', 'category', 'dctype'],
            'formato' => ['formato', 'format', 'dcformat'],
            'idioma' => ['idioma', 'language', 'lingua', 'dclanguage'],
            'fonte' => ['fonte', 'source', 'origem', 'dcsource'],
            'direitos' => ['direitos', 'rights', 'licenca', 'license', 'dcrights'],
            'cobertura' => ['cobertura', 'coverage', 'local', 'location', 'dccoverage'],
            'editor' => ['editor', 'publisher', 'editora', 'dcpublisher'],
            'contribuidor' => ['contribuidor', 'contributor', 'colaborador', 'dccontributor'],
            'relacao' => ['relacao', 'relation', 'relacionado', 'dcrelation'],
            'identificador' => ['identificador', 'identifier', 'id', 'dcidentifier'],
        ];

        $auto_mapping = [];

        foreach ($metadata as $meta) {
            $meta_name = strtolower($meta->get_name());
            $meta_slug = strtolower($meta->get_slug());
            $meta_id = $meta->get_id();

            // Tenta encontrar correspondência
            foreach ($ai_field_mappings as $ai_field => $variations) {
                foreach ($variations as $variation) {
                    // Verifica no nome ou slug do metadado
                    if (
                        strpos($meta_name, $variation) !== false ||
                        strpos($meta_slug, $variation) !== false ||
                        $meta_name === $variation ||
                        $meta_slug === $variation
                    ) {
                        $auto_mapping[$ai_field] = [
                            'metadata_id' => $meta_id,
                            'metadata_name' => $meta->get_name(),
                        ];
                        break 2; // Sai dos dois loops
                    }
                }
            }
        }

        wp_send_json_success($auto_mapping);
    }
}
