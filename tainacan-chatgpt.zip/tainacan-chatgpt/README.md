# Tainacan ChatGPT 2.0

Plugin WordPress para extração automatizada de metadados no Tainacan utilizando a API do ChatGPT. Refatorado para Tainacan 1.0+.

## Novidades da versão 2.0

- **Compatível com Tainacan 1.0+**: Usa as novas APIs `Pages` e `Admin Form Hooks`
- **Interface Moderna**: Nova paleta de cores e animações suaves
- **Melhor UX**: Botão de análise integrado diretamente no formulário de item
- **REST API**: Endpoints para integração externa
- **Cache Inteligente**: Sistema de cache com invalidação manual

## Instalação

1. Faça upload da pasta `tainacan-chatgpt` para `/wp-content/plugins/`
2. Execute `composer install` na pasta do plugin (para suporte a PDF)
3. Ative o plugin no WordPress
4. Configure a chave API em **Tainacan > ChatGPT**

## Requisitos

- WordPress 6.5+
- PHP 7.4+
- Tainacan 1.0+
- Chave API OpenAI

## Uso

1. Configure sua chave API nas configurações do plugin
2. Edite um item no Tainacan com documento anexado
3. Na seção "Análise com IA", clique em **Analisar com ChatGPT**
4. Copie os metadados extraídos para os campos desejados

## Formatos Suportados

**Imagens**: JPG, PNG, GIF, WebP  
**Documentos**: PDF, TXT, HTML

## API REST

```
POST /wp-json/tainacan-chatgpt/v1/analyze/{attachment_id}
GET  /wp-json/tainacan-chatgpt/v1/status
DELETE /wp-json/tainacan-chatgpt/v1/cache/{attachment_id}
```

## Estrutura

```
tainacan-chatgpt/
├── tainacan-chatgpt.php    # Arquivo principal
├── src/
│   ├── AdminPage.php       # Página admin (Tainacan Pages API)
│   ├── ItemFormHook.php    # Integração formulário (Admin Form Hooks)
│   ├── DocumentAnalyzer.php # Análise de documentos
│   └── API.php             # REST API
├── templates/
│   └── admin-page.php      # Template da página de configurações
├── assets/
│   ├── css/
│   │   ├── admin.css       # Estilos do admin
│   │   └── item-form.css   # Estilos do formulário
│   └── js/
│       ├── admin.js        # JS do admin
│       └── item-form.js    # JS do formulário
└── languages/              # Traduções
```

## Licença

GPL v2 ou posterior
