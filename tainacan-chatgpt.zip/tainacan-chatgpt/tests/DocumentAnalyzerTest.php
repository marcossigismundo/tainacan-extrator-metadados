<?php
/**
 * Class DocumentAnalyzerTest
 *
 * @package Tainacan\ChatGPT
 */

use Tainacan\ChatGPT\DocumentAnalyzer;

class DocumentAnalyzerTest extends WP_UnitTestCase {
    /**
     * Analisador de documentos
     * 
     * @var DocumentAnalyzer
     */
    private $analyzer;
    
    /**
     * Configurar o teste
     */
    public function setUp(): void {
        parent::setUp();
        $this->analyzer = new DocumentAnalyzer();
    }
    
    /**
     * Testar método get_pdf_chunks
     */
    public function test_get_pdf_chunks() {
        // Criar um arquivo PDF de teste
        $test_pdf_path = __DIR__ . '/fixtures/test.pdf';
        
        // Verificar se o arquivo existe
        if (!file_exists($test_pdf_path)) {
            $this->markTestSkipped('Arquivo de teste PDF não encontrado');
        }
        
        $chunks = $this->analyzer->get_pdf_chunks($test_pdf_path);
        
        // Verificar se retornou um array
        $this->assertIsArray($chunks);
        
        // Verificar se há pelo menos um chunk
        $this->assertGreaterThan(0, count($chunks));
        
        // Verificar o tamanho aproximado dos chunks (deve ser aproximadamente 1500 palavras)
        if (count($chunks) > 0) {
            foreach ($chunks as $chunk) {
                $this->assertLessThanOrEqual(1600, count($chunk));
            }
        }
    }
    
    /**
     * Testar método chunk_text
     */
    public function test_chunk_text() {
        // Criar texto de teste com 3000 palavras
        $test_text = str_repeat('word ', 3000);
        
        // Usar reflexão para acessar método privado
        $reflection = new ReflectionClass($this->analyzer);
        $method = $reflection->getMethod('chunk_text');
        $method->setAccessible(true);
        
        // Testar com tamanho de chunk de 1000
        $chunks = $method->invokeArgs($this->analyzer, [$test_text, 1000]);
        
        // Verificar se retornou um array
        $this->assertIsArray($chunks);
        
        // Verificar se o número de chunks está correto
        $this->assertGreaterThanOrEqual(3, count($chunks));
        
        // Verificar o tamanho dos chunks
        foreach ($chunks as $chunk) {
            $this->assertLessThanOrEqual(1100, strlen($chunk)); // Permite alguma variação
        }
    }
    
    /**
     * Testar método validate_field_with_regex
     */
    public function test_validate_field_with_regex() {
        // Usar reflexão para acessar método privado
        $reflection = new ReflectionClass($this->analyzer);
        $method = $reflection->getMethod('validate_field_with_regex');
        $method->setAccessible(true);
        
        // Testar validação de data
        $this->assertTrue($method->invokeArgs($this->analyzer, ['data', '2021']));
        $this->assertTrue($method->invokeArgs($this->analyzer, ['data', '01/01/2021']));
        $this->assertFalse($method->invokeArgs($this->analyzer, ['data', 'Janeiro de 2021']));
        
        // Testar validação de ano
        $this->assertTrue($method->invokeArgs($this->analyzer, ['ano', '2021']));
        $this->assertFalse($method->invokeArgs($this->analyzer, ['ano', '21']));
        
        // Testar validação de DOI
        $this->assertTrue($method->invokeArgs($this->analyzer, ['doi', '10.1234/abc123']));
        $this->assertFalse($method->invokeArgs($this->analyzer, ['doi', 'abc123']));
        
        // Testar validação de dimensões
        $this->assertTrue($method->invokeArgs($this->analyzer, ['dimensoes', '10 x 20 cm']));
        $this->assertTrue($method->invokeArgs($this->analyzer, ['dimensoes', '10.5x20.3x30']));
        $this->assertFalse($method->invokeArgs($this->analyzer, ['dimensoes', '10 por 20']));
    }
    
    /**
     * Testar método extract_fields_from_prompt
     */
    public function test_extract_fields_from_prompt() {
        // Usar reflexão para acessar método privado
        $reflection = new ReflectionClass($this->analyzer);
        $method = $reflection->getMethod('extract_fields_from_prompt');
        $method->setAccessible(true);
        
        // Testar extração de campos explícitos
        $prompt = 'Analise este documento e extraia os seguintes metadados: título, autor, data, resumo.';
        $fields = $method->invokeArgs($this->analyzer, [$prompt]);
        
        $this->assertContains('título', $fields);
        $this->assertContains('autor', $fields);
        $this->assertContains('data', $fields);
        $this->assertContains('resumo', $fields);
        
        // Testar extração de campos implícitos
        $prompt = 'Identifique o autor e a data de publicação deste documento.';
        $fields = $method->invokeArgs($this->analyzer, [$prompt]);
        
        $this->assertContains('autor', $fields);
        $this->assertContains('data', $fields);
    }
    
    /**
     * Testar método create_json_schema
     */
    public function test_create_json_schema() {
        // Usar reflexão para acessar método privado
        $reflection = new ReflectionClass($this->analyzer);
        $method = $reflection->getMethod('create_json_schema');
        $method->setAccessible(true);
        
        // Testar criação de esquema JSON
        $fields = ['título', 'autor', 'data'];
        $schema = $method->invokeArgs($this->analyzer, [$fields]);
        
        // Verificar estrutura básica do esquema
        $this->assertEquals('extract_metadata', $schema['name']);
        $this->assertArrayHasKey('parameters', $schema);
        $this->assertArrayHasKey('properties', $schema['parameters']);
        
        // Verificar propriedades específicas
        $this->assertArrayHasKey('título', $schema['parameters']['properties']);
        $this->assertArrayHasKey('autor', $schema['parameters']['properties']);
        $this->assertArrayHasKey('data', $schema['parameters']['properties']);
        
        // Verificar tipo de cada propriedade
        $this->assertEquals('string', $schema['parameters']['properties']['título']['type']);
        $this->assertEquals('string', $schema['parameters']['properties']['autor']['type']);
        $this->assertEquals('string', $schema['parameters']['properties']['data']['type']);
    }
}