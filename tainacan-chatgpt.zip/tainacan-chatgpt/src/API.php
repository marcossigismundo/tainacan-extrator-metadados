<?php
namespace Tainacan\ChatGPT;

/**
 * Classe responsável pela comunicação com a API do ChatGPT
 */
class API {
    /**
     * Opções do plugin
     */
    private $options;
    
    /**
     * Logger para registrar eventos
     */
    private $logger;
    
    /**
     * Construtor
     */
    public function __construct() {
        // Valores padrão
        $default_options = array(
            'api_key' => '',
            'model' => 'gpt-4o',
            'image_prompt' => __('Analise esta imagem museológica e extraia os seguintes metadados: título, autor, data de criação, técnica utilizada, dimensões, estado de conservação, descrição visual detalhada. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
            'text_prompt' => __('Analise este documento e extraia os seguintes metadados: título, autor(es), ano de publicação, resumo, palavras-chave, metodologia, instituição, área de conhecimento. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
            'max_tokens' => 1000,
            'temperature' => 0.1,
            'request_timeout' => 30,
            'cache_duration' => 3600,
        );
        
        // Obtém opções salvas ou usa valores padrão
        $this->options = wp_parse_args(get_option('tainacan_chatgpt_options', array()), $default_options);
        $this->logger = new Logger();
    }
    
    /**
     * Testa a conexão com a API OpenAI
     *
     * @return array Resultado do teste de conexão
     */
    public function test_connection() {
        if (empty($this->options['api_key'])) {
            return array(
                'success' => false,
                'message' => __('Chave da API não configurada.', 'tainacan-chatgpt')
            );
        }
        
        $response = wp_remote_get('https://api.openai.com/v1/models', array(
            'timeout' => 15,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->options['api_key'],
                'Content-Type' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            
            $this->logger->log_error('Erro de conexão: ' . $error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de conexão: %s', 'tainacan-chatgpt'), $error_message)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($response_code === 200) {
            return array(
                'success' => true,
                'message' => __('Conexão estabelecida com sucesso!', 'tainacan-chatgpt')
            );
        } else {
            $error_message = isset($response_body['error']['message']) 
                ? $response_body['error']['message'] 
                : __('Erro desconhecido.', 'tainacan-chatgpt');
            
            $this->logger->log_error('Erro de API: ' . $error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de API (%d): %s', 'tainacan-chatgpt'), $response_code, $error_message)
            );
        }
    }
    
    /**
     * Envia uma solicitação para a API do OpenAI com function calling
     *
     * @param array $messages Array de mensagens para o chat
     * @param array $functions Array de definições de funções
     * @param array $options Opções adicionais para a API
     * @return array Resposta da API
     */
    public function send_function_request($messages, $functions, $options = []) {
        if (empty($this->options['api_key'])) {
            return array(
                'success' => false,
                'message' => __('Chave da API não configurada.', 'tainacan-chatgpt')
            );
        }
        
        $default_options = [
            'model' => $this->options['model'],
            'temperature' => 0,
            'max_tokens' => intval($this->options['max_tokens'])  // Garantir que seja inteiro
        ];
        
        $options = array_merge($default_options, $options);
        
        // Garantir que parâmetros numéricos sejam do tipo correto
        $options['max_tokens'] = intval($options['max_tokens']);
        $options['temperature'] = floatval($options['temperature']);
        
        $request_data = [
            'model' => $options['model'],
            'messages' => $messages,
            'temperature' => $options['temperature'],
            'max_tokens' => $options['max_tokens'],
            'functions' => $functions,
            'function_call' => ['name' => $functions[0]['name']]
        ];
        
        return $this->send_request('https://api.openai.com/v1/chat/completions', $request_data, 'function_call');
    }
    
    /**
     * Enviar solicitação para processar uma imagem com a API OpenAI
     * 
     * @param array $messages Mensagens para o modelo
     * @param array $options Opções adicionais
     * @return array Resposta da API
     */
    public function send_image_request($messages, $options = []) {
        if (empty($this->options['api_key'])) {
            return array(
                'success' => false,
                'message' => __('Chave da API não configurada.', 'tainacan-chatgpt')
            );
        }
        
        $default_options = [
            'model' => 'gpt-4o-vision',
            'temperature' => 0.1,
            'max_tokens' => intval($this->options['max_tokens']),  // Garantir que seja inteiro
            'response_format' => array('type' => 'json_object')
        ];
        
        $options = array_merge($default_options, $options);
        
        // Garantir que parâmetros numéricos sejam do tipo correto
        $options['max_tokens'] = intval($options['max_tokens']);
        $options['temperature'] = floatval($options['temperature']);
        
        $request_data = [
            'model' => $options['model'],
            'messages' => $messages,
            'temperature' => $options['temperature'],
            'max_tokens' => $options['max_tokens'],
            'response_format' => $options['response_format']
        ];
        
        return $this->send_request('https://api.openai.com/v1/chat/completions', $request_data, 'image');
    }
    
    /**
     * Analisa uma imagem usando a API do ChatGPT com function calling
     *
     * @param int $attachment_id ID do anexo
     * @param array $json_schema Esquema JSON para os metadados
     * @param string $custom_prompt Prompt personalizado
     * @return array Resultado da análise
     */
    public function analyze_image_with_function($attachment_id, $json_schema, $custom_prompt = '') {
        if (empty($this->options['api_key'])) {
            return array(
                'success' => false,
                'message' => __('Chave da API não configurada.', 'tainacan-chatgpt')
            );
        }
        
        // Verificar se o anexo existe
        $attachment = get_post($attachment_id);
        if (!$attachment) {
            return array(
                'success' => false,
                'message' => __('Anexo não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        // Obter URL e caminho da imagem
        $image_url = wp_get_attachment_url($attachment_id);
        $image_path = get_attached_file($attachment_id);
        
        // Se não encontrou, tente caminho alternativo para Tainacan
        if (empty($image_path) || !file_exists($image_path)) {
            // Construir caminho a partir da URL
            $upload_dir = wp_upload_dir();
            
            if ($image_url) {
                $file_rel_path = str_replace($upload_dir['baseurl'], '', $image_url);
                $alt_path = $upload_dir['basedir'] . $file_rel_path;
                $alt_path = str_replace('/', DIRECTORY_SEPARATOR, $alt_path);
                
                error_log('Debug: [API] URL alternativa: ' . $image_url);
                error_log('Debug: [API] Caminho alternativo: ' . $alt_path);
                
                if (file_exists($alt_path)) {
                    $image_path = $alt_path;
                    error_log('Debug: [API] Usando caminho alternativo');
                }
            }
        }
        
        if (!$image_url || !file_exists($image_path)) {
            return array(
                'success' => false,
                'message' => __('Arquivo de imagem não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        // Converter imagem para base64
        $image_data = file_get_contents($image_path);
        $base64_image = base64_encode($image_data);
        
        $prompt = !empty($custom_prompt) ? $custom_prompt : $this->options['image_prompt'];
        $model = !empty($this->options['model']) ? $this->options['model'] : 'gpt-4o';
        
        // Verificar se o modelo suporta análise de imagem
        if (!$this->model_supports_vision($model)) {
            $model = 'gpt-4o'; // Fallback para gpt-4o
        }
        
        // Prepara os dados para a API
        $messages = [
            [
                'role' => 'system',
                'content' => __('Você é um assistente especializado em análise visual e extração de metadados para acervos museológicos e culturais. Responda apenas com valores explicitamente presentes. Se não existir ou não for visível, retorne \'INFORMAÇÃO AUSENTE\'. Responda apenas em português do Brasil.', 'tainacan-chatgpt')
            ],
            [
                'role' => 'user',
                'content' => [
                    [
                        'type' => 'text',
                        'text' => $prompt
                    ],
                    [
                        'type' => 'image_url',
                        'image_url' => [
                            'url' => "data:image/jpeg;base64,$base64_image",
                            'detail' => 'high'
                        ]
                    ]
                ]
            ]
        ];
        
        // Criar função para chamada
        $functions = [$json_schema];
        
        // Garantir que o max_tokens seja inteiro
        return $this->send_function_request($messages, $functions, [
            'model' => $model,
            'temperature' => 0.1,
            'max_tokens' => intval($this->options['max_tokens'])  // Garantindo tipo inteiro
        ]);
    }
    
    /**
     * Envia requisição para a API OpenAI
     *
     * @param string $url URL da API
     * @param array $data Dados da requisição
     * @param string $content_type Tipo de conteúdo
     * @return array Resposta da API
     */
    public function send_request($url, $data, $content_type) {
        // Garantir que parâmetros numéricos sejam do tipo correto
        if (isset($data['max_tokens'])) {
            $data['max_tokens'] = intval($data['max_tokens']);
        }
        if (isset($data['temperature'])) {
            $data['temperature'] = floatval($data['temperature']);
        }
        
        error_log('Debug: [API] request data: ' . json_encode($data));
        
        // Registra início da requisição
        $this->logger->log_request_start($data['model'], $content_type);
        
        $timeout = isset($this->options['request_timeout']) ? intval($this->options['request_timeout']) : 30;
        
        $response = wp_remote_post($url, array(
            'timeout' => $timeout,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->options['api_key'],
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($data)
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            
            $this->logger->log_request_error($error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de conexão: %s', 'tainacan-chatgpt'), $error_message)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($response_code === 200) {
            // Registra sucesso da requisição
            if (isset($response_body['usage'])) {
                $usage = array(
                    'prompt_tokens' => isset($response_body['usage']['prompt_tokens']) ? $response_body['usage']['prompt_tokens'] : 0,
                    'completion_tokens' => isset($response_body['usage']['completion_tokens']) ? $response_body['usage']['completion_tokens'] : 0,
                    'total_tokens' => isset($response_body['usage']['total_tokens']) ? $response_body['usage']['total_tokens'] : 0
                );
                
                $this->logger->log_request_success($data['model'], $usage);
            }
            
            // Para chamadas de função
            if ($content_type === 'function_call' && isset($response_body['choices'][0]['message']['function_call'])) {
                $function_call = $response_body['choices'][0]['message']['function_call'];
                $arguments = json_decode($function_call['arguments'], true);
                
                return array(
                    'success' => true,
                    'data' => $arguments,
                    'raw_data' => $function_call['arguments'],
                    'usage' => $usage ?? [],
                    'function_name' => $function_call['name']
                );
            }
            
            // Para respostas de texto padrão ou imagens
            if (isset($response_body['choices'][0]['message']['content'])) {
                $content = $response_body['choices'][0]['message']['content'];
                $content_decoded = json_decode($content, true);
                
                return array(
                    'success' => true,
                    'data' => $content_decoded ?: $content,
                    'raw_data' => $content,
                    'usage' => $usage ?? []
                );
            }
            
            return array(
                'success' => true,
                'data' => $response_body,
                'raw_data' => wp_remote_retrieve_body($response),
                'usage' => $usage ?? []
            );
        } else {
            $error_message = isset($response_body['error']['message']) 
                ? $response_body['error']['message'] 
                : __('Erro desconhecido.', 'tainacan-chatgpt');
            
            $this->logger->log_request_error($error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de API (%d): %s', 'tainacan-chatgpt'), $response_code, $error_message)
            );
        }
    }
    
    /**
     * Verifica se o modelo suporta análise de imagem
     *
     * @param string $model Nome do modelo
     * @return bool True se o modelo suporta visão
     */
    private function model_supports_vision($model) {
        $vision_models = array(
            'gpt-4o',
            'gpt-4-vision-preview',
            'gpt-4-turbo',
            'gpt-4o-vision'
        );
        
        return in_array($model, $vision_models);
    }
}