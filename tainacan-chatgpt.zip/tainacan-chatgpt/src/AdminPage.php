<?php
namespace Tainacan\ChatGPT;

/**
 * Página administrativa do plugin usando Tainacan Pages API (1.0+)
 */
class AdminPage extends \Tainacan\Pages {
    use \Tainacan\Traits\Singleton_Instance;

    /**
     * Slug da página
     */
    protected function get_page_slug(): string {
        return 'tainacan_chatgpt';
    }

    /**
     * Inicialização
     */
    public function init() {
        parent::init();

        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_ajax_tainacan_chatgpt_test_api', [$this, 'ajax_test_api']);
        add_action('wp_ajax_tainacan_chatgpt_clear_cache', [$this, 'ajax_clear_cache']);
        add_action('wp_ajax_tainacan_chatgpt_get_stats', [$this, 'ajax_get_stats']);
        add_action('wp_ajax_tainacan_chatgpt_export_logs', [$this, 'ajax_export_logs']);
    }

    /**
     * Registra menu administrativo
     */
    public function add_admin_menu() {
        $page_suffix = add_submenu_page(
            $this->tainacan_root_menu_slug,
            __('Extrator IA', 'tainacan-chatgpt'),
            '<span class="icon">' . $this->get_chatgpt_icon() . '</span>' .
            '<span class="menu-text">' . __('Extrator IA', 'tainacan-chatgpt') . '</span>',
            'manage_options',
            $this->get_page_slug(),
            [$this, 'render_page'],
            10
        );

        add_action('load-' . $page_suffix, [$this, 'load_page']);
    }

    /**
     * Ícone SVG personalizado
     */
    private function get_chatgpt_icon(): string {
        return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
            <path d="M22.282 9.821a5.985 5.985 0 0 0-.516-4.91 6.046 6.046 0 0 0-6.51-2.9A6.065 6.065 0 0 0 4.981 4.18a5.985 5.985 0 0 0-3.998 2.9 6.046 6.046 0 0 0 .743 7.097 5.98 5.98 0 0 0 .51 4.911 6.051 6.051 0 0 0 6.515 2.9A5.985 5.985 0 0 0 13.26 24a6.056 6.056 0 0 0 5.772-4.206 5.99 5.99 0 0 0 3.997-2.9 6.056 6.056 0 0 0-.747-7.073zM13.26 22.43a4.476 4.476 0 0 1-2.876-1.04l.141-.081 4.779-2.758a.795.795 0 0 0 .392-.681v-6.737l2.02 1.168a.071.071 0 0 1 .038.052v5.583a4.504 4.504 0 0 1-4.494 4.494z"/>
        </svg>';
    }

    /**
     * Carrega CSS
     */
    public function admin_enqueue_css() {
        wp_enqueue_style(
            'tainacan-chatgpt-admin',
            TAINACAN_CHATGPT_PLUGIN_URL . 'assets/css/admin.css',
            [],
            TAINACAN_CHATGPT_VERSION
        );
    }

    /**
     * Carrega JavaScript
     */
    public function admin_enqueue_js() {
        wp_enqueue_script(
            'tainacan-chatgpt-admin',
            TAINACAN_CHATGPT_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            TAINACAN_CHATGPT_VERSION,
            true
        );

        // Lista de coleções para prompts personalizados
        $collections = $this->get_collections_list();

        wp_localize_script('tainacan-chatgpt-admin', 'TainacanChatGPTAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tainacan_chatgpt_admin_nonce'),
            'collections' => $collections,
            'texts' => [
                'testing' => __('Testando API...', 'tainacan-chatgpt'),
                'success' => __('Conexão bem-sucedida!', 'tainacan-chatgpt'),
                'error' => __('Falha na conexão. Verifique sua chave API.', 'tainacan-chatgpt'),
                'clearing' => __('Limpando cache...', 'tainacan-chatgpt'),
                'cacheCleared' => __('Cache limpo com sucesso!', 'tainacan-chatgpt'),
                'saving' => __('Salvando...', 'tainacan-chatgpt'),
                'saved' => __('Salvo com sucesso!', 'tainacan-chatgpt'),
                'confirmReset' => __('Tem certeza que deseja resetar para o prompt padrão?', 'tainacan-chatgpt'),
                'generating' => __('Gerando sugestão...', 'tainacan-chatgpt'),
            ]
        ]);
    }

    /**
     * Obtém lista de coleções
     */
    private function get_collections_list(): array {
        if (!class_exists('\Tainacan\Repositories\Collections')) {
            return [];
        }

        $collections_repo = \Tainacan\Repositories\Collections::get_instance();
        $collections = $collections_repo->fetch([], 'OBJECT');

        $list = [];
        foreach ($collections as $collection) {
            $list[] = [
                'id' => $collection->get_id(),
                'name' => $collection->get_name(),
            ];
        }

        return $list;
    }

    /**
     * Registra configurações
     */
    public function register_settings() {
        register_setting('tainacan_chatgpt_options', 'tainacan_chatgpt_options', [$this, 'validate_options']);
    }

    /**
     * Valida opções
     */
    public function validate_options($input) {
        $options = get_option('tainacan_chatgpt_options', []);

        // Campos de texto
        $text_fields = ['api_key', 'model'];
        foreach ($text_fields as $field) {
            if (isset($input[$field])) {
                $options[$field] = sanitize_text_field($input[$field]);
            }
        }

        // Campos de texto longo (prompts)
        $textarea_fields = ['default_image_prompt', 'default_document_prompt'];
        foreach ($textarea_fields as $field) {
            if (isset($input[$field])) {
                $options[$field] = wp_kses_post($input[$field]);
            }
        }

        // Campos numéricos
        $numeric_fields = ['max_tokens', 'request_timeout', 'cache_duration'];
        foreach ($numeric_fields as $field) {
            if (isset($input[$field])) {
                $options[$field] = absint($input[$field]);
            }
        }

        // Temperature (float)
        if (isset($input['temperature'])) {
            $options['temperature'] = max(0, min(2, floatval($input['temperature'])));
        }

        // Checkboxes
        $checkbox_fields = ['extract_exif', 'auto_map_metadata', 'consent_required', 'log_enabled', 'cost_tracking'];
        foreach ($checkbox_fields as $field) {
            $options[$field] = !empty($input[$field]);
        }

        return $options;
    }

    /**
     * Renderiza conteúdo da página
     */
    public function render_page_content() {
        $options = get_option('tainacan_chatgpt_options', []);
        $logger = new UsageLogger();
        $stats = $logger->get_stats('month');

        include TAINACAN_CHATGPT_PLUGIN_DIR . 'templates/admin-page.php';
    }

    /**
     * Testa conexão com API
     */
    public function ajax_test_api() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $options = get_option('tainacan_chatgpt_options', []);

        if (empty($options['api_key'])) {
            wp_send_json_error(__('Chave API não configurada. Salve as configurações primeiro.', 'tainacan-chatgpt'));
        }

        $response = wp_remote_get('https://api.openai.com/v1/models', [
            'headers' => [
                'Authorization' => 'Bearer ' . $options['api_key'],
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);

        if ($code === 200) {
            // Obtém informações dos modelos disponíveis
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $models = [];

            if (!empty($body['data'])) {
                foreach ($body['data'] as $model) {
                    if (strpos($model['id'], 'gpt') !== false) {
                        $models[] = $model['id'];
                    }
                }
            }

            wp_send_json_success([
                'message' => __('API conectada com sucesso!', 'tainacan-chatgpt'),
                'models' => array_slice($models, 0, 10),
            ]);
        } else {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $message = $body['error']['message'] ?? __('Erro desconhecido', 'tainacan-chatgpt');
            wp_send_json_error($message);
        }
    }

    /**
     * Limpa cache
     */
    public function ajax_clear_cache() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        global $wpdb;
        $deleted = $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_tainacan_chatgpt_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_tainacan_chatgpt_%'");

        wp_send_json_success(sprintf(
            __('Cache limpo! %d entradas removidas.', 'tainacan-chatgpt'),
            $deleted
        ));
    }

    /**
     * Obtém estatísticas
     */
    public function ajax_get_stats() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $period = sanitize_text_field($_POST['period'] ?? 'month');
        $logger = new UsageLogger();

        wp_send_json_success([
            'stats' => $logger->get_stats($period),
            'daily' => $logger->get_daily_usage(30),
        ]);
    }

    /**
     * Exporta logs
     */
    public function ajax_export_logs() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $logger = new UsageLogger();
        $csv = $logger->export_csv();

        wp_send_json_success(['csv' => $csv]);
    }
}
