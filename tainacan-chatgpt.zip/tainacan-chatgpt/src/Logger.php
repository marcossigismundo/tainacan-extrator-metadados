<?php
namespace Tainacan\ChatGPT;

/**
 * Classe responsável pelo registro de eventos e estatísticas
 */
class Logger {
    /**
     * Nome da opção para armazenar logs
     */
    private $option_name = 'tainacan_chatgpt_logs';
    
    /**
     * Obtém todos os logs
     * 
     * @return array Array com todos os logs
     */
    private function get_logs() {
        $logs = get_option($this->option_name);
        
        if (!$logs) {
            $logs = array(
                'requests' => array(),
                'errors' => array(),
                'models' => array(),
                'stats' => array(
                    'total_requests' => 0,
                    'successful_requests' => 0,
                    'failed_requests' => 0,
                    'cache_hits' => 0,
                    'total_tokens' => 0,
                    'total_cost' => 0
                )
            );
            
            update_option($this->option_name, $logs);
        }
        
        return $logs;
    }
    
    /**
     * Atualiza os logs
     * 
     * @param array $logs Array com logs atualizados
     */
    private function update_logs($logs) {
        // Limita o histórico para não sobrecarregar o banco de dados
        if (count($logs['requests']) > 1000) {
            array_splice($logs['requests'], 0, 100);
        }
        
        if (count($logs['errors']) > 100) {
            array_splice($logs['errors'], 0, 10);
        }
        
        update_option($this->option_name, $logs);
    }
    
    /**
     * Registra o início de uma requisição
     * 
     * @param string $model Modelo usado
     * @param string $content_type Tipo de conteúdo
     * @return string ID da requisição
     */
    public function log_request_start($model, $content_type) {
        $logs = $this->get_logs();
        
        $request_id = uniqid();
        
        $logs['requests'][] = array(
            'id' => $request_id,
            'model' => $model,
            'content_type' => $content_type,
            'timestamp' => time(),
            'status' => 'pending',
            'usage' => array(
                'prompt_tokens' => 0,
                'completion_tokens' => 0,
                'total_tokens' => 0
            )
        );
        
        $this->update_logs($logs);
        
        return $request_id;
    }
    
    /**
     * Registra o sucesso de uma requisição
     * 
     * @param string $model Modelo usado
     * @param array $usage Dados de uso de tokens
     */
    public function log_request_success($model, $usage) {
        $logs = $this->get_logs();
        
        // Encontra a última requisição pendente com este modelo
        $request_index = -1;
        for ($i = count($logs['requests']) - 1; $i >= 0; $i--) {
            if ($logs['requests'][$i]['status'] === 'pending' && $logs['requests'][$i]['model'] === $model) {
                $request_index = $i;
                break;
            }
        }
        
        if ($request_index >= 0) {
            $logs['requests'][$request_index]['status'] = 'success';
            $logs['requests'][$request_index]['usage'] = $usage;
            $logs['requests'][$request_index]['completed_at'] = time();
        }
        
        // Atualiza estatísticas
        $logs['stats']['total_requests']++;
        $logs['stats']['successful_requests']++;
        $logs['stats']['total_tokens'] += isset($usage['total_tokens']) ? $usage['total_tokens'] : 0;
        
        // Registra uso por modelo
        if (!isset($logs['models'][$model])) {
            $logs['models'][$model] = array(
                'requests' => 0,
                'tokens' => 0,
                'cost' => 0
            );
        }
        
        $logs['models'][$model]['requests']++;
        $logs['models'][$model]['tokens'] += isset($usage['total_tokens']) ? $usage['total_tokens'] : 0;
        
        // Estima custo baseado no modelo
        $cost = $this->estimate_cost($model, $usage);
        $logs['models'][$model]['cost'] += $cost;
        $logs['stats']['total_cost'] += $cost;
        
        $this->update_logs($logs);
    }
    
    /**
     * Registra erro em uma requisição
     * 
     * @param string $error_message Mensagem de erro
     */
    public function log_request_error($error_message) {
        $logs = $this->get_logs();
        
        // Encontra a última requisição pendente
        $request_index = -1;
        for ($i = count($logs['requests']) - 1; $i >= 0; $i--) {
            if ($logs['requests'][$i]['status'] === 'pending') {
                $request_index = $i;
                break;
            }
        }
        
        if ($request_index >= 0) {
            $logs['requests'][$request_index]['status'] = 'error';
            $logs['requests'][$request_index]['error'] = $error_message;
            $logs['requests'][$request_index]['completed_at'] = time();
        }
        
        // Registra o erro
        $logs['errors'][] = array(
            'timestamp' => time(),
            'message' => $error_message
        );
        
        // Atualiza estatísticas
        $logs['stats']['total_requests']++;
        $logs['stats']['failed_requests']++;
        
        $this->update_logs($logs);
    }
    
    /**
     * Registra um uso do cache
     */
    public function log_cache_hit() {
        $logs = $this->get_logs();
        $logs['stats']['cache_hits']++;
        $this->update_logs($logs);
    }
    
    /**
     * Registra um erro genérico
     * 
     * @param string $message Mensagem de erro
     */
    public function log_error($message) {
        $logs = $this->get_logs();
        
        $logs['errors'][] = array(
            'timestamp' => time(),
            'message' => $message
        );
        
        $this->update_logs($logs);
    }
    
    /**
     * Obtém estatísticas de uso
     * 
     * @return array Estatísticas de uso
     */
    public function get_usage_stats() {
        $logs = $this->get_logs();
        
        return array(
            'total_requests' => $logs['stats']['total_requests'],
            'successful_requests' => $logs['stats']['successful_requests'],
            'failed_requests' => $logs['stats']['failed_requests'],
            'cache_hits' => $logs['stats']['cache_hits'],
            'total_tokens' => $logs['stats']['total_tokens'],
            'total_cost' => $logs['stats']['total_cost'],
            'models' => $logs['models']
        );
    }
    
    /**
     * Estima o custo de uso baseado no modelo
     * 
     * @param string $model Nome do modelo
     * @param array $usage Dados de uso de tokens
     * @return float Custo estimado
     */
    private function estimate_cost($model, $usage) {
        $rates = array(
            'gpt-4o' => array(
                'input' => 0.00001, // $10 por 1M tokens
                'output' => 0.00003  // $30 por 1M tokens
            ),
            'gpt-4-vision-preview' => array(
                'input' => 0.00001,
                'output' => 0.00003
            ),
            'gpt-4-turbo' => array(
                'input' => 0.00001,
                'output' => 0.00003
            ),
            'gpt-4o-vision' => array(
                'input' => 0.00001,
                'output' => 0.00003
            ),
            'gpt-3.5-turbo' => array(
                'input' => 0.000001, // $1 por 1M tokens
                'output' => 0.000002  // $2 por 1M tokens
            )
        );
        
        // Se o modelo não estiver na lista, usa taxas do GPT-4o como padrão
        if (!isset($rates[$model])) {
            $model = 'gpt-4o';
        }
        
        $prompt_tokens = isset($usage['prompt_tokens']) ? $usage['prompt_tokens'] : 0;
        $completion_tokens = isset($usage['completion_tokens']) ? $usage['completion_tokens'] : 0;
        
        $input_cost = $prompt_tokens * $rates[$model]['input'];
        $output_cost = $completion_tokens * $rates[$model]['output'];
        
        return $input_cost + $output_cost;
    }
}