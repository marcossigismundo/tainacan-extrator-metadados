<?php
namespace Tainacan\ChatGPT;

/**
 * Extrator de metadados EXIF de imagens
 *
 * Extrai dados técnicos de imagens como câmera, configurações,
 * data de captura, localização GPS, etc.
 */
class ExifExtractor {

    /**
     * Tipos MIME suportados para EXIF
     */
    private array $supported_types = [
        'image/jpeg',
        'image/jpg',
        'image/tiff',
    ];

    /**
     * Extrai metadados EXIF de uma imagem
     */
    public function extract(string $file_path): array {
        if (!file_exists($file_path)) {
            return ['error' => __('Arquivo não encontrado.', 'tainacan-chatgpt')];
        }

        if (!function_exists('exif_read_data')) {
            return ['error' => __('Extensão EXIF do PHP não está habilitada.', 'tainacan-chatgpt')];
        }

        $mime_type = mime_content_type($file_path);
        if (!in_array($mime_type, $this->supported_types)) {
            return ['supported' => false, 'message' => __('Tipo de imagem não suporta EXIF.', 'tainacan-chatgpt')];
        }

        try {
            $exif = @exif_read_data($file_path, 'ANY_TAG', true);

            if ($exif === false) {
                return ['supported' => true, 'data' => [], 'message' => __('Nenhum dado EXIF encontrado.', 'tainacan-chatgpt')];
            }

            return [
                'supported' => true,
                'data' => $this->parse_exif_data($exif),
                'raw' => $exif,
            ];
        } catch (\Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Extrai EXIF de um attachment do WordPress
     */
    public function extract_from_attachment(int $attachment_id): array {
        $file_path = get_attached_file($attachment_id);

        if (!$file_path) {
            return ['error' => __('Arquivo do anexo não encontrado.', 'tainacan-chatgpt')];
        }

        return $this->extract($file_path);
    }

    /**
     * Processa dados EXIF brutos em formato amigável
     */
    private function parse_exif_data(array $exif): array {
        $parsed = [];

        // Informações básicas da imagem
        $parsed['imagem'] = [
            'largura' => $exif['COMPUTED']['Width'] ?? null,
            'altura' => $exif['COMPUTED']['Height'] ?? null,
            'orientacao' => $this->get_orientation_text($exif['IFD0']['Orientation'] ?? null),
            'resolucao_x' => $exif['IFD0']['XResolution'] ?? null,
            'resolucao_y' => $exif['IFD0']['YResolution'] ?? null,
            'unidade_resolucao' => $this->get_resolution_unit($exif['IFD0']['ResolutionUnit'] ?? null),
            'espaco_cor' => $this->get_color_space($exif['EXIF']['ColorSpace'] ?? null),
        ];

        // Informações da câmera
        $parsed['camera'] = [
            'fabricante' => $exif['IFD0']['Make'] ?? null,
            'modelo' => $exif['IFD0']['Model'] ?? null,
            'software' => $exif['IFD0']['Software'] ?? null,
            'lente' => $exif['EXIF']['LensModel'] ?? $exif['EXIF']['UndefinedTag:0xA434'] ?? null,
        ];

        // Configurações de captura
        $parsed['captura'] = [
            'data_hora' => $this->parse_datetime($exif['EXIF']['DateTimeOriginal'] ?? $exif['IFD0']['DateTime'] ?? null),
            'exposicao' => $this->format_exposure($exif['EXIF']['ExposureTime'] ?? null),
            'abertura' => $this->format_aperture($exif['EXIF']['FNumber'] ?? null),
            'iso' => $exif['EXIF']['ISOSpeedRatings'] ?? null,
            'distancia_focal' => $this->format_focal_length($exif['EXIF']['FocalLength'] ?? null),
            'distancia_focal_35mm' => isset($exif['EXIF']['FocalLengthIn35mmFilm'])
                ? $exif['EXIF']['FocalLengthIn35mmFilm'] . 'mm'
                : null,
            'modo_exposicao' => $this->get_exposure_mode($exif['EXIF']['ExposureMode'] ?? null),
            'programa_exposicao' => $this->get_exposure_program($exif['EXIF']['ExposureProgram'] ?? null),
            'modo_medicao' => $this->get_metering_mode($exif['EXIF']['MeteringMode'] ?? null),
            'flash' => $this->get_flash_info($exif['EXIF']['Flash'] ?? null),
            'balanco_branco' => $this->get_white_balance($exif['EXIF']['WhiteBalance'] ?? null),
        ];

        // GPS
        if (isset($exif['GPS']) && !empty($exif['GPS'])) {
            $parsed['gps'] = $this->parse_gps_data($exif['GPS']);
        }

        // Copyright e autor
        $parsed['autoria'] = [
            'artista' => $exif['IFD0']['Artist'] ?? null,
            'copyright' => $exif['IFD0']['Copyright'] ?? null,
            'descricao' => $exif['IFD0']['ImageDescription'] ?? null,
        ];

        // Remove valores nulos
        $parsed = $this->remove_null_values($parsed);

        return $parsed;
    }

    /**
     * Parse de data/hora EXIF
     */
    private function parse_datetime(?string $datetime): ?string {
        if (!$datetime) {
            return null;
        }

        try {
            $dt = \DateTime::createFromFormat('Y:m:d H:i:s', $datetime);
            return $dt ? $dt->format('Y-m-d H:i:s') : $datetime;
        } catch (\Exception $e) {
            return $datetime;
        }
    }

    /**
     * Formata tempo de exposição
     */
    private function format_exposure(mixed $exposure): ?string {
        if (!$exposure) {
            return null;
        }

        if (is_string($exposure) && strpos($exposure, '/') !== false) {
            list($num, $den) = explode('/', $exposure);
            $value = $num / $den;

            if ($value >= 1) {
                return $value . 's';
            } else {
                return '1/' . round(1 / $value) . 's';
            }
        }

        return $exposure . 's';
    }

    /**
     * Formata abertura (f-number)
     */
    private function format_aperture(mixed $fnumber): ?string {
        if (!$fnumber) {
            return null;
        }

        if (is_string($fnumber) && strpos($fnumber, '/') !== false) {
            list($num, $den) = explode('/', $fnumber);
            return 'f/' . round($num / $den, 1);
        }

        return 'f/' . $fnumber;
    }

    /**
     * Formata distância focal
     */
    private function format_focal_length(mixed $focal): ?string {
        if (!$focal) {
            return null;
        }

        if (is_string($focal) && strpos($focal, '/') !== false) {
            list($num, $den) = explode('/', $focal);
            return round($num / $den) . 'mm';
        }

        return $focal . 'mm';
    }

    /**
     * Texto de orientação
     */
    private function get_orientation_text(?int $orientation): ?string {
        $orientations = [
            1 => __('Normal', 'tainacan-chatgpt'),
            2 => __('Espelhado horizontalmente', 'tainacan-chatgpt'),
            3 => __('Rotacionado 180°', 'tainacan-chatgpt'),
            4 => __('Espelhado verticalmente', 'tainacan-chatgpt'),
            5 => __('Espelhado horizontalmente e rotacionado 270°', 'tainacan-chatgpt'),
            6 => __('Rotacionado 90°', 'tainacan-chatgpt'),
            7 => __('Espelhado horizontalmente e rotacionado 90°', 'tainacan-chatgpt'),
            8 => __('Rotacionado 270°', 'tainacan-chatgpt'),
        ];

        return $orientations[$orientation] ?? null;
    }

    /**
     * Unidade de resolução
     */
    private function get_resolution_unit(?int $unit): ?string {
        $units = [
            1 => __('Sem unidade', 'tainacan-chatgpt'),
            2 => __('polegadas', 'tainacan-chatgpt'),
            3 => __('centímetros', 'tainacan-chatgpt'),
        ];

        return $units[$unit] ?? null;
    }

    /**
     * Espaço de cor
     */
    private function get_color_space(?int $space): ?string {
        $spaces = [
            1 => 'sRGB',
            65535 => __('Não calibrado', 'tainacan-chatgpt'),
        ];

        return $spaces[$space] ?? null;
    }

    /**
     * Modo de exposição
     */
    private function get_exposure_mode(?int $mode): ?string {
        $modes = [
            0 => __('Automático', 'tainacan-chatgpt'),
            1 => __('Manual', 'tainacan-chatgpt'),
            2 => __('Auto bracket', 'tainacan-chatgpt'),
        ];

        return $modes[$mode] ?? null;
    }

    /**
     * Programa de exposição
     */
    private function get_exposure_program(?int $program): ?string {
        $programs = [
            0 => __('Não definido', 'tainacan-chatgpt'),
            1 => __('Manual', 'tainacan-chatgpt'),
            2 => __('Programa normal', 'tainacan-chatgpt'),
            3 => __('Prioridade de abertura', 'tainacan-chatgpt'),
            4 => __('Prioridade de velocidade', 'tainacan-chatgpt'),
            5 => __('Criativo', 'tainacan-chatgpt'),
            6 => __('Ação', 'tainacan-chatgpt'),
            7 => __('Retrato', 'tainacan-chatgpt'),
            8 => __('Paisagem', 'tainacan-chatgpt'),
        ];

        return $programs[$program] ?? null;
    }

    /**
     * Modo de medição
     */
    private function get_metering_mode(?int $mode): ?string {
        $modes = [
            0 => __('Desconhecido', 'tainacan-chatgpt'),
            1 => __('Média', 'tainacan-chatgpt'),
            2 => __('Ponderada ao centro', 'tainacan-chatgpt'),
            3 => __('Pontual', 'tainacan-chatgpt'),
            4 => __('Multi-ponto', 'tainacan-chatgpt'),
            5 => __('Padrão', 'tainacan-chatgpt'),
            6 => __('Parcial', 'tainacan-chatgpt'),
        ];

        return $modes[$mode] ?? null;
    }

    /**
     * Informações do flash
     */
    private function get_flash_info(?int $flash): ?string {
        if ($flash === null) {
            return null;
        }

        $fired = ($flash & 1) ? __('Disparado', 'tainacan-chatgpt') : __('Não disparado', 'tainacan-chatgpt');

        return $fired;
    }

    /**
     * Balanço de branco
     */
    private function get_white_balance(?int $wb): ?string {
        $balances = [
            0 => __('Automático', 'tainacan-chatgpt'),
            1 => __('Manual', 'tainacan-chatgpt'),
        ];

        return $balances[$wb] ?? null;
    }

    /**
     * Parse dados GPS
     */
    private function parse_gps_data(array $gps): array {
        $parsed = [];

        // Latitude
        if (isset($gps['GPSLatitude']) && isset($gps['GPSLatitudeRef'])) {
            $lat = $this->gps_to_decimal($gps['GPSLatitude'], $gps['GPSLatitudeRef']);
            $parsed['latitude'] = $lat;
            $parsed['latitude_formatada'] = $this->format_gps_coordinate($gps['GPSLatitude'], $gps['GPSLatitudeRef'], 'lat');
        }

        // Longitude
        if (isset($gps['GPSLongitude']) && isset($gps['GPSLongitudeRef'])) {
            $lng = $this->gps_to_decimal($gps['GPSLongitude'], $gps['GPSLongitudeRef']);
            $parsed['longitude'] = $lng;
            $parsed['longitude_formatada'] = $this->format_gps_coordinate($gps['GPSLongitude'], $gps['GPSLongitudeRef'], 'lng');
        }

        // Altitude
        if (isset($gps['GPSAltitude'])) {
            $alt = $this->parse_gps_value($gps['GPSAltitude']);
            $ref = $gps['GPSAltitudeRef'] ?? 0;
            $parsed['altitude'] = ($ref == 1 ? -1 : 1) * $alt;
            $parsed['altitude_formatada'] = round($parsed['altitude']) . 'm';
        }

        // Link Google Maps
        if (isset($parsed['latitude']) && isset($parsed['longitude'])) {
            $parsed['google_maps_link'] = sprintf(
                'https://www.google.com/maps?q=%s,%s',
                $parsed['latitude'],
                $parsed['longitude']
            );
        }

        return $parsed;
    }

    /**
     * Converte coordenada GPS para decimal
     */
    private function gps_to_decimal(array $coordinate, string $ref): float {
        $degrees = $this->parse_gps_value($coordinate[0]);
        $minutes = $this->parse_gps_value($coordinate[1]);
        $seconds = $this->parse_gps_value($coordinate[2]);

        $decimal = $degrees + ($minutes / 60) + ($seconds / 3600);

        if ($ref === 'S' || $ref === 'W') {
            $decimal *= -1;
        }

        return round($decimal, 6);
    }

    /**
     * Parse valor GPS (fração)
     */
    private function parse_gps_value(mixed $value): float {
        if (is_string($value) && strpos($value, '/') !== false) {
            list($num, $den) = explode('/', $value);
            return $den != 0 ? $num / $den : 0;
        }

        return (float) $value;
    }

    /**
     * Formata coordenada GPS para exibição
     */
    private function format_gps_coordinate(array $coord, string $ref, string $type): string {
        $degrees = $this->parse_gps_value($coord[0]);
        $minutes = $this->parse_gps_value($coord[1]);
        $seconds = $this->parse_gps_value($coord[2]);

        return sprintf(
            '%d° %d\' %.2f" %s',
            $degrees,
            $minutes,
            $seconds,
            $ref
        );
    }

    /**
     * Remove valores nulos recursivamente
     */
    private function remove_null_values(array $array): array {
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $array[$key] = $this->remove_null_values($value);
                if (empty($array[$key])) {
                    unset($array[$key]);
                }
            } elseif ($value === null) {
                unset($array[$key]);
            }
        }

        return $array;
    }

    /**
     * Obtém resumo dos dados EXIF para exibição
     */
    public function get_summary(array $exif_data): array {
        if (!isset($exif_data['data'])) {
            return [];
        }

        $data = $exif_data['data'];
        $summary = [];

        // Camera
        if (!empty($data['camera']['fabricante']) || !empty($data['camera']['modelo'])) {
            $summary['camera'] = trim(
                ($data['camera']['fabricante'] ?? '') . ' ' . ($data['camera']['modelo'] ?? '')
            );
        }

        // Data
        if (!empty($data['captura']['data_hora'])) {
            $summary['data_captura'] = $data['captura']['data_hora'];
        }

        // Configurações principais
        $settings = [];
        if (!empty($data['captura']['exposicao'])) {
            $settings[] = $data['captura']['exposicao'];
        }
        if (!empty($data['captura']['abertura'])) {
            $settings[] = $data['captura']['abertura'];
        }
        if (!empty($data['captura']['iso'])) {
            $settings[] = 'ISO ' . $data['captura']['iso'];
        }
        if (!empty($data['captura']['distancia_focal'])) {
            $settings[] = $data['captura']['distancia_focal'];
        }
        if (!empty($settings)) {
            $summary['configuracoes'] = implode(' | ', $settings);
        }

        // Dimensões
        if (!empty($data['imagem']['largura']) && !empty($data['imagem']['altura'])) {
            $summary['dimensoes'] = $data['imagem']['largura'] . ' x ' . $data['imagem']['altura'] . 'px';
        }

        // GPS
        if (!empty($data['gps']['google_maps_link'])) {
            $summary['localizacao'] = $data['gps']['google_maps_link'];
        }

        return $summary;
    }
}
