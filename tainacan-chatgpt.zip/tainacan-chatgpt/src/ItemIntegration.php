<?php
namespace Tainacan\ChatGPT;

/**
 * Classe responsável pela integração com a interface de itens do Tainacan
 */
class ItemIntegration {
    /**
     * Construtor
     */
public function __construct() {
    // Verificar se o Tainacan está ativo e disponível
    if (!class_exists('\Tainacan\Repositories\Items')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error is-dismissible"><p>';
            echo esc_html__('O plugin Tainacan precisa estar ativo para usar o Tainacan ChatGPT.', 'tainacan-chatgpt');
            echo '</p></div>';
        });
        return;
    }
    
    // Adiciona scripts na interface de admin do Tainacan
    add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    
    // Adiciona endpoint AJAX para análise de anexos
    add_action('wp_ajax_tainacan_chatgpt_analyze_attachment', array($this, 'ajax_analyze_attachment'));
    add_action('wp_ajax_tainacan_chatgpt_analyze_item', array($this, 'ajax_analyze_item'));
    
    // Adiciona endpoint AJAX para obter anexo por URL
    add_action('wp_ajax_tainacan_chatgpt_get_attachment_by_url', array($this, 'ajax_get_attachment_by_url'));
    
    // Adiciona endpoint AJAX para limpar cache de um item específico
    add_action('wp_ajax_tainacan_chatgpt_clear_item_cache', array($this, 'ajax_clear_item_cache'));
}

/**
 * Adicione esta função ao arquivo src/ItemIntegration.php
 * Endpoint AJAX para limpar cache de um item específico
 */
public function ajax_clear_item_cache() {
    // Verificar nonce para segurança
    check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');
    
    // Verificar permissões
    if (!current_user_can('edit_posts') && !current_user_can('edit_tainacan_items')) {
        wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        return;
    }
    
    $attachment_id = isset($_POST['attachment_id']) ? absint($_POST['attachment_id']) : 0;
    
    if (empty($attachment_id)) {
        wp_send_json_error(__('ID do anexo não fornecido.', 'tainacan-chatgpt'));
        return;
    }
    
    error_log('Debug: Limpando cache para anexo ID: ' . $attachment_id);
    
    // Limpar cache para o anexo
    $cache = new Cache();
    $deleted_attachment = $cache->delete("attachment_{$attachment_id}");
    
    // Limpar cache para o item (se existir)
    $deleted_item = false;
    if (class_exists('\Tainacan\Repositories\Items')) {
        // Tente encontrar o ID do item relacionado ao anexo
        $item_id = 0;
        
        // Método 1: Verificar se o anexo é um documento de item
        global $wpdb;
        $item_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = 'document_id' AND meta_value = %d",
            $attachment_id
        ));
        
        if ($item_id) {
            error_log('Debug: Limpando cache também para item ID: ' . $item_id);
            $deleted_item = $cache->delete("item_{$item_id}");
        }
    }
    
    if ($deleted_attachment || $deleted_item) {
        wp_send_json_success(__('Cache limpo com sucesso!', 'tainacan-chatgpt'));
    } else {
        wp_send_json_success(__('Não havia cache para este item ou não foi possível limpá-lo.', 'tainacan-chatgpt'));
    }
}
    
    /**
     * Carrega scripts e estilos
     * 
     * @param string $hook Hook da página atual
     */
public function enqueue_assets($hook) {
    // Carrega apenas nas páginas de edição de itens do Tainacan
    if (strpos($hook, 'tainacan_admin') !== false || 
        strpos($hook, 'page_tainacan_admin') !== false ||
        strpos($hook, 'post.php') !== false) {
        
        // Registra e carrega o JavaScript
        wp_enqueue_script(
            'tainacan-chatgpt',
            TAINACAN_CHATGPT_PLUGIN_DIR_URL . 'assets/js/tainacan-chatgpt.js',
            array('jquery'),
            TAINACAN_CHATGPT_VERSION,
            true
        );
        
        // Registra e carrega o CSS
        wp_enqueue_style(
            'tainacan-chatgpt',
            TAINACAN_CHATGPT_PLUGIN_DIR_URL . 'assets/css/tainacan-chatgpt.css',
            array(),
            TAINACAN_CHATGPT_VERSION
        );
        
        // Localiza script (isso já estava presente)
        wp_localize_script('tainacan-chatgpt', 'TainacanChatGPT', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tainacan_chatgpt_nonce'),
            'debug_enabled' => defined('WP_DEBUG') && WP_DEBUG,
            'texts' => array(
                'analyzeWithChatGPT' => __('Analisar com ChatGPT', 'tainacan-chatgpt'),
                'analyzing' => __('Analisando...', 'tainacan-chatgpt'),
                'errorOccurred' => __('Ocorreu um erro. Tente novamente.', 'tainacan-chatgpt'),
                'noDocumentFound' => __('Nenhum documento encontrado neste item.', 'tainacan-chatgpt'),
                'copyValue' => __('Copiar', 'tainacan-chatgpt'),
                'copied' => __('Copiado!', 'tainacan-chatgpt'),
                'closePanel' => __('Fechar', 'tainacan-chatgpt'),
                'refreshAnalysis' => __('Atualizar', 'tainacan-chatgpt'),
                'refreshTooltip' => __('Atualizar análise (usa cache se disponível)', 'tainacan-chatgpt'),
                'clearCache' => __('Limpar Cache', 'tainacan-chatgpt'),
                'clearCacheTooltip' => __('Limpar cache e fazer nova análise', 'tainacan-chatgpt'),
                'cacheCleared' => __('Cache limpo!', 'tainacan-chatgpt'),
                'metadataResults' => __('Metadados Extraídos', 'tainacan-chatgpt'),
                'fromCache' => __('Resultados carregados do cache', 'tainacan-chatgpt'),
                'needsHumanReview' => __('Este resultado precisa de revisão humana. Alguns campos podem não ter sido encontrados ou podem conter informações imprecisas.', 'tainacan-chatgpt'),
                'showEvidence' => __('Mostrar evidência', 'tainacan-chatgpt'),
                'hideEvidence' => __('Ocultar evidência', 'tainacan-chatgpt'),
                'evidence' => __('Evidência', 'tainacan-chatgpt'),
                'analysisType' => __('Tipo de análise', 'tainacan-chatgpt'),
                'analysisTypeAuto' => __('Automático', 'tainacan-chatgpt'),
                'analysisTypePdf' => __('PDF', 'tainacan-chatgpt'),
                'analysisTypeImage' => __('Imagem', 'tainacan-chatgpt'),
                'stepExtraction' => __('Extração', 'tainacan-chatgpt'),
                'stepVerification' => __('Verificação', 'tainacan-chatgpt'),
                'stepValidation' => __('Validação', 'tainacan-chatgpt'),
                'stepCompletion' => __('Finalização', 'tainacan-chatgpt')
            )
        ));
    }
}
    
    /**
     * Endpoint AJAX para obter anexo por URL
     */
    public function ajax_get_attachment_by_url() {
        // Verificar nonce para segurança
        check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');
        
        // Verificar permissões
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }
        
        // Sanitizar entrada
        $attachment_url = isset($_POST['attachment_url']) ? sanitize_text_field($_POST['attachment_url']) : '';
        
        if (empty($attachment_url)) {
            wp_send_json_error(__('URL do anexo não fornecido.', 'tainacan-chatgpt'));
        }
        
        // Obter caminho base de uploads
        $uploads_dir = wp_upload_dir();
        $uploads_baseurl = $uploads_dir['baseurl'];
        
        // Verificar se o URL é da pasta de uploads
        if (strpos($attachment_url, $uploads_baseurl) === false) {
            wp_send_json_error(__('URL do anexo não é válido.', 'tainacan-chatgpt'));
        }
        
        // Buscar pelo path relativo
        $relative_path = str_replace($uploads_baseurl, '', $attachment_url);
        global $wpdb;
        
        // Primeiro tentar buscar pelo link direto
        $attachment_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value = %s",
            ltrim($relative_path, '/')
        ));
        
        // Se não encontrou, tentar buscar por qualquer URL que contenha o arquivo
        if (!$attachment_id) {
            $filename = basename($attachment_url);
            $attachment_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s",
                '%' . $wpdb->esc_like($filename)
            ));
        }
        
        if ($attachment_id) {
            wp_send_json_success(absint($attachment_id));
        } else {
            wp_send_json_error(__('Anexo não encontrado para a URL fornecida.', 'tainacan-chatgpt'));
        }
    }
    
    /**
     * Endpoint AJAX para análise de anexos
     */
    public function ajax_analyze_attachment() {
		 error_log('Debug: ajax_analyze_attachment iniciado');
        // Verificar nonce para segurança
        check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');
        
        // Verificar permissões (edit_posts ou edit_tainacan_items)
        if (!current_user_can('edit_posts') && !current_user_can('edit_tainacan_items')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
            return;
        }
        
        // Sanitizar inputs
        $attachment_id = isset($_POST['attachment_id']) ? absint($_POST['attachment_id']) : 0;
        $force_refresh = isset($_POST['force_refresh']) ? (bool)$_POST['force_refresh'] : false;
        $analysis_type = isset($_POST['analysis_type']) ? sanitize_text_field($_POST['analysis_type']) : 'auto';
        
        if (empty($attachment_id)) {
            wp_send_json_error(__('ID do anexo não fornecido.', 'tainacan-chatgpt'));
        }
        
        // Verificar se o anexo existe
        $attachment = get_post($attachment_id);
        if (!$attachment || $attachment->post_type !== 'attachment') {
            wp_send_json_error(__('Anexo não encontrado ou ID inválido.', 'tainacan-chatgpt'));
        }
        
        // Verificar se é um tipo de análise válido
        $valid_types = array('auto', 'pdf', 'image', 'document');
        if (!in_array($analysis_type, $valid_types)) {
            $analysis_type = 'auto';
        }
        
        $analyzer = new DocumentAnalyzer();
		 error_log('Debug: chamando analyze_attachment com ID: ' . $attachment_id);
        $result = $analyzer->analyze_attachment($attachment_id, $force_refresh, $analysis_type);
		error_log('Debug: resultado da análise: ' . json_encode($result));
        
        if ($result['success']) {
            // Se for bem-sucedido, salvar flag de revisão humana nos metadados do item
            if (isset($result['data']['needs_human_review'])) {
                update_post_meta($attachment_id, '_tainacan_chatgpt_needs_review', $result['data']['needs_human_review']);
            }
            
            wp_send_json_success(array(
                'metadata' => $result['data']['metadata'] ?? [],
                'evidence' => $result['data']['evidence'] ?? [],
                'validation' => $result['data']['validation'] ?? [],
                'needs_human_review' => $result['data']['needs_human_review'] ?? false,
                'from_cache' => isset($result['from_cache']) ? $result['from_cache'] : false
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Endpoint AJAX para análise de itens
     */
    public function ajax_analyze_item() {
        // Verificar nonce para segurança
        check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');
        
        // Verificar permissões (edit_posts ou edit_tainacan_items)
        if (!current_user_can('edit_posts') && !current_user_can('edit_tainacan_items')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }
        
        $item_id = isset($_POST['item_id']) ? absint($_POST['item_id']) : 0;
        
        // Se não recebeu item_id, tenta usar o document_id como attachment_id
        if (empty($item_id) && isset($_POST['document_id']) && !empty($_POST['document_id'])) {
            return $this->ajax_analyze_attachment(); 
        }
        
        if (empty($item_id)) {
            wp_send_json_error(__('ID do item não fornecido.', 'tainacan-chatgpt'));
        }
        
        // Sanitizar inputs
        $force_refresh = isset($_POST['force_refresh']) ? (bool)$_POST['force_refresh'] : false;
        $analysis_type = isset($_POST['analysis_type']) ? sanitize_text_field($_POST['analysis_type']) : 'auto';
        
        // Verificar se é um tipo de análise válido
        $valid_types = array('auto', 'pdf', 'image', 'document');
        if (!in_array($analysis_type, $valid_types)) {
            $analysis_type = 'auto';
        }
        
        $analyzer = new DocumentAnalyzer();
        $result = $analyzer->analyze_item($item_id, $force_refresh, $analysis_type);
        
        if ($result['success']) {
            // Se for bem-sucedido, salvar flag de revisão humana nos metadados do item
            if (isset($result['data']['needs_human_review'])) {
                update_post_meta($item_id, '_tainacan_chatgpt_needs_review', $result['data']['needs_human_review']);
            }
            
            wp_send_json_success(array(
                'metadata' => $result['data']['metadata'] ?? [],
                'evidence' => $result['data']['evidence'] ?? [],
                'validation' => $result['data']['validation'] ?? [],
                'needs_human_review' => $result['data']['needs_human_review'] ?? false,
                'from_cache' => isset($result['from_cache']) ? $result['from_cache'] : false
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }
}