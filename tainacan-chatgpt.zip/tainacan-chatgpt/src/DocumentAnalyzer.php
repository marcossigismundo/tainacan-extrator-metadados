<?php
namespace Tainacan\ChatGPT;

use Tainacan\ChatGPT\PdfParser\PdfParser;
use Tainacan\ChatGPT\PdfParser\PdfToImage;

/**
 * Analisador de documentos usando API OpenAI
 *
 * Analisa imagens e documentos extraindo metadados via GPT-4 Vision.
 * Suporta múltiplos métodos de extração com fallback automático.
 *
 * @since 3.1.0 - Versão com dependências embutidas
 */
class DocumentAnalyzer {

    private array $options;
    private ?int $collection_id = null;
    private ?int $item_id = null;
    private ExifExtractor $exif_extractor;
    private CollectionPrompts $collection_prompts;
    private UsageLogger $logger;

    /**
     * Tipos MIME suportados
     */
    private array $supported_image_types = [
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
    ];

    private array $supported_document_types = [
        'application/pdf',
        'text/plain',
        'text/html',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ];

    public function __construct() {
        $this->options = \Tainacan_ChatGPT::get_options();
        $this->exif_extractor = new ExifExtractor();
        $this->collection_prompts = new CollectionPrompts();
        $this->logger = new UsageLogger();
    }

    /**
     * Define contexto da análise
     */
    public function set_context(?int $collection_id = null, ?int $item_id = null): self {
        $this->collection_id = $collection_id;
        $this->item_id = $item_id;
        return $this;
    }

    /**
     * Analisa um anexo
     */
    public function analyze(int $attachment_id, bool $include_exif = true): array|\WP_Error {
        // Verifica API key
        if (empty($this->options['api_key'])) {
            return new \WP_Error('no_api_key', __('Chave API não configurada. Acesse Tainacan > Extrator IA para configurar.', 'tainacan-chatgpt'));
        }

        // Verifica consentimento
        if (!\Tainacan_ChatGPT::has_consent()) {
            return new \WP_Error('no_consent', __('Consentimento necessário para usar funcionalidades de IA.', 'tainacan-chatgpt'));
        }

        $file_path = get_attached_file($attachment_id);
        $mime_type = get_post_mime_type($attachment_id);

        if (!$file_path) {
            return new \WP_Error(
                'file_not_found',
                __('Caminho do arquivo não encontrado no WordPress. O anexo pode ter sido removido.', 'tainacan-chatgpt')
            );
        }

        if (!file_exists($file_path)) {
            // Tenta caminho alternativo (pode ter mudado de servidor)
            $upload_dir = wp_upload_dir();
            $relative_path = str_replace($upload_dir['basedir'], '', $file_path);

            return new \WP_Error(
                'file_not_found',
                sprintf(
                    __('O arquivo físico não existe no servidor. Esperado em: %s', 'tainacan-chatgpt'),
                    $file_path
                )
            );
        }

        // Detecta coleção se não foi definida
        if (!$this->collection_id && $this->item_id) {
            $this->collection_id = $this->get_item_collection($this->item_id);
        }

        $result = [];
        $document_type = 'unknown';
        $extraction_method = null;

        // Análise baseada no tipo
        if (in_array($mime_type, $this->supported_image_types)) {
            $document_type = 'image';

            // Extrai EXIF primeiro
            if ($include_exif && ($this->options['extract_exif'] ?? true)) {
                $exif_data = $this->exif_extractor->extract($file_path);
                if (!empty($exif_data['data'])) {
                    $result['exif'] = $exif_data['data'];
                    $result['exif_summary'] = $this->exif_extractor->get_summary($exif_data);
                }
            }

            // Análise com IA
            $ai_result = $this->analyze_image($attachment_id, $file_path, $mime_type);
            $extraction_method = 'vision';

        } elseif ($mime_type === 'application/pdf') {
            $document_type = 'pdf';
            $pdf_result = $this->analyze_pdf_smart($file_path);
            $ai_result = $pdf_result['result'];
            $extraction_method = $pdf_result['method'];

        } elseif (in_array($mime_type, ['text/plain', 'text/html'])) {
            $document_type = 'text';
            $ai_result = $this->analyze_text(file_get_contents($file_path));
            $extraction_method = 'text';

        } else {
            return new \WP_Error(
                'unsupported_type',
                sprintf(__('Tipo de arquivo não suportado: %s', 'tainacan-chatgpt'), $mime_type)
            );
        }

        // Verifica erro na análise IA
        if (is_wp_error($ai_result)) {
            // Log do erro
            $this->logger->log([
                'user_id' => get_current_user_id(),
                'item_id' => $this->item_id,
                'collection_id' => $this->collection_id,
                'attachment_id' => $attachment_id,
                'document_type' => $document_type,
                'model' => $this->options['model'] ?? 'gpt-4o',
                'status' => 'error',
                'error_message' => $ai_result->get_error_message(),
            ]);

            return $ai_result;
        }

        // Combina resultados
        $result['ai_metadata'] = $ai_result['metadata'] ?? $ai_result;
        $result['document_type'] = $document_type;
        $result['extraction_method'] = $extraction_method;
        $result['tokens_used'] = $ai_result['usage']['total_tokens'] ?? 0;
        $result['model'] = $this->options['model'] ?? 'gpt-4o';
        $result['analyzed_at'] = current_time('mysql');

        // Log de sucesso
        $this->logger->log([
            'user_id' => get_current_user_id(),
            'item_id' => $this->item_id,
            'collection_id' => $this->collection_id,
            'attachment_id' => $attachment_id,
            'document_type' => $document_type,
            'model' => $result['model'],
            'tokens_used' => $result['tokens_used'],
            'cost' => $this->calculate_cost($result['tokens_used'], $result['model']),
            'status' => 'success',
        ]);

        return $result;
    }

    /**
     * Análise inteligente de PDF com múltiplos fallbacks
     */
    private function analyze_pdf_smart(string $file_path): array {
        // Método 1: Extração de texto (mais rápido e barato)
        $text = $this->extract_pdf_text($file_path);

        if (!is_wp_error($text) && !empty(trim($text)) && strlen(trim($text)) > 100) {
            // Texto suficiente encontrado
            $result = $this->analyze_text($text);
            return [
                'result' => $result,
                'method' => 'text_extraction',
            ];
        }

        // Método 2: Conversão para imagem e análise visual
        $visual_result = $this->analyze_pdf_visually($file_path);

        if (!is_wp_error($visual_result)) {
            return [
                'result' => $visual_result,
                'method' => 'visual_analysis',
            ];
        }

        // Se ambos falharam, retorna erro mais informativo
        $error_msg = __('Não foi possível analisar o PDF. ', 'tainacan-chatgpt');

        if (is_wp_error($text)) {
            $error_msg .= $text->get_error_message() . ' ';
        } else {
            $error_msg .= __('O PDF não contém texto extraível. ', 'tainacan-chatgpt');
        }

        if (is_wp_error($visual_result)) {
            $error_msg .= $visual_result->get_error_message();
        }

        return [
            'result' => new \WP_Error('pdf_analysis_failed', trim($error_msg)),
            'method' => 'failed',
        ];
    }

    /**
     * Analisa PDF visualmente (para PDFs escaneados)
     */
    private function analyze_pdf_visually(string $file_path): array|\WP_Error {
        try {
            $converter = new PdfToImage();
            $converter->setDpi(150)
                      ->setQuality(85)
                      ->setMaxPages(3); // Limita a 3 páginas para não estourar contexto

            $images = $converter->convert($file_path);

            if (empty($images)) {
                return new \WP_Error('conversion_failed', __('Não foi possível converter o PDF para imagem. Instale Imagick ou Ghostscript.', 'tainacan-chatgpt'));
            }

            // Prepara conteúdo para API com múltiplas imagens
            $content = [];

            // Obtém prompt
            $prompt = $this->collection_id
                ? $this->collection_prompts->get_effective_prompt($this->collection_id, 'document')
                : ($this->options['default_document_prompt'] ?? '');

            if (empty($prompt)) {
                return new \WP_Error('no_prompt', __('Nenhum prompt configurado para análise de documentos.', 'tainacan-chatgpt'));
            }

            $pageCount = count($images);
            $promptWithContext = $prompt . "\n\n" . sprintf(
                __('O documento tem %d página(s). Analise o conteúdo visual de todas as páginas fornecidas.', 'tainacan-chatgpt'),
                $pageCount
            );

            $content[] = [
                'type' => 'text',
                'text' => $promptWithContext,
            ];

            // Adiciona cada página como imagem
            foreach ($images as $image) {
                $content[] = [
                    'type' => 'image_url',
                    'image_url' => [
                        'url' => "data:{$image['mime']};base64,{$image['base64']}",
                        'detail' => 'high',
                    ],
                ];
            }

            $messages = [
                [
                    'role' => 'user',
                    'content' => $content,
                ],
            ];

            $result = $this->call_api($messages);

            // Limpa arquivos temporários
            foreach ($images as $image) {
                if (isset($image['path']) && file_exists($image['path'])) {
                    @unlink($image['path']);
                }
            }

            return $result;

        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[TainacanChatGPT] Visual analysis error: ' . $e->getMessage());
            }
            return new \WP_Error('visual_analysis_error', $e->getMessage());
        }
    }

    /**
     * Analisa imagem
     */
    private function analyze_image(int $attachment_id, string $file_path, string $mime_type): array|\WP_Error {
        // Tenta usar URL pública, senão converte para base64
        $image_url = wp_get_attachment_url($attachment_id);
        $image_data = null;

        if (!$image_url || !$this->is_url_accessible($image_url)) {
            // Converte para base64
            $image_content = @file_get_contents($file_path);

            if ($image_content === false) {
                return new \WP_Error('file_read_error', __('Não foi possível ler o arquivo de imagem.', 'tainacan-chatgpt'));
            }

            $base64 = base64_encode($image_content);

            // Valida que o base64 foi gerado corretamente
            if (empty($base64)) {
                return new \WP_Error('base64_error', __('Erro ao codificar imagem em base64.', 'tainacan-chatgpt'));
            }

            $image_data = "data:{$mime_type};base64,{$base64}";
        }

        // Obtém prompt (customizado ou padrão)
        $prompt = $this->collection_id
            ? $this->collection_prompts->get_effective_prompt($this->collection_id, 'image')
            : ($this->options['default_image_prompt'] ?? '');

        if (empty($prompt)) {
            return new \WP_Error('no_prompt', __('Nenhum prompt configurado para análise de imagens.', 'tainacan-chatgpt'));
        }

        $messages = [
            [
                'role' => 'user',
                'content' => [
                    [
                        'type' => 'text',
                        'text' => $prompt,
                    ],
                    [
                        'type' => 'image_url',
                        'image_url' => [
                            'url' => $image_data ?? $image_url,
                            'detail' => 'high',
                        ],
                    ],
                ],
            ],
        ];

        return $this->call_api($messages);
    }

    /**
     * Extrai texto de PDF usando múltiplos métodos
     */
    private function extract_pdf_text(string $file_path): string|\WP_Error {
        // Método 1: Parser embutido do plugin
        try {
            $parser = new PdfParser();
            $text = $parser->parseFile($file_path)->getText();

            if (!empty(trim($text))) {
                return $text;
            }
        } catch (\Throwable $e) {
            // Log do erro se debug estiver ativo
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[TainacanChatGPT] PdfParser error: ' . $e->getMessage());
            }
            // Continua para próximo método
        }

        // Método 2: smalot/pdfparser (se instalado via Composer)
        if (class_exists('\Smalot\PdfParser\Parser')) {
            try {
                $parser = new \Smalot\PdfParser\Parser();
                $pdf = $parser->parseFile($file_path);
                $text = $pdf->getText();

                if (!empty(trim($text))) {
                    return $text;
                }
            } catch (\Throwable $e) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('[TainacanChatGPT] Smalot PdfParser error: ' . $e->getMessage());
                }
                // Continua para próximo método
            }
        }

        // Método 3: pdftotext (poppler-utils) - Linux/Mac
        if (function_exists('shell_exec') && !$this->is_windows()) {
            $escaped_path = escapeshellarg($file_path);
            $output = @shell_exec("pdftotext {$escaped_path} - 2>/dev/null");

            if (!empty($output)) {
                return $output;
            }
        }

        // Método 4: pdftotext no Windows (se disponível)
        if ($this->is_windows() && function_exists('shell_exec')) {
            $escaped_path = escapeshellarg($file_path);

            // Tenta caminhos comuns no Windows
            $paths = [
                'pdftotext',
                'C:\\Program Files\\poppler\\bin\\pdftotext.exe',
                'C:\\poppler\\bin\\pdftotext.exe',
            ];

            foreach ($paths as $pdftotext) {
                $output = @shell_exec("\"{$pdftotext}\" {$escaped_path} - 2>nul");
                if (!empty($output)) {
                    return $output;
                }
            }
        }

        // Método 5: Extração básica via regex
        $text = $this->basic_pdf_text_extract($file_path);
        if (!empty(trim($text))) {
            return $text;
        }

        return new \WP_Error(
            'pdf_extract_failed',
            __('Não foi possível extrair texto do PDF. O documento pode ser uma imagem escaneada.', 'tainacan-chatgpt')
        );
    }

    /**
     * Extração básica de texto de PDF
     */
    private function basic_pdf_text_extract(string $file_path): string {
        $content = file_get_contents($file_path);
        $text = '';

        // Procura por streams de texto
        if (preg_match_all('/stream\s*\n(.*?)\nendstream/s', $content, $matches)) {
            foreach ($matches[1] as $stream) {
                // Tenta decodificar
                $decoded = @gzuncompress($stream);
                if ($decoded === false) {
                    $decoded = @gzinflate($stream);
                }
                if ($decoded === false) {
                    $decoded = $stream;
                }

                // Extrai texto entre parênteses
                if (preg_match_all('/\((.*?)\)/', $decoded, $text_matches)) {
                    $text .= implode(' ', $text_matches[1]) . ' ';
                }
            }
        }

        return trim($text);
    }

    /**
     * Analisa texto
     */
    private function analyze_text(string $text): array|\WP_Error {
        // Sanitiza o texto para UTF-8 válido
        $text = $this->sanitize_utf8_string($text);

        // Limita tamanho do texto
        $max_chars = 32000;
        $truncated = false;

        if (mb_strlen($text, 'UTF-8') > $max_chars) {
            $text = mb_substr($text, 0, $max_chars, 'UTF-8');
            $truncated = true;
        }

        // Obtém prompt
        $prompt = $this->collection_id
            ? $this->collection_prompts->get_effective_prompt($this->collection_id, 'document')
            : ($this->options['default_document_prompt'] ?? '');

        if (empty($prompt)) {
            return new \WP_Error('no_prompt', __('Nenhum prompt configurado para análise de documentos.', 'tainacan-chatgpt'));
        }

        $full_prompt = $prompt . "\n\n---\n\n**Documento:**\n\n" . $text;

        if ($truncated) {
            $full_prompt .= "\n\n[Documento truncado devido ao tamanho]";
        }

        $messages = [
            [
                'role' => 'user',
                'content' => $full_prompt,
            ],
        ];

        return $this->call_api($messages);
    }

    /**
     * Chama API OpenAI
     */
    private function call_api(array $messages): array|\WP_Error {
        $model = $this->options['model'] ?? 'gpt-4o';

        // Sanitiza mensagens para garantir UTF-8 válido
        $messages = $this->sanitize_messages_utf8($messages);

        $body = [
            'model' => $model,
            'messages' => $messages,
            'max_tokens' => (int) ($this->options['max_tokens'] ?? 2000),
            'temperature' => (float) ($this->options['temperature'] ?? 0.1),
            'response_format' => ['type' => 'json_object'],
        ];

        // Codifica o body para JSON com tratamento de erro
        $json_body = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);

        if ($json_body === false) {
            $json_error = json_last_error_msg();
            return new \WP_Error(
                'json_encode_error',
                sprintf(__('Erro ao preparar dados para API: %s', 'tainacan-chatgpt'), $json_error)
            );
        }

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->options['api_key'],
                'Content-Type' => 'application/json',
            ],
            'body' => $json_body,
            'timeout' => (int) ($this->options['request_timeout'] ?? 120),
        ]);

        if (is_wp_error($response)) {
            return new \WP_Error(
                'api_connection_error',
                sprintf(__('Erro de conexão com a API: %s', 'tainacan-chatgpt'), $response->get_error_message())
            );
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            $error_msg = $body['error']['message'] ?? __('Erro desconhecido na API OpenAI', 'tainacan-chatgpt');

            // Mensagens de erro mais amigáveis
            if ($code === 401) {
                $error_msg = __('Chave API inválida ou expirada. Verifique suas configurações.', 'tainacan-chatgpt');
            } elseif ($code === 429) {
                $error_msg = __('Limite de requisições excedido. Aguarde alguns minutos.', 'tainacan-chatgpt');
            } elseif ($code === 500 || $code === 503) {
                $error_msg = __('Serviço da OpenAI temporariamente indisponível. Tente novamente.', 'tainacan-chatgpt');
            }

            return new \WP_Error('api_error', $error_msg);
        }

        $content = $body['choices'][0]['message']['content'] ?? '';

        if (empty($content)) {
            return new \WP_Error('empty_response', __('Resposta vazia da API.', 'tainacan-chatgpt'));
        }

        // Parse JSON
        $metadata = $this->parse_json_response($content);

        if ($metadata === null) {
            return new \WP_Error(
                'json_parse_error',
                __('Erro ao interpretar resposta da API. O formato retornado não é JSON válido.', 'tainacan-chatgpt')
            );
        }

        return [
            'metadata' => $metadata,
            'usage' => $body['usage'] ?? [],
            'model' => $model,
        ];
    }

    /**
     * Parse resposta JSON da API
     */
    private function parse_json_response(string $content): ?array {
        // Tenta parse direto
        $metadata = json_decode($content, true);

        if (json_last_error() === JSON_ERROR_NONE) {
            return $metadata;
        }

        // Tenta extrair JSON do texto
        if (preg_match('/\{[\s\S]*\}/', $content, $matches)) {
            $metadata = json_decode($matches[0], true);

            if (json_last_error() === JSON_ERROR_NONE) {
                return $metadata;
            }
        }

        // Tenta remover markdown code blocks
        $content = preg_replace('/```json?\s*/', '', $content);
        $content = preg_replace('/```\s*/', '', $content);
        $content = trim($content);

        $metadata = json_decode($content, true);

        if (json_last_error() === JSON_ERROR_NONE) {
            return $metadata;
        }

        return null;
    }

    /**
     * Verifica se URL é acessível
     */
    private function is_url_accessible(string $url): bool {
        $response = wp_remote_head($url, ['timeout' => 5]);

        if (is_wp_error($response)) {
            return false;
        }

        return wp_remote_retrieve_response_code($response) === 200;
    }

    /**
     * Verifica se é Windows
     */
    private function is_windows(): bool {
        return strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
    }

    /**
     * Obtém coleção de um item
     */
    private function get_item_collection(int $item_id): ?int {
        if (!class_exists('\Tainacan\Repositories\Items')) {
            return null;
        }

        $items_repo = \Tainacan\Repositories\Items::get_instance();
        $item = $items_repo->fetch($item_id);

        if ($item && method_exists($item, 'get_collection_id')) {
            return $item->get_collection_id();
        }

        return null;
    }

    /**
     * Calcula custo estimado
     */
    private function calculate_cost(int $tokens, string $model): float {
        // Preços aproximados por 1000 tokens (entrada + saída)
        $prices = [
            'gpt-4o' => 0.005,
            'gpt-4o-mini' => 0.00015,
            'gpt-4-turbo' => 0.01,
            'gpt-4' => 0.03,
            'gpt-3.5-turbo' => 0.0005,
        ];

        $price_per_1k = $prices[$model] ?? 0.005;

        return round(($tokens / 1000) * $price_per_1k, 6);
    }

    /**
     * Sanitiza mensagens para garantir UTF-8 válido
     */
    private function sanitize_messages_utf8(array $messages): array {
        return array_map(function ($message) {
            if (is_array($message)) {
                return $this->sanitize_messages_utf8($message);
            }

            if (is_string($message)) {
                return $this->sanitize_utf8_string($message);
            }

            return $message;
        }, $messages);
    }

    /**
     * Sanitiza uma string para UTF-8 válido
     */
    private function sanitize_utf8_string(string $string): string {
        // Se já é UTF-8 válido, retorna como está
        if (mb_check_encoding($string, 'UTF-8')) {
            // Remove caracteres de controle inválidos (exceto newline, tab, etc.)
            $string = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $string);
            return $string;
        }

        // Tenta converter de diferentes encodings
        $encodings = ['ISO-8859-1', 'Windows-1252', 'ASCII'];

        foreach ($encodings as $encoding) {
            $converted = @mb_convert_encoding($string, 'UTF-8', $encoding);
            if ($converted !== false && mb_check_encoding($converted, 'UTF-8')) {
                return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $converted);
            }
        }

        // Fallback: remove caracteres não-UTF-8
        $string = mb_convert_encoding($string, 'UTF-8', 'UTF-8');

        // Remove caracteres inválidos
        $string = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $string);

        // Remove sequências UTF-8 inválidas
        $string = preg_replace('/[\x80-\xFF](?![\x80-\xBF])|(?<![\xC0-\xFF])[\x80-\xBF]/', '', $string);

        return $string;
    }

    /**
     * Obtém tipos de arquivo suportados
     */
    public function get_supported_types(): array {
        return [
            'images' => $this->supported_image_types,
            'documents' => $this->supported_document_types,
        ];
    }

    /**
     * Verifica se tipo é suportado
     */
    public function is_supported(string $mime_type): bool {
        return in_array($mime_type, array_merge($this->supported_image_types, $this->supported_document_types));
    }

    /**
     * Verifica capacidades disponíveis
     */
    public static function get_capabilities(): array {
        $capabilities = [
            'text_extraction' => [
                'name' => __('Extração de Texto', 'tainacan-chatgpt'),
                'available' => true,
                'methods' => ['built_in_parser'],
            ],
            'visual_analysis' => [
                'name' => __('Análise Visual (PDF)', 'tainacan-chatgpt'),
                'available' => false,
                'methods' => [],
            ],
            'exif_extraction' => [
                'name' => __('Extração EXIF', 'tainacan-chatgpt'),
                'available' => function_exists('exif_read_data'),
            ],
        ];

        // Verifica backends de conversão de imagem
        $backends = PdfToImage::getAvailableBackends();

        if (!empty($backends['imagick']['available']) && !empty($backends['imagick']['supports_pdf'])) {
            $capabilities['visual_analysis']['available'] = true;
            $capabilities['visual_analysis']['methods'][] = 'imagick';
        }

        if (!empty($backends['ghostscript']['available'])) {
            $capabilities['visual_analysis']['available'] = true;
            $capabilities['visual_analysis']['methods'][] = 'ghostscript';
        }

        // Verifica bibliotecas externas de PDF
        if (class_exists('\Smalot\PdfParser\Parser')) {
            $capabilities['text_extraction']['methods'][] = 'smalot_pdfparser';
        }

        // Verifica pdftotext
        if (function_exists('shell_exec')) {
            $output = @shell_exec('pdftotext -v 2>&1');
            if ($output && stripos($output, 'pdftotext') !== false) {
                $capabilities['text_extraction']['methods'][] = 'pdftotext';
            }
        }

        return $capabilities;
    }
}
