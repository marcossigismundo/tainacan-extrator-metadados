<?php
namespace Tainacan\ChatGPT;

use Smalot\PdfParser\Parser;

/**
 * Classe responsável pela análise de documentos
 */
class DocumentAnalyzer {
    /**
     * API do ChatGPT
     */
    private $api;
    
    /**
     * Cache para resultados
     */
    private $cache;
    
    /**
     * Construtor
     */
    public function __construct() {
        $this->api = new API();
        $this->cache = new Cache();
    }
    
    /**
     * Analisa um item do Tainacan
     * 
     * @param int $item_id ID do item
     * @param bool $force_refresh Forçar atualização do cache
     * @param string $analysis_type Tipo de análise (auto, pdf, image)
     * @return array Resultado da análise
     */
    public function analyze_item($item_id, $force_refresh = false, $analysis_type = 'auto') {
        error_log('Debug: analyze_item iniciado para item ' . $item_id);
        
        // Verifica cache primeiro se não for forçada atualização
        if (!$force_refresh) {
            $cached_result = $this->cache->get("item_{$item_id}");
            if ($cached_result !== false) {
                return array(
                    'success' => true,
                    'data' => $cached_result,
                    'from_cache' => true
                );
            }
        }
        
        // Obtém detalhes do item
        $item = \Tainacan\Repositories\Items::get_instance()->fetch($item_id);
        
        if (!$item) {
            return array(
                'success' => false,
                'message' => __('Item não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        // Busca o documento anexado ao item
        $document_data = $this->get_document_from_item($item);
        
        if (!$document_data['success']) {
            return $document_data;
        }
        
        // Se o tipo de análise for auto, detecta automaticamente
        if ($analysis_type === 'auto') {
            $analysis_type = $document_data['type'];
        }
        
        // Obtém opções do plugin
        $options = get_option('tainacan_chatgpt_options', array());
        $prompt = ($analysis_type === 'image') ? 
            $options['image_prompt'] : 
            $options['text_prompt'];
        
        // Analisa documento com o tipo apropriado
        if ($analysis_type === 'image') {
            $result = $this->analyze_image($document_data['attachment_id'], $prompt);
        } elseif ($analysis_type === 'pdf') {
            $result = $this->analyze_pdf($document_data['attachment_id'], $prompt);
        } else {
            $result = $this->analyze_document($document_data['attachment_id'], $prompt);
        }
        
        // Se análise for bem-sucedida, armazena em cache
        if ($result['success']) {
            $this->cache->set("item_{$item_id}", $result['data']);
        }
        
        return $result;
    }
    
/**
 * Analisa um anexo diretamente
 * 
 * @param int $attachment_id ID do anexo
 * @param bool $force_refresh Forçar atualização do cache
 * @param string $analysis_type Tipo de análise (auto, pdf, image)
 * @return array Resultado da análise
 */
public function analyze_attachment($attachment_id, $force_refresh = false, $analysis_type = 'auto') {
    error_log('Debug: analyze_attachment iniciado para ID ' . $attachment_id);
    
    // Verifica cache primeiro se não for forçada atualização
    if (!$force_refresh) {
        $cached_result = $this->cache->get("attachment_{$attachment_id}");
        if ($cached_result !== false) {
            return array(
                'success' => true,
                'data' => $cached_result,
                'from_cache' => true
            );
        }
    }
    
    // VERIFICAÇÕES MELHORADAS DO ANEXO
    
    // Método 1: Verificação padrão do WordPress
    $attachment = get_post($attachment_id);
    error_log('Debug: Post existe? ' . ($attachment ? 'SIM : ' . $attachment->post_title : 'NÃO'));
    
    // Método 2: Tentativa pelo Tainacan (em caso de IDs de item vs anexo)
    if (!$attachment || $attachment->post_type !== 'attachment') {
        // Verificar se é um ID de item do Tainacan
        if (class_exists('\Tainacan\Repositories\Items')) {
            $item = \Tainacan\Repositories\Items::get_instance()->fetch($attachment_id);
            if ($item) {
                // Tentar obter documento do item
                $document_id = get_post_meta($attachment_id, 'document_id', true);
                if ($document_id) {
                    $attachment = get_post($document_id);
                    $attachment_id = $document_id;
                    error_log('Debug: Usando documento do item Tainacan: ' . $document_id);
                }
            }
        }
    }
    
    // Método 3: Busca pelo banco de dados diretamente
    if (!$attachment || $attachment->post_type !== 'attachment') {
        global $wpdb;
        $alt_attachment_id = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM $wpdb->posts WHERE ID = %d OR post_parent = %d AND post_type = 'attachment'",
            $attachment_id, $attachment_id
        ));
        
        if ($alt_attachment_id) {
            $attachment = get_post($alt_attachment_id);
            $attachment_id = $alt_attachment_id;
            error_log('Debug: Encontrado anexo alternativo: ' . $alt_attachment_id);
        }
    }
    
    // Verificação final
    if (!$attachment || $attachment->post_type !== 'attachment') {
        error_log('Debug: Anexo não encontrado para ID: ' . $attachment_id);
        return array(
            'success' => false,
            'message' => __('Anexo não encontrado ou ID inválido.', 'tainacan-chatgpt')
        );
    }
    
    // RESTO DO CÓDIGO IGUAL AO ORIGINAL
    
    // Verificar se é um arquivo do Tainacan
    $mime_type = get_post_mime_type($attachment_id);
    error_log('Debug: MIME Type: ' . $mime_type);
    
    // Tentar obter caminho do arquivo - método WordPress
    $file_path = get_attached_file($attachment_id);
    error_log('Debug: WordPress path: ' . $file_path);
    
    // Se não encontrou, tente caminho alternativo para Tainacan
    if (empty($file_path) || !file_exists($file_path)) {
        // Construir caminho a partir da URL
        $upload_dir = wp_upload_dir();
        $file_url = wp_get_attachment_url($attachment_id);
        
        if ($file_url) {
            $file_rel_path = str_replace($upload_dir['baseurl'], '', $file_url);
            $alt_path = $upload_dir['basedir'] . $file_rel_path;
            $alt_path = str_replace('/', DIRECTORY_SEPARATOR, $alt_path);
            
            error_log('Debug: URL alternativa: ' . $file_url);
            error_log('Debug: Caminho alternativo: ' . $alt_path);
            
            if (file_exists($alt_path)) {
                $file_path = $alt_path;
                error_log('Debug: Usando caminho alternativo');
            }
        }
    }
    
    // Verificar se o arquivo existe
    if (empty($file_path) || !file_exists($file_path)) {
        error_log('Debug: Arquivo não encontrado: ' . $file_path);
        return array(
            'success' => false,
            'message' => __('Arquivo não encontrado no servidor.', 'tainacan-chatgpt')
        );
    }
    
    // Se o tipo de análise for auto, detecta automaticamente
    if ($analysis_type === 'auto') {
        if (strpos($mime_type, 'image/') === 0) {
            $analysis_type = 'image';
        } elseif ($mime_type === 'application/pdf') {
            $analysis_type = 'pdf';
        } else {
            $analysis_type = 'document';
        }
    }
    error_log('Debug: Tipo de análise: ' . $analysis_type);
    
    // Obtém opções do plugin
    $options = get_option('tainacan_chatgpt_options', array());
    $prompt = ($analysis_type === 'image') ? 
        $options['image_prompt'] : 
        $options['text_prompt'];
    
    // Analisa com o tipo apropriado
    if ($analysis_type === 'image') {
        $result = $this->analyze_image($attachment_id, $prompt);
    } elseif ($analysis_type === 'pdf') {
        $result = $this->analyze_pdf($attachment_id, $prompt);
    } else {
        $result = $this->analyze_document($attachment_id, $prompt);
    }
    
    // Se análise for bem-sucedida, armazena em cache
    if ($result['success']) {
        $this->cache->set("attachment_{$attachment_id}", $result['data']);
    }
    
    error_log('Debug: resultado da análise: ' . json_encode($result));
    return $result;
}
    
    /**
     * Analisa um PDF usando a biblioteca smalot/pdfparser
     * 
     * @param int $attachment_id ID do anexo
     * @param string $user_prompt Prompt personalizado
     * @return array Resultado da análise com evidências
     */
    public function analyze_pdf($attachment_id, $user_prompt) {
        error_log('Debug: analyze_pdf iniciado para ID ' . $attachment_id);
        
        // Verifica se a biblioteca PDF Parser está disponível
        if (!class_exists('\\Smalot\\PdfParser\\Parser')) {
            // Tenta carregá-la via Composer autoload
            if (file_exists(TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'vendor/autoload.php')) {
                require_once TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'vendor/autoload.php';
            }
            
            // Verifica novamente
            if (!class_exists('\\Smalot\\PdfParser\\Parser')) {
                error_log('Debug: PDF Parser não está disponível');
                return array(
                    'success' => false,
                    'message' => __('A biblioteca PDF Parser não está disponível. Execute composer install.', 'tainacan-chatgpt')
                );
            }
        }
        
        // Verifica se o anexo existe
        $attachment = get_post($attachment_id);
        if (!$attachment) {
            error_log('Debug: Anexo não encontrado: ' . $attachment_id);
            return array(
                'success' => false,
                'message' => __('Anexo não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        // Obtém o caminho do arquivo usando o mesmo método de analyze_attachment
        $file_path = get_attached_file($attachment_id);
        
        // Se não encontrou, tente caminho alternativo para Tainacan
        if (empty($file_path) || !file_exists($file_path)) {
            // Construir caminho a partir da URL
            $upload_dir = wp_upload_dir();
            $file_url = wp_get_attachment_url($attachment_id);
            
            if ($file_url) {
                $file_rel_path = str_replace($upload_dir['baseurl'], '', $file_url);
                $alt_path = $upload_dir['basedir'] . $file_rel_path;
                $alt_path = str_replace('/', DIRECTORY_SEPARATOR, $alt_path);
                
                error_log('Debug: [PDF] URL alternativa: ' . $file_url);
                error_log('Debug: [PDF] Caminho alternativo: ' . $alt_path);
                
                if (file_exists($alt_path)) {
                    $file_path = $alt_path;
                    error_log('Debug: [PDF] Usando caminho alternativo');
                }
            }
        }
        
        if (!$file_path || !file_exists($file_path)) {
            error_log('Debug: Arquivo PDF não encontrado: ' . $file_path);
            return array(
                'success' => false,
                'message' => __('Arquivo PDF não encontrado.', 'tainacan-chatgpt')
            );
        }
        error_log('Debug: Arquivo PDF encontrado: ' . $file_path);
        
        // Obtém chunks de texto do PDF
        try {
            $chunks = $this->get_pdf_chunks($file_path);
            error_log('Debug: Chunks obtidos: ' . count($chunks));
            
            if (empty($chunks)) {
                return array(
                    'success' => false,
                    'message' => __('Não foi possível extrair texto do PDF.', 'tainacan-chatgpt')
                );
            }
        } catch (\Exception $e) {
            error_log('Debug: Erro ao processar PDF: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => __('Erro ao processar o PDF: ', 'tainacan-chatgpt') . $e->getMessage()
            );
        }
        
        // Extrai campos do prompt
        $fields = $this->extract_fields_from_prompt($user_prompt);
        error_log('Debug: Campos extraídos: ' . json_encode($fields));
        
        // Cria esquema JSON para chamada de função
        $json_schema = $this->create_json_schema($fields);
        
        // Fase 1: Extração de metadados
        error_log('Debug: Iniciando extração de metadados...');
        $metadata = $this->extract_metadata_from_chunks($chunks, $user_prompt, $json_schema);
        
        if (empty($metadata) || !is_array($metadata)) {
            return array(
                'success' => false,
                'message' => __('Falha ao extrair metadados do PDF.', 'tainacan-chatgpt')
            );
        }
        error_log('Debug: Metadados extraídos: ' . json_encode($metadata));
        
        // Fase 2: Verificação de cada campo
        error_log('Debug: Iniciando verificação de campos...');
        $verified_metadata = $this->verify_metadata_fields($metadata, $chunks, $fields);
        
        // Fase 3: Validação dos dados
        error_log('Debug: Iniciando validação de dados...');
        $validated_metadata = $this->validate_metadata($verified_metadata);
        
        return array(
            'success' => true,
            'data' => $validated_metadata
        );
    }
    
    /**
     * Obtém chunks de texto de um arquivo PDF
     * 
     * @param string $file_path Caminho para o arquivo PDF
     * @return array Array de chunks de texto
     */
    public function get_pdf_chunks($file_path) {
        try {
            error_log('Debug: Extraindo texto do PDF: ' . $file_path);
            $parser = new \Smalot\PdfParser\Parser();
            $pdf = $parser->parseFile($file_path);
            $text = trim($pdf->getText());
            error_log('Debug: Tamanho do texto extraído: ' . strlen($text) . ' caracteres');
            
            // Divide em chunks de aproximadamente 1500 caracteres
            return $this->chunk_text($text, 1500);
        } catch (\Exception $e) {
            error_log('Debug: Erro ao extrair texto do PDF: ' . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Divide texto em chunks de tamanho aproximado
     * 
     * @param string $text Texto para dividir
     * @param int $size Tamanho aproximado de cada chunk
     * @return array Array de chunks de texto
     */
    private function chunk_text($text, $size) {
        // Primeiro divide por parágrafos
        $paragraphs = explode("\n\n", $text);
        $chunks = array();
        $current_chunk = '';
        
        foreach ($paragraphs as $paragraph) {
            $paragraph = trim($paragraph);
            if (empty($paragraph)) continue;
            
            // Se o parágrafo for muito grande, divide por pontos
            if (strlen($paragraph) > $size) {
                $sentences = preg_split('/(?<=[.!?])\s+/', $paragraph);
                
                foreach ($sentences as $sentence) {
                    if (strlen($current_chunk) + strlen($sentence) <= $size) {
                        $current_chunk .= ' ' . $sentence;
                    } else {
                        if (!empty($current_chunk)) {
                            $chunks[] = trim($current_chunk);
                        }
                        
                        // Se a frase for maior que o tamanho máximo, divide por palavras
                        if (strlen($sentence) > $size) {
                            $words = preg_split('/\s+/', $sentence);
                            $current_chunk = '';
                            
                            foreach ($words as $word) {
                                if (strlen($current_chunk) + strlen($word) + 1 <= $size) {
                                    $current_chunk .= ' ' . $word;
                                } else {
                                    if (!empty($current_chunk)) {
                                        $chunks[] = trim($current_chunk);
                                    }
                                    $current_chunk = $word;
                                }
                            }
                        } else {
                            $current_chunk = $sentence;
                        }
                    }
                }
            } else {
                if (strlen($current_chunk) + strlen($paragraph) + 2 <= $size) {
                    $current_chunk .= "\n\n" . $paragraph;
                } else {
                    if (!empty($current_chunk)) {
                        $chunks[] = trim($current_chunk);
                    }
                    $current_chunk = $paragraph;
                }
            }
        }
        
        // Adiciona o último chunk se não estiver vazio
        if (!empty($current_chunk)) {
            $chunks[] = trim($current_chunk);
        }
        
        error_log('Debug: Texto dividido em ' . count($chunks) . ' chunks');
        return $chunks;
    }
    
    /**
     * Extrai campos de metadados do prompt do usuário
     * 
     * @param string $prompt Prompt do usuário
     * @return array Lista de campos para extrair
     */
    private function extract_fields_from_prompt($prompt) {
        $fields = array();
        
        // Lista de campos comuns para buscar no prompt
        $common_fields = array(
            'título', 'titulo', 'title',
            'autor', 'autores', 'author', 'authors',
            'data', 'date', 'ano', 'year',
            'resumo', 'abstract', 'summary',
            'palavras-chave', 'keywords',
            'metodologia', 'methodology',
            'instituição', 'institution',
            'área', 'area', 'field',
            'técnica', 'tecnica', 'technique',
            'dimensões', 'dimensoes', 'dimensions',
            'descrição', 'descricao', 'description',
            'estado', 'state', 'condition'
        );
        
        // Tenta encontrar campos no formato "extraia X, Y, Z"
        if (preg_match('/extraia\s+(?:os\s+seguintes\s+)?(?:metadados|dados|campos|informações)?:?\s*([\w\s,\-\(\)]+)(?:\.|\n|$)/i', $prompt, $matches)) {
            $extracted_text = $matches[1];
            $extracted_fields = preg_split('/[,\s]+e\s+|[,\s]+ou\s+|[,\s]+/', $extracted_text);
            
            foreach ($extracted_fields as $field) {
                $field = trim($field);
                if (!empty($field)) {
                    $fields[] = $field;
                }
            }
        }
        
        // Se não encontrou campos específicos, busca campos comuns no prompt
        if (empty($fields)) {
            foreach ($common_fields as $field) {
                if (stripos($prompt, $field) !== false) {
                    $fields[] = $field;
                }
            }
        }
        
        // Campos básicos padrão se nada for encontrado
        if (empty($fields)) {
            $fields = array('título', 'autor', 'data', 'descrição');
        }
        
        return array_unique($fields);
    }
    
    /**
     * Cria esquema JSON para chamada de função
     * 
     * @param array $fields Lista de campos
     * @return array Esquema JSON
     */
    private function create_json_schema($fields) {
        $properties = array();
        
        foreach ($fields as $field) {
            $properties[$field] = array(
                'type' => 'string',
                'description' => sprintf(
                    __('O campo %s do documento, ou "INFORMAÇÃO AUSENTE" se não for encontrado.', 'tainacan-chatgpt'),
                    $field
                )
            );
        }
        
        return array(
            'name' => 'extract_metadata',
            'description' => __('Extrai metadados de um documento ou imagem', 'tainacan-chatgpt'),
            'parameters' => array(
                'type' => 'object',
                'properties' => $properties,
                'required' => array()
            )
        );
    }
    
    /**
     * Extrai metadados de chunks de texto usando a API OpenAI
     * 
     * @param array $chunks Chunks de texto
     * @param string $user_prompt Prompt do usuário
     * @param array $json_schema Esquema JSON para function calling
     * @return array Metadados extraídos
     */
    private function extract_metadata_from_chunks($chunks, $user_prompt, $json_schema) {
        $combined_text = '';
        $max_chars = 12000; // Limite para evitar limites de tokens
        
        // Combina chunks até o limite máximo de caracteres
        foreach ($chunks as $chunk) {
            if (strlen($combined_text) + strlen($chunk) < $max_chars) {
                $combined_text .= $chunk . "\n\n";
            } else {
                break;
            }
        }
        
        error_log('Debug: Tamanho do texto combinado: ' . strlen($combined_text) . ' caracteres');
        
        // Prepara mensagens para a API
        $messages = [
            [
                'role' => 'system',
                'content' => __('Você é um assistente especializado em análise de documentos e extração de metadados para acervos digitais. Responda apenas com valores explicitamente presentes no texto. Se não existir, retorne \'INFORMAÇÃO AUSENTE\'. Responda apenas em português do Brasil.', 'tainacan-chatgpt')
            ],
            [
                'role' => 'user',
                'content' => $user_prompt . "\n\nDocumento:\n" . $combined_text
            ]
        ];
        
        // Chama a API com function calling
        error_log('Debug: Enviando requisição para API...');
        $response = $this->api->send_function_request(
            $messages,
            [$json_schema],
            [
                'temperature' => 0,
                'max_tokens' => 1000
            ]
        );
        
        // Processa e retorna metadados
        if ($response['success'] && isset($response['data']) && is_array($response['data'])) {
            error_log('Debug: Resposta da API recebida com sucesso');
            return $response['data'];
        }
        
        error_log('Debug: Falha na resposta da API: ' . json_encode($response));
        return [];
    }
    
    /**
     * Verifica campos de metadados solicitando evidências do texto
     * 
     * @param array $metadata Metadados extraídos
     * @param array $chunks Chunks de texto
     * @param array $fields Lista de campos
     * @return array Metadados verificados com evidências
     */
    private function verify_metadata_fields($metadata, $chunks, $fields) {
        $verified_metadata = [
            'metadata' => $metadata,
            'evidence' => [],
            'needs_human_review' => false
        ];
        
        error_log('Debug: Verificando campos de metadados...');
        
        foreach ($metadata as $field => $value) {
            // Pula campos vazios ou ausentes
            if (empty($value) || $value === 'INFORMAÇÃO AUSENTE') {
                $verified_metadata['evidence'][$field] = null;
                continue;
            }
            
            // Busca evidência para este campo
            error_log('Debug: Buscando evidência para o campo: ' . $field);
            $evidence = $this->find_evidence_for_field($chunks, $field, $value);
            
            if (empty($evidence)) {
                // Marca para revisão humana se não encontrar evidência
                error_log('Debug: Nenhuma evidência encontrada para ' . $field);
                $verified_metadata['needs_human_review'] = true;
                $verified_metadata['evidence'][$field] = null;
            } else {
                error_log('Debug: Evidência encontrada para ' . $field);
                $verified_metadata['evidence'][$field] = $evidence;
            }
        }
        
        return $verified_metadata;
    }
    
    /**
     * Busca evidência para um campo em chunks de texto
     * 
     * @param array $chunks Chunks de texto
     * @param string $field Nome do campo
     * @param string $value Valor do campo
     * @return string|null Evidência encontrada ou null
     */
    private function find_evidence_for_field($chunks, $field, $value) {
        // Primeiro tenta encontrar o valor exato em algum chunk
        foreach ($chunks as $chunk) {
            if (stripos($chunk, $value) !== false) {
                // Extrai o contexto ao redor do valor (até 100 caracteres antes e depois)
                $pos = stripos($chunk, $value);
                $start = max(0, $pos - 100);
                $length = min(strlen($chunk) - $start, strlen($value) + 200);
                $context = substr($chunk, $start, $length);
                
                return $context;
            }
        }
        
        // Se não encontrar o valor exato, pergunta à API onde está a evidência
        $json_schema = [
            'name' => 'find_evidence',
            'description' => __('Encontra evidência textual para um campo', 'tainacan-chatgpt'),
            'parameters' => [
                'type' => 'object',
                'properties' => [
                    'evidence' => [
                        'type' => 'string',
                        'description' => __('Trecho exato do texto que contém a informação, ou "EVIDÊNCIA AUSENTE" se não for encontrada', 'tainacan-chatgpt')
                    ]
                ],
                'required' => ['evidence']
            ]
        ];
        
        foreach ($chunks as $chunk) {
            $messages = [
                [
                    'role' => 'system',
                    'content' => __('Você é um assistente que encontra evidências textuais. Cite APENAS o trecho exato onde a informação aparece. Se não encontrar, responda "EVIDÊNCIA AUSENTE".', 'tainacan-chatgpt')
                ],
                [
                    'role' => 'user',
                    'content' => sprintf(
                        __('No texto a seguir, encontre o trecho exato que menciona ou contém o valor "%s" para o campo "%s". Cite APENAS o trecho, sem adicionar explicações.\n\nTexto: %s', 'tainacan-chatgpt'),
                        $value,
                        $field,
                        $chunk
                    )
                ]
            ];
            
            $response = $this->api->send_function_request($messages, [$json_schema], [
                'temperature' => 0,
                'max_tokens' => 500
            ]);
            
            if ($response['success'] && isset($response['data']['evidence']) && 
                $response['data']['evidence'] !== 'EVIDÊNCIA AUSENTE') {
                return $response['data']['evidence'];
            }
        }
        
        return null;
    }
    
    /**
     * Valida metadados com verificações de regex e similaridade
     * 
     * @param array $metadata Metadados com evidências
     * @return array Metadados validados
     */
    private function validate_metadata($metadata) {
        $validated = $metadata;
        $validated['validation'] = [];
        
        error_log('Debug: Validando metadados...');
        
        foreach ($metadata['metadata'] as $field => $value) {
            // Pula campos vazios
            if (empty($value) || $value === 'INFORMAÇÃO AUSENTE') {
                $validated['validation'][$field] = [
                    'valid' => true,
                    'reason' => 'empty'
                ];
                continue;
            }
            
            // Valida com padrões regex
            $regex_valid = $this->validate_field_with_regex($field, $value);
            
            $validated['validation'][$field] = [
                'valid' => $regex_valid,
                'reason' => !$regex_valid ? 'format' : 'valid'
            ];
            
            // Atualiza flag de revisão humana
            if (!$regex_valid) {
                $validated['needs_human_review'] = true;
                error_log('Debug: Campo ' . $field . ' não passou na validação de regex');
            }
        }
        
        return $validated;
    }
    
    /**
     * Valida um valor de campo com padrões regex
     * 
     * @param string $field Nome do campo
     * @param string $value Valor do campo
     * @return bool True se o valor for válido
     */
    private function validate_field_with_regex($field, $value) {
        // Define padrões regex para campos comuns
        $patterns = [
            'data' => '/^\d{1,2}\/\d{1,2}\/\d{4}|\d{4}$/', // DD/MM/YYYY ou YYYY
            'ano' => '/^\d{4}$/', // YYYY
            'doi' => '/^10\.\d{4,9}\/[-._;()/:A-Z0-9]+$/i', // formato DOI
            'issn' => '/^\d{4}-\d{3}[\dX]$/', // formato ISSN
            'dimensoes' => '/^\d+(\.\d+)?\s*[x×]\s*\d+(\.\d+)?\s*[x×]?\s*\d*(\.\d+)?\s*[a-z]*$/i' // dimensões
        ];
        
        // Verifica se o campo corresponde a algum padrão
        foreach ($patterns as $pattern_field => $pattern) {
            if (stripos($field, $pattern_field) !== false) {
                return preg_match($pattern, $value) === 1;
            }
        }
        
        return true; // Válido por padrão
    }
    
    /**
     * Analisa uma imagem usando a API do ChatGPT
     * 
     * @param int $attachment_id ID do anexo
     * @param string $custom_prompt Prompt personalizado
     * @return array Resultado da análise
     */
    public function analyze_image($attachment_id, $custom_prompt = '') {
        error_log('Debug: analyze_image iniciado para ID ' . $attachment_id);
        
        // Verifica se o anexo existe
        $attachment = get_post($attachment_id);
        if (!$attachment) {
            return array(
                'success' => false,
                'message' => __('Anexo não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        // Obtém caminho do arquivo utilizando o mesmo método de analyze_attachment
        $file_path = get_attached_file($attachment_id);
        
        // Se não encontrou, tente caminho alternativo para Tainacan
        if (empty($file_path) || !file_exists($file_path)) {
            // Construir caminho a partir da URL
            $upload_dir = wp_upload_dir();
            $file_url = wp_get_attachment_url($attachment_id);
            
            if ($file_url) {
                $file_rel_path = str_replace($upload_dir['baseurl'], '', $file_url);
                $alt_path = $upload_dir['basedir'] . $file_rel_path;
                $alt_path = str_replace('/', DIRECTORY_SEPARATOR, $alt_path);
                
                error_log('Debug: [IMAGE] URL alternativa: ' . $file_url);
                error_log('Debug: [IMAGE] Caminho alternativo: ' . $alt_path);
                
                if (file_exists($alt_path)) {
                    $file_path = $alt_path;
                    error_log('Debug: [IMAGE] Usando caminho alternativo');
                }
            }
        }
        
        if (!$file_path || !file_exists($file_path)) {
            error_log('Debug: Arquivo de imagem não encontrado: ' . $file_path);
            return array(
                'success' => false,
                'message' => __('Arquivo de imagem não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        // Extrai campos do prompt para criar esquema JSON
        $fields = $this->extract_fields_from_prompt($custom_prompt);
        $json_schema = $this->create_json_schema($fields);
        
        // Analisa imagem com function calling
        error_log('Debug: Enviando imagem para análise...');
        $result = $this->api->analyze_image_with_function($attachment_id, $json_schema, $custom_prompt);
        
        if (!$result['success']) {
            error_log('Debug: Erro na análise de imagem: ' . json_encode($result));
            return $result;
        }
        
        // Para imagens, sempre marca como precisando de revisão humana
        $metadata = [
            'metadata' => $result['data'],
            'needs_human_review' => true,
            'validation' => []
        ];
        
        // Valida cada campo
        foreach ($result['data'] as $field => $value) {
            $metadata['validation'][$field] = [
                'valid' => true,
                'reason' => 'image'
            ];
        }
        
        error_log('Debug: Análise de imagem concluída com sucesso');
        return array(
            'success' => true,
            'data' => $metadata
        );
    }
    
    /**
     * Analisa um documento genérico
     * 
     * @param int $attachment_id ID do anexo
     * @param string $custom_prompt Prompt personalizado
     * @return array Resultado da análise
     */
    public function analyze_document($attachment_id, $custom_prompt = '') {
        error_log('Debug: analyze_document iniciado para ID ' . $attachment_id);
        
        // Verifica mime type para determinar o tipo de análise
        $mime_type = get_post_mime_type($attachment_id);
        
        // Para PDFs, usa o analisador específico
        if ($mime_type === 'application/pdf') {
            return $this->analyze_pdf($attachment_id, $custom_prompt);
        }
        
        // Para imagens, usa o analisador de imagens
        if (strpos($mime_type, 'image/') === 0) {
            return $this->analyze_image($attachment_id, $custom_prompt);
        }
        
        // Para documentos de texto, extrai o conteúdo
        $file_path = get_attached_file($attachment_id);
        
        // Se não encontrou, tente caminho alternativo para Tainacan
        if (empty($file_path) || !file_exists($file_path)) {
            // Construir caminho a partir da URL
            $upload_dir = wp_upload_dir();
            $file_url = wp_get_attachment_url($attachment_id);
            
            if ($file_url) {
                $file_rel_path = str_replace($upload_dir['baseurl'], '', $file_url);
                $alt_path = $upload_dir['basedir'] . $file_rel_path;
                $alt_path = str_replace('/', DIRECTORY_SEPARATOR, $alt_path);
                
                error_log('Debug: [DOC] URL alternativa: ' . $file_url);
                error_log('Debug: [DOC] Caminho alternativo: ' . $alt_path);
                
                if (file_exists($alt_path)) {
                    $file_path = $alt_path;
                    error_log('Debug: [DOC] Usando caminho alternativo');
                }
            }
        }
        
        if (!$file_path || !file_exists($file_path)) {
            error_log('Debug: Arquivo não encontrado: ' . $file_path);
            return array(
                'success' => false,
                'message' => __('Arquivo não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        $text_content = $this->get_file_content($file_path, $mime_type);
        
        if (empty($text_content)) {
            error_log('Debug: Não foi possível extrair conteúdo do documento');
            return array(
                'success' => false,
                'message' => __('Não foi possível extrair conteúdo do documento.', 'tainacan-chatgpt')
            );
        }
        
        // Divide em chunks
        $chunks = $this->chunk_text($text_content, 1500);
        
        // Extrai campos do prompt
        $fields = $this->extract_fields_from_prompt($custom_prompt);
        
        // Cria esquema JSON para chamada de função
        $json_schema = $this->create_json_schema($fields);
        
        // Fase 1: Extração de metadados
        $metadata = $this->extract_metadata_from_chunks($chunks, $custom_prompt, $json_schema);
        
        if (empty($metadata) || !is_array($metadata)) {
            return array(
                'success' => false,
                'message' => __('Falha ao extrair metadados do documento.', 'tainacan-chatgpt')
            );
        }
        
        // Fase 2: Verificação de cada campo
        $verified_metadata = $this->verify_metadata_fields($metadata, $chunks, $fields);
        
        // Fase 3: Validação dos dados
        $validated_metadata = $this->validate_metadata($verified_metadata);
        
        return array(
            'success' => true,
            'data' => $validated_metadata
        );
    }
    
    /**
     * Obtém o conteúdo do arquivo
     * 
     * @param string $file_path Caminho do arquivo
     * @param string $mime_type Tipo MIME do arquivo
     * @return string Conteúdo do arquivo
     */
    private function get_file_content($file_path, $mime_type) {
        $content = '';
        error_log('Debug: Extraindo conteúdo de arquivo: ' . $file_path . ' (MIME: ' . $mime_type . ')');
        
        // Tentar ler o arquivo diretamente se for texto
        if (strpos($mime_type, 'text/') === 0) {
            $content = file_get_contents($file_path);
            
            if ($mime_type === 'text/html' || $mime_type === 'text/xml') {
                $content = strip_tags($content);
            }
            
            return $content;
        }
        
        // Para documentos Office, podemos adicionar bibliotecas adicionais
        // como PhpOffice/PhpWord para DOCX, etc.
        
        return $content;
    }
    
    /**
     * Obtém o documento anexado ao item
     * 
     * @param object $item Item do Tainacan
     * @return array Informações do documento
     */
    private function get_document_from_item($item) {
        // Busca o documento anexado
        $document_type = get_post_meta($item->get_id(), 'document_type', true);
        
        if (empty($document_type) || $document_type === 'none') {
            return array(
                'success' => false,
                'message' => __('Item não possui documento anexado.', 'tainacan-chatgpt')
            );
        }
        
        if ($document_type === 'attachment') {
            $document_id = get_post_meta($item->get_id(), 'document_id', true);
            
            if (empty($document_id)) {
                return array(
                    'success' => false,
                    'message' => __('Documento não encontrado.', 'tainacan-chatgpt')
                );
            }
            
            $file_url = wp_get_attachment_url($document_id);
            $mime_type = get_post_mime_type($document_id);
            
            // Determina o tipo de documento
            $is_image = strpos($mime_type, 'image/') === 0;
            $is_pdf = $mime_type === 'application/pdf';
            
            $type = $is_image ? 'image' : ($is_pdf ? 'pdf' : 'document');
            
            return array(
                'success' => true,
                'type' => $type,
                'url' => $file_url,
                'attachment_id' => $document_id,
                'mime_type' => $mime_type
            );
        } elseif ($document_type === 'url') {
            // Para URLs externas, não podemos usar o ChatGPT diretamente
            return array(
                'success' => false,
                'message' => __('URLs externas não são suportadas pela API do ChatGPT. Por favor, utilize arquivos anexados.', 'tainacan-chatgpt')
            );
        } else {
            return array(
                'success' => false,
                'message' => __('Tipo de documento não suportado.', 'tainacan-chatgpt')
            );
        }
    }
}