/**
 * Scripts para a interface de administração do plugin
 */
(function($) {
    'use strict';
    
    // Variável para controlar o modo de debug
    const debug = TainacanChatGPT.debug_enabled === true;
    
    $(document).ready(function() {
        if (debug) {
            console.log('Tainacan ChatGPT Admin: Script inicializado');
        }
        
        // Botão para testar conexão com a API
        $('#test-api-btn').on('click', function(e) {
            e.preventDefault();
            
            const $button = $(this);
            const $result = $('#api-test-result');
            
            $button.prop('disabled', true);
            $result.text(TainacanChatGPT.testingApi).addClass('testing');
            
            $.ajax({
                url: TainacanChatGPT.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'tainacan_chatgpt_test_api',
                    nonce: TainacanChatGPT.nonce
                },
                success: function(response) {
                    $button.prop('disabled', false);
                    $result.removeClass('testing');
                    
                    if (response.success) {
                        $result.text(TainacanChatGPT.testSuccess).addClass('success').removeClass('error');
                    } else {
                        $result.text(response.data).addClass('error').removeClass('success');
                    }
                    
                    // Esconde o resultado após 5 segundos
                    setTimeout(function() {
                        $result.text('').removeClass('success error');
                    }, 5000);
                },
                error: function() {
                    $button.prop('disabled', false);
                    $result.text(TainacanChatGPT.testFailed).addClass('error').removeClass('testing success');
                }
            });
        });
        
        // Botão para limpar cache
        $('#clear-cache-btn').on('click', function(e) {
            e.preventDefault();
            
            const $button = $(this);
            const $result = $('#cache-clear-result');
            
            $button.prop('disabled', true);
            $result.text(TainacanChatGPT.clearingCache).addClass('testing');
            
            $.ajax({
                url: TainacanChatGPT.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'tainacan_chatgpt_clear_cache',
                    nonce: TainacanChatGPT.nonce
                },
                success: function(response) {
                    $button.prop('disabled', false);
                    $result.removeClass('testing');
                    
                    if (response.success) {
                        $result.text(TainacanChatGPT.cacheCleared).addClass('success').removeClass('error');
                    } else {
                        $result.text(response.data).addClass('error').removeClass('success');
                    }
                    
                    // Esconde o resultado após 5 segundos
                    setTimeout(function() {
                        $result.text('').removeClass('success error');
                    }, 5000);
                },
                error: function() {
                    $button.prop('disabled', false);
                    $result.text(TainacanChatGPT.errorOccurred).addClass('error').removeClass('testing success');
                }
            });
        });
        
        // Botões para restaurar prompts padrão
        $('#reset-image-prompt').on('click', function(e) {
            e.preventDefault();
            $('#tainacan_chatgpt_image_prompt').val(
                'Analise esta imagem museológica e extraia os seguintes metadados: título, autor, data de criação, técnica utilizada, dimensões, estado de conservação, descrição visual detalhada. Formate a resposta como um JSON com esses campos.'
            );
        });
        
        $('#reset-text-prompt').on('click', function(e) {
            e.preventDefault();
            $('#tainacan_chatgpt_text_prompt').val(
                'Analise este documento e extraia os seguintes metadados: título, autor(es), ano de publicação, resumo, palavras-chave, metodologia, instituição, área de conhecimento. Formate a resposta como um JSON com esses campos.'
            );
        });
        
        // Botões para usar prompts da biblioteca
        $('.use-prompt').on('click', function(e) {
            e.preventDefault();
            
            const target = $(this).data('target');
            const prompt = $(this).data('prompt');
            
            if (target === 'image') {
                $('#tainacan_chatgpt_image_prompt').val(prompt);
            } else if (target === 'text') {
                $('#tainacan_chatgpt_text_prompt').val(prompt);
            }
        });
        
        // Exportar estatísticas
        $('#export-stats-btn').on('click', function(e) {
            e.preventDefault();
            
            $.ajax({
                url: TainacanChatGPT.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'tainacan_chatgpt_get_usage_stats',
                    nonce: TainacanChatGPT.nonce
                },
                success: function(response) {
                    if (response.success) {
                        const stats = response.data;
                        let csv = 'Modelo,Requisições,Tokens,Custo (USD)\n';
                        
                        // Adiciona dados de cada modelo
                        for (const model in stats.models) {
                            if (stats.models.hasOwnProperty(model)) {
                                const data = stats.models[model];
                                csv += `"${model}",${data.requests},${data.tokens},${data.cost.toFixed(4)}\n`;
                            }
                        }
                        
                        // Adiciona totais
                        csv += `"Total",${stats.total_requests},${stats.total_tokens},${stats.total_cost.toFixed(4)}\n`;
                        
                        // Cria e aciona o download
                        const blob = new Blob([csv], { type: 'text/csv' });
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        
                        a.style.display = 'none';
                        a.href = url;
                        a.download = 'tainacan-chatgpt-stats.csv';
                        
                        document.body.appendChild(a);
                        a.click();
                        
                        window.URL.revokeObjectURL(url);
                        document.body.removeChild(a);
                    }
                }
            });
        });
        
        // Atualizar estatísticas
        $('#refresh-stats-btn').on('click', function(e) {
            e.preventDefault();
            location.reload();
        });
        
        // Validar inputs numéricos
        $('#tainacan_chatgpt_max_tokens, #tainacan_chatgpt_request_timeout, #tainacan_chatgpt_cache_duration').on('input', function() {
            const $input = $(this);
            const min = parseInt($input.attr('min')) || 0;
            const max = parseInt($input.attr('max')) || Number.MAX_SAFE_INTEGER;
            let value = parseInt($input.val());
            
            if (isNaN(value)) {
                value = min;
            } else {
                value = Math.max(min, Math.min(max, value));
            }
            
            $input.val(value);
        });
        
        // Validar temperatura
        $('#tainacan_chatgpt_temperature').on('input', function() {
            const $input = $(this);
            const min = 0;
            const max = 1;
            let value = parseFloat($input.val());
            
            if (isNaN(value)) {
                value = 0.1;
            } else {
                value = Math.max(min, Math.min(max, value));
            }
            
            $input.val(value);
        });
    });
})(jQuery);