<?php
/**
 * Classe responsável pela interface de administração do plugin
 */
class Tainacan_ChatGPT_Admin {
    /**
     * Construtor
     */
    public function __construct() {
        // Adiciona menu no painel administrativo
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Registra configurações
        add_action('admin_init', array($this, 'register_settings'));
        
        // Carrega scripts e estilos
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Adiciona AJAX handlers
        add_action('wp_ajax_tainacan_chatgpt_test_api', array($this, 'ajax_test_api'));
        add_action('wp_ajax_tainacan_chatgpt_clear_cache', array($this, 'ajax_clear_cache'));
        add_action('wp_ajax_tainacan_chatgpt_get_usage_stats', array($this, 'ajax_get_usage_stats'));
    }
    
    /**
     * Adiciona menu no painel administrativo
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Tainacan ChatGPT', 'tainacan-chatgpt'),
            __('Tainacan ChatGPT', 'tainacan-chatgpt'),
            'manage_options',
            'tainacan-chatgpt',
            array($this, 'render_admin_page'),
            'dashicons-format-status',
            30
        );
        
        add_submenu_page(
            'tainacan-chatgpt',
            __('Configurações', 'tainacan-chatgpt'),
            __('Configurações', 'tainacan-chatgpt'),
            'manage_options',
            'tainacan-chatgpt',
            array($this, 'render_admin_page')
        );
        
        add_submenu_page(
            'tainacan-chatgpt',
            __('Estatísticas de Uso', 'tainacan-chatgpt'),
            __('Estatísticas de Uso', 'tainacan-chatgpt'),
            'manage_options',
            'tainacan-chatgpt-stats',
            array($this, 'render_stats_page')
        );
        
        add_submenu_page(
            'tainacan-chatgpt',
            __('Configurações Avançadas', 'tainacan-chatgpt'),
            __('Configurações Avançadas', 'tainacan-chatgpt'),
            'manage_options',
            'tainacan-chatgpt-advanced',
            array($this, 'render_advanced_page')
        );
    }
    
    /**
     * Registra configurações do plugin
     */
    public function register_settings() {
        register_setting('tainacan_chatgpt_options', 'tainacan_chatgpt_options', array($this, 'validate_options'));
    }
    
    /**
     * Valida as opções salvas
     */
    public function validate_options($input) {
        $options = get_option('tainacan_chatgpt_options', array());
        
        // Valida chave da API
        if (isset($input['api_key'])) {
            $options['api_key'] = sanitize_text_field($input['api_key']);
        }
        
        // Valida modelo
        if (isset($input['model'])) {
            $options['model'] = sanitize_text_field($input['model']);
        }
        
        // Valida prompts
        if (isset($input['image_prompt'])) {
            $options['image_prompt'] = wp_kses_post($input['image_prompt']);
        }
        
        if (isset($input['text_prompt'])) {
            $options['text_prompt'] = wp_kses_post($input['text_prompt']);
        }
        
        // Valida opções numéricas
        $numeric_options = array('max_tokens', 'temperature', 'request_timeout', 'cache_duration');
        foreach ($numeric_options as $option) {
            if (isset($input[$option])) {
                $options[$option] = intval($input[$option]);
            }
        }
        
        // Valida temperatura (entre 0 e 1)
        if (isset($input['temperature'])) {
            $options['temperature'] = max(0, min(1, floatval($input['temperature'])));
        }
        
        return $options;
    }
    
    /**
     * Carrega scripts e estilos para as páginas de administração
     */
    public function enqueue_admin_assets($hook) {
        $admin_pages = array(
            'toplevel_page_tainacan-chatgpt',
            'tainacan-chatgpt_page_tainacan-chatgpt-stats',
            'tainacan-chatgpt_page_tainacan-chatgpt-advanced'
        );
        
        if (in_array($hook, $admin_pages)) {
            wp_enqueue_style(
                'tainacan-chatgpt-admin',
                TAINACAN_CHATGPT_PLUGIN_DIR_URL . 'admin/css/admin.css',
                array(),
                TAINACAN_CHATGPT_VERSION
            );
            
            wp_enqueue_script(
                'tainacan-chatgpt-admin',
                TAINACAN_CHATGPT_PLUGIN_DIR_URL . 'admin/js/admin.js',
                array('jquery'),
                TAINACAN_CHATGPT_VERSION,
                true
            );
            
            wp_localize_script('tainacan-chatgpt-admin', 'TainacanChatGPT', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('tainacan_chatgpt_admin_nonce'),
                'testingApi' => __('Testando API...', 'tainacan-chatgpt'),
                'testSuccess' => __('Conexão bem-sucedida!', 'tainacan-chatgpt'),
                'testFailed' => __('Falha na conexão. Verifique sua chave API.', 'tainacan-chatgpt'),
                'clearingCache' => __('Limpando cache...', 'tainacan-chatgpt'),
                'cacheCleared' => __('Cache limpo com sucesso!', 'tainacan-chatgpt'),
                'errorOccurred' => __('Ocorreu um erro. Tente novamente.', 'tainacan-chatgpt')
            ));
        }
    }
    
    /**
     * Renderiza a página principal de administração
     */
    public function render_admin_page() {
        // Verifica permissões
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Inicializa valores padrão caso não existam
        $default_options = array(
            'api_key' => '',
            'model' => 'gpt-4o',
            'image_prompt' => __('Analise esta imagem museológica e extraia os seguintes metadados: título, autor, data de criação, técnica utilizada, dimensões, estado de conservação, descrição visual detalhada. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
            'text_prompt' => __('Analise este documento e extraia os seguintes metadados: título, autor(es), ano de publicação, resumo, palavras-chave, metodologia, instituição, área de conhecimento. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
            'max_tokens' => 1000,
            'temperature' => 0.7,
            'request_timeout' => 30,
            'cache_duration' => 3600,
        );
        
        // Obtém opções salvas ou usa valores padrão
        $options = wp_parse_args(get_option('tainacan_chatgpt_options', array()), $default_options);
        ?>
        <div class="wrap tainacan-chatgpt-admin">
            <h1><?php echo esc_html__('Tainacan ChatGPT - Configurações', 'tainacan-chatgpt'); ?></h1>
            
            <div class="tainacan-chatgpt-card">
                <form method="post" action="options.php">
                    <?php settings_fields('tainacan_chatgpt_options'); ?>
                    
                    <div class="tainacan-chatgpt-form-section">
                        <h2><?php echo esc_html__('Configurações da API', 'tainacan-chatgpt'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_api_key"><?php echo esc_html__('Chave da API OpenAI', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <input type="password" 
                                        id="tainacan_chatgpt_api_key" 
                                        name="tainacan_chatgpt_options[api_key]" 
                                        value="<?php echo esc_attr($options['api_key']); ?>" 
                                        class="regular-text"
                                        required
                                    />
                                    <p class="description">
                                        <?php echo esc_html__('Insira sua chave da API OpenAI. Você pode obtê-la em', 'tainacan-chatgpt'); ?> 
                                        <a href="https://platform.openai.com/account/api-keys" target="_blank">platform.openai.com</a>
                                    </p>
                                    <button type="button" id="test-api-btn" class="button button-secondary">
                                        <?php echo esc_html__('Testar Conexão', 'tainacan-chatgpt'); ?>
                                    </button>
                                    <span id="api-test-result"></span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_model"><?php echo esc_html__('Modelo', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <select id="tainacan_chatgpt_model" name="tainacan_chatgpt_options[model]">
                                        <option value="gpt-4o" <?php selected($options['model'], 'gpt-4o'); ?>>
                                            <?php echo esc_html__('GPT-4o (Recomendado)', 'tainacan-chatgpt'); ?>
                                        </option>
                                        <option value="gpt-4-vision-preview" <?php selected($options['model'], 'gpt-4-vision-preview'); ?>>
                                            <?php echo esc_html__('GPT-4 Vision', 'tainacan-chatgpt'); ?>
                                        </option>
                                        <option value="gpt-4-turbo" <?php selected($options['model'], 'gpt-4-turbo'); ?>>
                                            <?php echo esc_html__('GPT-4 Turbo', 'tainacan-chatgpt'); ?>
                                        </option>
                                        <option value="gpt-3.5-turbo" <?php selected($options['model'], 'gpt-3.5-turbo'); ?>>
                                            <?php echo esc_html__('GPT-3.5 Turbo (Mais rápido, menos preciso)', 'tainacan-chatgpt'); ?>
                                        </option>
                                    </select>
                                    <p class="description">
                                        <?php echo esc_html__('Selecione o modelo da OpenAI para análise de documentos e imagens.', 'tainacan-chatgpt'); ?>
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="tainacan-chatgpt-form-section">
                        <h2><?php echo esc_html__('Prompts Personalizados', 'tainacan-chatgpt'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_image_prompt"><?php echo esc_html__('Prompt para Imagens', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <textarea 
                                        id="tainacan_chatgpt_image_prompt" 
                                        name="tainacan_chatgpt_options[image_prompt]" 
                                        rows="6" 
                                        class="large-text"
                                    ><?php echo esc_textarea($options['image_prompt']); ?></textarea>
                                    <p class="description">
                                        <?php echo esc_html__('Prompt usado para analisar imagens. Solicite que o ChatGPT retorne metadados específicos.', 'tainacan-chatgpt'); ?>
                                    </p>
                                    <button type="button" id="reset-image-prompt" class="button button-secondary">
                                        <?php echo esc_html__('Restaurar Padrão', 'tainacan-chatgpt'); ?>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_text_prompt"><?php echo esc_html__('Prompt para Documentos', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <textarea 
                                        id="tainacan_chatgpt_text_prompt" 
                                        name="tainacan_chatgpt_options[text_prompt]" 
                                        rows="6" 
                                        class="large-text"
                                    ><?php echo esc_textarea($options['text_prompt']); ?></textarea>
                                    <p class="description">
                                        <?php echo esc_html__('Prompt usado para analisar documentos PDF e textos. Solicite que o ChatGPT retorne metadados específicos.', 'tainacan-chatgpt'); ?>
                                    </p>
                                    <button type="button" id="reset-text-prompt" class="button button-secondary">
                                        <?php echo esc_html__('Restaurar Padrão', 'tainacan-chatgpt'); ?>
                                    </button>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="tainacan-chatgpt-form-section">
                        <h2><?php echo esc_html__('Cache', 'tainacan-chatgpt'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_cache_duration"><?php echo esc_html__('Duração do Cache', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <input type="number" 
                                        id="tainacan_chatgpt_cache_duration" 
                                        name="tainacan_chatgpt_options[cache_duration]" 
                                        value="<?php echo esc_attr($options['cache_duration']); ?>" 
                                        min="300"
                                        step="300"
                                    />
                                    <span><?php echo esc_html__('segundos', 'tainacan-chatgpt'); ?></span>
                                    <p class="description">
                                        <?php echo esc_html__('Tempo em segundos para manter os resultados em cache (mínimo 300s / 5 minutos).', 'tainacan-chatgpt'); ?>
                                    </p>
                                    <button type="button" id="clear-cache-btn" class="button button-secondary">
                                        <?php echo esc_html__('Limpar Cache Agora', 'tainacan-chatgpt'); ?>
                                    </button>
                                    <span id="cache-clear-result"></span>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <?php submit_button(__('Salvar Configurações', 'tainacan-chatgpt'), 'primary', 'submit', true); ?>
                </form>
            </div>
        </div>
        <?php
    }
    
    /**
     * Renderiza a página de estatísticas de uso
     */
    public function render_stats_page() {
        // Verifica permissões
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $logger = new Tainacan_ChatGPT_Logger();
        $usage_stats = $logger->get_usage_stats();
        ?>
        <div class="wrap tainacan-chatgpt-admin">
            <h1><?php echo esc_html__('Tainacan ChatGPT - Estatísticas de Uso', 'tainacan-chatgpt'); ?></h1>
            
            <div class="tainacan-chatgpt-card">
                <h2><?php echo esc_html__('Resumo de Uso', 'tainacan-chatgpt'); ?></h2>
                
                <div class="tainacan-chatgpt-stats-grid">
                    <div class="tainacan-chatgpt-stat-box">
                        <h3><?php echo esc_html__('Total de Requisições', 'tainacan-chatgpt'); ?></h3>
                        <div class="tainacan-chatgpt-stat-value"><?php echo esc_html($usage_stats['total_requests']); ?></div>
                    </div>
                    
                    <div class="tainacan-chatgpt-stat-box">
                        <h3><?php echo esc_html__('Requisições com Sucesso', 'tainacan-chatgpt'); ?></h3>
                        <div class="tainacan-chatgpt-stat-value"><?php echo esc_html($usage_stats['successful_requests']); ?></div>
                    </div>
                    
                    <div class="tainacan-chatgpt-stat-box">
                        <h3><?php echo esc_html__('Total de Tokens', 'tainacan-chatgpt'); ?></h3>
                        <div class="tainacan-chatgpt-stat-value"><?php echo esc_html($usage_stats['total_tokens']); ?></div>
                    </div>
                    
                    <div class="tainacan-chatgpt-stat-box">
                        <h3><?php echo esc_html__('Economia por Cache', 'tainacan-chatgpt'); ?></h3>
                        <div class="tainacan-chatgpt-stat-value"><?php echo esc_html($usage_stats['cache_hits']); ?></div>
                    </div>
                </div>
                
                <h2><?php echo esc_html__('Uso por Modelo', 'tainacan-chatgpt'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Modelo', 'tainacan-chatgpt'); ?></th>
                            <th><?php echo esc_html__('Requisições', 'tainacan-chatgpt'); ?></th>
                            <th><?php echo esc_html__('Tokens', 'tainacan-chatgpt'); ?></th>
                            <th><?php echo esc_html__('Custo Estimado (USD)', 'tainacan-chatgpt'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usage_stats['models'] as $model => $data): ?>
                        <tr>
                            <td><?php echo esc_html($model); ?></td>
                            <td><?php echo esc_html($data['requests']); ?></td>
                            <td><?php echo esc_html($data['tokens']); ?></td>
                            <td>$<?php echo esc_html(number_format($data['cost'], 4)); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th><?php echo esc_html__('Total', 'tainacan-chatgpt'); ?></th>
                            <th><?php echo esc_html($usage_stats['total_requests']); ?></th>
                            <th><?php echo esc_html($usage_stats['total_tokens']); ?></th>
                            <th>$<?php echo esc_html(number_format($usage_stats['total_cost'], 4)); ?></th>
                        </tr>
                    </tfoot>
                </table>
                
                <div class="tainacan-chatgpt-actions">
                    <button type="button" id="export-stats-btn" class="button button-primary">
                        <?php echo esc_html__('Exportar Estatísticas (CSV)', 'tainacan-chatgpt'); ?>
                    </button>
                    <button type="button" id="refresh-stats-btn" class="button button-secondary">
                        <?php echo esc_html__('Atualizar Dados', 'tainacan-chatgpt'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Renderiza a página de configurações avançadas
     */
    public function render_advanced_page() {
        // Verifica permissões
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Inicializa valores padrão caso não existam
        $default_options = array(
            'max_tokens' => 1000,
            'temperature' => 0.7,
            'request_timeout' => 30,
        );
        
        // Obtém opções salvas ou usa valores padrão
        $options = wp_parse_args(get_option('tainacan_chatgpt_options', array()), $default_options);
        ?>
        <div class="wrap tainacan-chatgpt-admin">
            <h1><?php echo esc_html__('Tainacan ChatGPT - Configurações Avançadas', 'tainacan-chatgpt'); ?></h1>
            
            <div class="tainacan-chatgpt-card">
                <form method="post" action="options.php">
                    <?php settings_fields('tainacan_chatgpt_options'); ?>
                    
                    <div class="tainacan-chatgpt-form-section">
                        <h2><?php echo esc_html__('Parâmetros da API', 'tainacan-chatgpt'); ?></h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_max_tokens"><?php echo esc_html__('Tokens Máximos', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <input type="number" 
                                        id="tainacan_chatgpt_max_tokens" 
                                        name="tainacan_chatgpt_options[max_tokens]" 
                                        value="<?php echo esc_attr($options['max_tokens']); ?>" 
                                        min="100"
                                        max="4096"
                                        step="1"
                                    />
                                    <p class="description">
                                        <?php echo esc_html__('Número máximo de tokens na resposta. Valores mais altos permitem respostas mais detalhadas mas aumentam o custo.', 'tainacan-chatgpt'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_temperature"><?php echo esc_html__('Temperatura', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <input type="number" 
                                        id="tainacan_chatgpt_temperature" 
                                        name="tainacan_chatgpt_options[temperature]" 
                                        value="<?php echo esc_attr($options['temperature']); ?>" 
                                        min="0"
                                        max="1"
                                        step="0.1"
                                    />
                                    <p class="description">
                                        <?php echo esc_html__('Controla a aleatoriedade das respostas. Valores mais baixos resultam em respostas mais determinísticas e focadas.', 'tainacan-chatgpt'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="tainacan_chatgpt_request_timeout"><?php echo esc_html__('Timeout da Requisição', 'tainacan-chatgpt'); ?></label>
                                </th>
                                <td>
                                    <input type="number" 
                                        id="tainacan_chatgpt_request_timeout" 
                                        name="tainacan_chatgpt_options[request_timeout]" 
                                        value="<?php echo esc_attr($options['request_timeout']); ?>" 
                                        min="10"
                                        max="120"
                                        step="1"
                                    />
                                    <span><?php echo esc_html__('segundos', 'tainacan-chatgpt'); ?></span>
                                    <p class="description">
                                        <?php echo esc_html__('Tempo máximo de espera para resposta da API em segundos.', 'tainacan-chatgpt'); ?>
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="tainacan-chatgpt-form-section">
                        <h2><?php echo esc_html__('Bibliotecas de Prompts', 'tainacan-chatgpt'); ?></h2>
                        
                        <div class="tainacan-chatgpt-prompt-library">
                            <h3><?php echo esc_html__('Prompts para Imagens', 'tainacan-chatgpt'); ?></h3>
                            <div class="tainacan-chatgpt-prompt-examples">
                                <div class="tainacan-chatgpt-prompt-example">
                                    <h4><?php echo esc_html__('Arte Museológica', 'tainacan-chatgpt'); ?></h4>
                                    <pre><?php echo esc_html__('Analise esta imagem museológica e extraia os seguintes metadados: título, autor, data de criação, técnica utilizada, dimensões, estado de conservação, descrição visual detalhada. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?></pre>
                                    <button type="button" class="button button-secondary use-prompt" data-target="image" data-prompt="<?php echo esc_attr__('Analise esta imagem museológica e extraia os seguintes metadados: título, autor, data de criação, técnica utilizada, dimensões, estado de conservação, descrição visual detalhada. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?>">
                                        <?php echo esc_html__('Usar Este Prompt', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                                
                                <div class="tainacan-chatgpt-prompt-example">
                                    <h4><?php echo esc_html__('Fotografia Histórica', 'tainacan-chatgpt'); ?></h4>
                                    <pre><?php echo esc_html__('Analise esta fotografia histórica e identifique: período histórico aproximado, localização geográfica provável, eventos ou contexto histórico representado, personagens ou elementos notáveis, vestuário e arquitetura visíveis, tecnologias da época presentes, e significado histórico potencial. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?></pre>
                                    <button type="button" class="button button-secondary use-prompt" data-target="image" data-prompt="<?php echo esc_attr__('Analise esta fotografia histórica e identifique: período histórico aproximado, localização geográfica provável, eventos ou contexto histórico representado, personagens ou elementos notáveis, vestuário e arquitetura visíveis, tecnologias da época presentes, e significado histórico potencial. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?>">
                                        <?php echo esc_html__('Usar Este Prompt', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                                
                                <div class="tainacan-chatgpt-prompt-example">
                                    <h4><?php echo esc_html__('Artefato Arqueológico', 'tainacan-chatgpt'); ?></h4>
                                    <pre><?php echo esc_html__('Analise esta imagem de artefato arqueológico e extraia: tipo de artefato, cultura/civilização de origem, período histórico estimado, material de composição, função provável, características distintivas, estado de preservação, e relevância arqueológica. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?></pre>
                                    <button type="button" class="button button-secondary use-prompt" data-target="image" data-prompt="<?php echo esc_attr__('Analise esta imagem de artefato arqueológico e extraia: tipo de artefato, cultura/civilização de origem, período histórico estimado, material de composição, função provável, características distintivas, estado de preservação, e relevância arqueológica. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?>">
                                        <?php echo esc_html__('Usar Este Prompt', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                            </div>
                            
                            <h3><?php echo esc_html__('Prompts para Documentos', 'tainacan-chatgpt'); ?></h3>
                            <div class="tainacan-chatgpt-prompt-examples">
                                <div class="tainacan-chatgpt-prompt-example">
                                    <h4><?php echo esc_html__('Artigo Acadêmico', 'tainacan-chatgpt'); ?></h4>
                                    <pre><?php echo esc_html__('Analise este artigo acadêmico e extraia os seguintes metadados: título, autor(es), instituição de origem, ano de publicação, resumo, palavras-chave, área de conhecimento, metodologia utilizada, principais conclusões, e referências importantes. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?></pre>
                                    <button type="button" class="button button-secondary use-prompt" data-target="text" data-prompt="<?php echo esc_attr__('Analise este artigo acadêmico e extraia os seguintes metadados: título, autor(es), instituição de origem, ano de publicação, resumo, palavras-chave, área de conhecimento, metodologia utilizada, principais conclusões, e referências importantes. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?>">
                                        <?php echo esc_html__('Usar Este Prompt', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                                
                                <div class="tainacan-chatgpt-prompt-example">
                                    <h4><?php echo esc_html__('Tese ou Dissertação', 'tainacan-chatgpt'); ?></h4>
                                    <pre><?php echo esc_html__('Analise esta tese/dissertação e extraia: título, autor, orientador, instituição, programa de pós-graduação, ano de defesa, resumo, palavras-chave, problema de pesquisa, metodologia, principais resultados e contribuições originais para o campo. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?></pre>
                                    <button type="button" class="button button-secondary use-prompt" data-target="text" data-prompt="<?php echo esc_attr__('Analise esta tese/dissertação e extraia: título, autor, orientador, instituição, programa de pós-graduação, ano de defesa, resumo, palavras-chave, problema de pesquisa, metodologia, principais resultados e contribuições originais para o campo. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?>">
                                        <?php echo esc_html__('Usar Este Prompt', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                                
                                <div class="tainacan-chatgpt-prompt-example">
                                    <h4><?php echo esc_html__('Documento Histórico', 'tainacan-chatgpt'); ?></h4>
                                    <pre><?php echo esc_html__('Analise este documento histórico e identifique: tipo de documento, data de criação, autor/órgão emissor, destinatário, contexto histórico, conteúdo principal, importância histórica, idioma original, e elementos visuais distintivos (selos, assinaturas, carimbos). Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?></pre>
                                    <button type="button" class="button button-secondary use-prompt" data-target="text" data-prompt="<?php echo esc_attr__('Analise este documento histórico e identifique: tipo de documento, data de criação, autor/órgão emissor, destinatário, contexto histórico, conteúdo principal, importância histórica, idioma original, e elementos visuais distintivos (selos, assinaturas, carimbos). Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'); ?>">
                                        <?php echo esc_html__('Usar Este Prompt', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php submit_button(__('Salvar Configurações Avançadas', 'tainacan-chatgpt'), 'primary', 'submit', true); ?>
                </form>
            </div>
        </div>
        <?php
    }
    
    /**
     * Testa a conexão com a API OpenAI
     */
    public function ajax_test_api() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }
        
        $api = new Tainacan_ChatGPT_API();
        $test_result = $api->test_connection();
        
        if ($test_result['success']) {
            wp_send_json_success(__('Conexão com a API estabelecida com sucesso!', 'tainacan-chatgpt'));
        } else {
            wp_send_json_error($test_result['message']);
        }
    }
    
    /**
     * Limpa o cache do plugin
     */
    public function ajax_clear_cache() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }
        
        $cache = new Tainacan_ChatGPT_Cache();
        $cleared = $cache->clear_all();
        
        if ($cleared) {
            wp_send_json_success(__('Cache limpo com sucesso!', 'tainacan-chatgpt'));
        } else {
            wp_send_json_error(__('Erro ao limpar cache.', 'tainacan-chatgpt'));
        }
    }
    
    /**
     * Obtém estatísticas de uso atualizadas
     */
    public function ajax_get_usage_stats() {
        check_ajax_referer('tainacan_chatgpt_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }
        
        $logger = new Tainacan_ChatGPT_Logger();
        $usage_stats = $logger->get_usage_stats();
        
        wp_send_json_success($usage_stats);
    }
}