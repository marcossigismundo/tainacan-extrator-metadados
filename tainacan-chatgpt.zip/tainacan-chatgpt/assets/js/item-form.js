/**
 * Tainacan ChatGPT - Item Form JavaScript
 * @version 3.1.1
 */
(function($) {
    'use strict';

    const TainacanChatGPTApp = {
        // Estado
        state: {
            itemId: null,
            collectionId: null,
            attachmentId: null,
            documentInfo: null,
            isAnalyzing: false,
            lastResult: null,
        },

        // Elementos DOM
        elements: {},

        /**
         * Inicializa a aplicação
         */
        init() {
            this.cacheElements();
            this.bindEvents();
            this.observeUrlChanges();
            this.extractContext();

            if (TainacanChatGPT.debug) {
                console.log('[TainacanChatGPT] Initialized', this.state);
            }
        },

        /**
         * Cache de elementos DOM
         */
        cacheElements() {
            this.elements = {
                widget: $('#tainacan-chatgpt-widget'),
                analyzeBtn: $('#tainacan-chatgpt-analyze'),
                refreshBtn: $('#tainacan-chatgpt-refresh'),
                status: $('#tainacan-chatgpt-status'),
                results: $('#tainacan-chatgpt-results'),
                resultsContent: $('#tainacan-chatgpt-results-content'),
                exifContent: $('#tainacan-chatgpt-exif-content'),
                cacheBadge: $('#tainacan-chatgpt-cache-badge'),
                documentInfo: $('#tainacan-chatgpt-document-info'),
                docType: $('#tainacan-chatgpt-doc-type'),
                docName: $('#tainacan-chatgpt-doc-name'),
                tabExif: $('#tainacan-chatgpt-tab-exif'),
                modelInfo: $('#tainacan-chatgpt-model'),
                tokensInfo: $('#tainacan-chatgpt-tokens'),
                copyAllBtn: $('#tainacan-chatgpt-copy-all'),
            };
        },

        /**
         * Binding de eventos
         */
        bindEvents() {
            // Botão de análise
            $(document).on('click', '#tainacan-chatgpt-analyze', (e) => {
                e.preventDefault();
                this.analyze(false);
            });

            // Botão de refresh (força nova análise)
            $(document).on('click', '#tainacan-chatgpt-refresh', (e) => {
                e.preventDefault();
                this.analyze(true);
            });

            // Tabs
            $(document).on('click', '.tainacan-chatgpt-tab', (e) => {
                this.switchTab($(e.currentTarget).data('tab'));
            });

            // Copiar valor individual
            $(document).on('click', '.tainacan-chatgpt-copy-btn', (e) => {
                this.copyValue($(e.currentTarget));
            });

            // Copiar todos
            $(document).on('click', '#tainacan-chatgpt-copy-all', () => {
                this.copyAllValues();
            });
        },

        /**
         * Observa mudanças na URL (navegação SPA)
         */
        observeUrlChanges() {
            // Hash change
            $(window).on('hashchange', () => {
                this.extractContext();
            });

            // MutationObserver para detectar mudanças no DOM
            const observer = new MutationObserver((mutations) => {
                let shouldUpdate = false;

                mutations.forEach((mutation) => {
                    if (mutation.addedNodes.length) {
                        mutation.addedNodes.forEach((node) => {
                            if (node.nodeType === 1 && (
                                node.classList?.contains('tainacan-form') ||
                                node.id === 'tainacan-chatgpt-widget' ||
                                node.querySelector?.('#tainacan-chatgpt-widget')
                            )) {
                                shouldUpdate = true;
                            }
                        });
                    }
                });

                if (shouldUpdate) {
                    this.cacheElements();
                    this.extractContext();
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true,
            });
        },

        /**
         * Extrai contexto da página (item_id, collection_id)
         */
        extractContext() {
            // Reset
            this.state.itemId = null;
            this.state.collectionId = null;
            this.state.documentInfo = null;

            // Método 1: URL hash (#/collections/X/items/Y/edit)
            const hash = window.location.hash;
            const hashMatch = hash.match(/collections\/(\d+)\/items\/(\d+)/);
            if (hashMatch) {
                this.state.collectionId = parseInt(hashMatch[1]);
                this.state.itemId = parseInt(hashMatch[2]);
            }

            // Método 2: Query params
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('item')) {
                this.state.itemId = parseInt(urlParams.get('item'));
            }
            if (urlParams.get('post')) {
                this.state.itemId = parseInt(urlParams.get('post'));
            }

            // Método 3: Data attributes
            const $container = $('[data-item-id]');
            if ($container.length) {
                this.state.itemId = parseInt($container.data('item-id'));
            }
            const $collection = $('[data-collection-id]');
            if ($collection.length) {
                this.state.collectionId = parseInt($collection.data('collection-id'));
            }

            // Método 4: tainacan_plugin global
            if (typeof window.tainacan_plugin !== 'undefined') {
                if (window.tainacan_plugin.item_id) {
                    this.state.itemId = parseInt(window.tainacan_plugin.item_id);
                }
                if (window.tainacan_plugin.collection_id) {
                    this.state.collectionId = parseInt(window.tainacan_plugin.collection_id);
                }
            }

            if (TainacanChatGPT.debug) {
                console.log('[TainacanChatGPT] Context extracted:', this.state);
            }

            // Detecta documento se temos item_id
            if (this.state.itemId) {
                this.detectDocument();
            }
        },

        /**
         * Detecta documento do item
         */
        async detectDocument() {
            if (!this.state.itemId) return;

            try {
                const response = await $.ajax({
                    url: TainacanChatGPT.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'tainacan_chatgpt_get_item_document',
                        nonce: TainacanChatGPT.nonce,
                        item_id: this.state.itemId,
                    },
                });

                if (response.success && response.data) {
                    this.state.documentInfo = response.data;
                    this.state.attachmentId = response.data.id;
                    this.showDocumentInfo(response.data);
                }
            } catch (error) {
                if (TainacanChatGPT.debug) {
                    console.log('[TainacanChatGPT] No document found');
                }
            }
        },

        /**
         * Exibe informações do documento detectado
         */
        showDocumentInfo(doc) {
            if (!doc) return;

            const typeLabels = {
                image: TainacanChatGPT.texts.image,
                pdf: TainacanChatGPT.texts.pdf,
                text: TainacanChatGPT.texts.text,
            };

            const typeIcons = {
                image: 'dashicons-format-image',
                pdf: 'dashicons-pdf',
                text: 'dashicons-media-text',
            };

            this.elements.docType.html(
                `<span class="dashicons ${typeIcons[doc.type] || 'dashicons-media-default'}"></span> ` +
                (typeLabels[doc.type] || doc.type)
            );
            this.elements.docName.text(doc.title || '');
            this.elements.documentInfo.show();
        },

        /**
         * Executa análise
         */
        async analyze(forceRefresh = false) {
            if (this.state.isAnalyzing) return;

            // Verifica se temos item ou attachment
            if (!this.state.itemId && !this.state.attachmentId) {
                this.showError(TainacanChatGPT.texts.noDocument);
                return;
            }

            this.state.isAnalyzing = true;
            this.showLoading();

            let hasError = false;

            try {
                const response = await $.ajax({
                    url: TainacanChatGPT.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'tainacan_chatgpt_analyze',
                        nonce: TainacanChatGPT.nonce,
                        item_id: this.state.itemId,
                        attachment_id: this.state.attachmentId,
                        collection_id: this.state.collectionId,
                        force_refresh: forceRefresh,
                    },
                });

                if (response.success) {
                    this.state.lastResult = response.data.result;
                    this.displayResults(response.data.result, response.data.from_cache);
                } else {
                    hasError = true;
                    this.showError(response.data || TainacanChatGPT.texts.error);
                }
            } catch (error) {
                hasError = true;
                console.error('[TainacanChatGPT] Analysis error:', error);
                this.showError(error.responseJSON?.data || TainacanChatGPT.texts.error);
            } finally {
                this.state.isAnalyzing = false;
                // Só esconde o loading se não houver erro (o erro já mostra sua própria mensagem)
                if (!hasError) {
                    this.hideLoading();
                }
            }
        },

        /**
         * Exibe resultados
         */
        displayResults(result, fromCache) {
            // Cache badge
            if (fromCache) {
                this.elements.cacheBadge.show();
            } else {
                this.elements.cacheBadge.hide();
            }

            // Metadados AI
            if (result.ai_metadata) {
                this.renderMetadata(result.ai_metadata);
            }

            // EXIF
            if (result.exif && Object.keys(result.exif).length > 0) {
                this.elements.tabExif.show();
                this.renderExif(result.exif);
            } else {
                this.elements.tabExif.hide();
            }

            // Info da análise
            if (result.model) {
                let modelHtml = `<span class="dashicons dashicons-cloud"></span> ${result.model}`;

                // Mostra método de extração para PDFs
                if (result.extraction_method) {
                    const methodLabels = {
                        text_extraction: 'Texto',
                        visual_analysis: 'Visual',
                        vision: 'Vision',
                        text: 'Texto'
                    };
                    const methodLabel = methodLabels[result.extraction_method] || result.extraction_method;
                    modelHtml += ` <span class="tainacan-chatgpt-method-badge">${methodLabel}</span>`;
                }

                this.elements.modelInfo.html(modelHtml);
            }
            if (result.tokens_used) {
                this.elements.tokensInfo.html(
                    `<span class="dashicons dashicons-performance"></span> ${result.tokens_used} ${TainacanChatGPT.texts.tokens}`
                );
            }

            this.elements.results.show();
            this.switchTab('ai');
        },

        /**
         * Renderiza metadados extraídos
         */
        renderMetadata(metadata) {
            const $container = this.elements.resultsContent;
            $container.empty();

            Object.entries(metadata).forEach(([key, value], index) => {
                const formattedLabel = this.formatLabel(key);
                const formattedValue = this.formatValue(value);
                const rawValue = typeof value === 'string' ? value : JSON.stringify(value);
                const isEmpty = value === null || value === undefined ||
                               (Array.isArray(value) && value.length === 0) ||
                               value === '';

                const $item = $(`
                    <div class="tainacan-chatgpt-metadata-item ${isEmpty ? 'empty' : ''}" style="animation-delay: ${index * 0.05}s">
                        <div class="tainacan-chatgpt-metadata-header">
                            <span class="tainacan-chatgpt-metadata-label">${formattedLabel}</span>
                        </div>
                        <div class="tainacan-chatgpt-metadata-body">
                            <div class="tainacan-chatgpt-metadata-value">${formattedValue}</div>
                            <div class="tainacan-chatgpt-metadata-actions">
                                <button type="button" class="button button-small tainacan-chatgpt-copy-btn"
                                        data-value="${this.escapeHtml(rawValue)}"
                                        title="${TainacanChatGPT.texts.copy}">
                                    <span class="dashicons dashicons-clipboard"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                `);

                $container.append($item);
            });
        },

        /**
         * Renderiza dados EXIF
         */
        renderExif(exif) {
            const $container = this.elements.exifContent;
            $container.empty();

            const renderSection = (title, data) => {
                if (!data || Object.keys(data).length === 0) return;

                const $section = $(`
                    <div class="tainacan-chatgpt-exif-section">
                        <h6>${title}</h6>
                        <div class="tainacan-chatgpt-exif-grid"></div>
                    </div>
                `);

                const $grid = $section.find('.tainacan-chatgpt-exif-grid');

                Object.entries(data).forEach(([key, value]) => {
                    if (value !== null && value !== undefined) {
                        $grid.append(`
                            <div class="tainacan-chatgpt-exif-item">
                                <span class="tainacan-chatgpt-exif-label">${this.formatLabel(key)}</span>
                                <span class="tainacan-chatgpt-exif-value">${this.escapeHtml(String(value))}</span>
                            </div>
                        `);
                    }
                });

                $container.append($section);
            };

            const sectionTitles = {
                camera: 'Camera',
                captura: 'Captura',
                imagem: 'Imagem',
                gps: 'Localização',
                autoria: 'Autoria',
            };

            Object.entries(exif).forEach(([section, data]) => {
                renderSection(sectionTitles[section] || section, data);
            });

            // Link do Google Maps
            if (exif.gps?.google_maps_link) {
                $container.append(`
                    <div class="tainacan-chatgpt-exif-map">
                        <a href="${exif.gps.google_maps_link}" target="_blank" class="button">
                            <span class="dashicons dashicons-location"></span>
                            Ver no Google Maps
                        </a>
                    </div>
                `);
            }
        },

        /**
         * Alterna entre tabs
         */
        switchTab(tabId) {
            $('.tainacan-chatgpt-tab').removeClass('active');
            $(`.tainacan-chatgpt-tab[data-tab="${tabId}"]`).addClass('active');

            $('.tainacan-chatgpt-tab-content').removeClass('active');
            $(`#tainacan-chatgpt-content-${tabId}`).addClass('active');
        },

        /**
         * Copia valor para clipboard
         */
        async copyValue($btn) {
            const value = $btn.data('value');

            try {
                await navigator.clipboard.writeText(value);
                this.showCopySuccess($btn);
            } catch (error) {
                // Fallback
                const $temp = $('<textarea>').val(value).appendTo('body').select();
                document.execCommand('copy');
                $temp.remove();
                this.showCopySuccess($btn);
            }
        },

        /**
         * Copia todos os valores
         */
        async copyAllValues() {
            if (!this.state.lastResult?.ai_metadata) return;

            const text = Object.entries(this.state.lastResult.ai_metadata)
                .map(([key, value]) => {
                    const formattedValue = typeof value === 'string' ? value : JSON.stringify(value);
                    return `${this.formatLabel(key)}: ${formattedValue}`;
                })
                .join('\n');

            try {
                await navigator.clipboard.writeText(text);
                this.showToast(TainacanChatGPT.texts.allCopied);
            } catch (error) {
                const $temp = $('<textarea>').val(text).appendTo('body').select();
                document.execCommand('copy');
                $temp.remove();
                this.showToast(TainacanChatGPT.texts.allCopied);
            }
        },

        /**
         * Feedback visual de cópia
         */
        showCopySuccess($btn) {
            const $icon = $btn.find('.dashicons');
            $icon.removeClass('dashicons-clipboard').addClass('dashicons-yes');
            $btn.addClass('copied');

            setTimeout(() => {
                $icon.removeClass('dashicons-yes').addClass('dashicons-clipboard');
                $btn.removeClass('copied');
            }, 1500);
        },

        /**
         * Mostra estado de loading
         */
        showLoading() {
            this.elements.analyzeBtn.prop('disabled', true);
            this.elements.refreshBtn.prop('disabled', true);
            this.elements.status.show();
            this.elements.results.hide();
        },

        /**
         * Esconde loading
         */
        hideLoading() {
            this.elements.analyzeBtn.prop('disabled', false);
            this.elements.refreshBtn.prop('disabled', false);
            this.elements.status.hide();
        },

        /**
         * Mostra erro
         */
        showError(message) {
            // Reabilita os botões
            this.elements.analyzeBtn.prop('disabled', false);
            this.elements.refreshBtn.prop('disabled', false);

            this.elements.status.html(`
                <div class="tainacan-chatgpt-error">
                    <span class="dashicons dashicons-warning"></span>
                    <div class="tainacan-chatgpt-error-text">
                        <strong>Erro</strong>
                        <span>${message}</span>
                    </div>
                </div>
            `).show();

            // Aumentado para 10 segundos para dar tempo de ler a mensagem
            setTimeout(() => {
                this.elements.status.fadeOut();
            }, 10000);
        },

        /**
         * Mostra toast notification
         */
        showToast(message) {
            const $toast = $(`
                <div class="tainacan-chatgpt-toast">
                    <span class="dashicons dashicons-yes-alt"></span>
                    ${message}
                </div>
            `).appendTo('body');

            setTimeout(() => {
                $toast.addClass('visible');
            }, 10);

            setTimeout(() => {
                $toast.removeClass('visible');
                setTimeout(() => $toast.remove(), 300);
            }, 2000);
        },

        /**
         * Formata label do metadado
         */
        formatLabel(key) {
            return key
                .replace(/_/g, ' ')
                .replace(/([A-Z])/g, ' $1')
                .replace(/^./, str => str.toUpperCase())
                .trim();
        },

        /**
         * Formata valor para exibição
         */
        formatValue(value) {
            if (value === null || value === undefined || value === '') {
                return '<span class="tainacan-chatgpt-empty-value">-</span>';
            }

            if (Array.isArray(value)) {
                if (value.length === 0) {
                    return '<span class="tainacan-chatgpt-empty-value">-</span>';
                }
                return value.map(v => `<span class="tainacan-chatgpt-tag">${this.escapeHtml(String(v))}</span>`).join(' ');
            }

            if (typeof value === 'object') {
                return `<pre class="tainacan-chatgpt-json">${this.escapeHtml(JSON.stringify(value, null, 2))}</pre>`;
            }

            return this.escapeHtml(String(value));
        },

        /**
         * Escape HTML
         */
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },
    };

    // Inicializa quando DOM estiver pronto
    $(document).ready(() => {
        TainacanChatGPTApp.init();
    });

})(jQuery);
