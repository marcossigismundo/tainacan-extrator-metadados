/**
 * Scripts para integração com a interface do Tainacan
 */
(function($) {
    'use strict';
    
    // Registro único do evento delegado
    let eventRegistered = false;
	
	// Cache em memória para a sessão atual
const memoryCache = {};
    
    /**
     * Adiciona o botão na interface de edição de itens
     */
    function addAnalyzeButton() {
        // Verifica se o modo de debug está ativado
        const debug = TainacanChatGPT.debug_enabled === true;
        
        // Aguarda o carregamento completo da interface do Tainacan
        const $documentField = $('.document-field-content, .field-type-document, .document-field');
        
        if ($documentField.length === 0) {
            // Tenta novamente após um intervalo
            setTimeout(addAnalyzeButton, 1000);
            return;
        }
        
        // Verifica se já existe um botão
        if ($('#tainacan-chatgpt-analyze-btn').length > 0) {
            return;
        }
        
        // Cria o botão e o adiciona ao lado do documento principal
        const $button = $(`
            <button id="tainacan-chatgpt-analyze-btn" class="button tainacan-chatgpt-analyze-button">
                <span class="dashicons dashicons-text"></span>
                ${TainacanChatGPT.texts.analyzeWithChatGPT}
            </button>
        `);
        
        // Adiciona o botão após o campo de documento ou como último recurso no container de metadados
        if ($documentField.length > 0) {
            $documentField.after($button);
        } else {
            // Tenta encontrar outros pontos de inserção
            const $metadataContainer = $('.metadata-container, .tainacan-item-metadata-container, .item-metadata-form');
            if ($metadataContainer.length > 0) {
                $metadataContainer.append($button);
            }
        }
        
        // Adiciona evento de clique explícito apenas ao botão recém-criado
        $('#tainacan-chatgpt-analyze-btn').on('click', handleAnalyzeButtonClick);
        
        // Cria a sidebar se ainda não existir
        if (!$('#tainacan-chatgpt-sidebar').length) {
            createSidebar();
        }
        
        if (debug) {
            console.log('Tainacan ChatGPT: Botão de análise adicionado com sucesso');
        }
    }
    
    /**
     * Manipula o clique no botão de análise
     */
    function handleAnalyzeButtonClick(e) {
        e.preventDefault();
        const debug = TainacanChatGPT.debug_enabled === true;
        
        if (debug) {
            console.log('Botão de análise clicado');
        }
        
        // Encontra o ID do anexo (documento)
        let attachmentId = findAttachmentId();
        
        if (!attachmentId) {
            alert(TainacanChatGPT.texts.noDocumentFound);
            return;
        }
        
        if (debug) {
            console.log('ID do anexo para análise:', attachmentId);
        }
        
        // Cria sidebar se não existir
        if (!$('#tainacan-chatgpt-sidebar').length) {
            createSidebar();
        }
        
        openSidebar();
        
        // Reseta o indicador de progresso
        updateProgressIndicator('extraction');
        
        // Obtém o tipo de análise selecionado
        const analysisType = $('#tainacan-chatgpt-analysis-type').val();
        
        // Analisa o anexo
        analyzeAttachment(attachmentId, false, analysisType);
    }
    
    /**
     * Atualiza o indicador de progresso
     */
    function updateProgressIndicator(step) {
        // Primeiro, remove a classe 'active' de todas as etapas
        $('.tainacan-chatgpt-progress-step').removeClass('active');
        
        // Marca a etapa atual e todas as anteriores como ativas
        const steps = ['extraction', 'verification', 'validation', 'completion'];
        const currentIndex = steps.indexOf(step);
        
        for (let i = 0; i <= currentIndex; i++) {
            $(`.tainacan-chatgpt-progress-step[data-step="${steps[i]}"]`).addClass('active');
        }
    }

    /**
     * Encontra o ID do anexo na página atual
     */
    function findAttachmentId() {
        const debug = TainacanChatGPT.debug_enabled === true;
        
        if (debug) {
            console.log('Tentando encontrar ID do anexo...');
            
            // Registrar todos os elementos que podem conter informações do documento
            console.log('Elementos #tainacan-document-file-id:', $('#tainacan-document-file-id').length);
            console.log('Elementos .document-file-thumbnail:', $('.document-file-thumbnail').length);
            console.log('Elementos input[name="document_id"]:', $('input[name="document_id"]').length);
            console.log('Elementos [data-attachment-id]:', $('[data-attachment-id]').length);
            console.log('Elementos [data-document-id]:', $('[data-document-id]').length);
            console.log('Elementos .document-field-content iframe:', $('.document-field-content iframe').length);
            
            // Registrar metadados nos elementos relevantes
            if ($('.document-file-thumbnail').length) {
                console.log('document-file-thumbnail data:', $('.document-file-thumbnail').data());
            }
        }
        
        // Método 1: Procurar por documento_id em elementos específicos do Tainacan
        if ($('#tainacan-document-file-id').length) {
            const id = $('#tainacan-document-file-id').val();
            if (debug) console.log('ID encontrado em #tainacan-document-file-id:', id);
            return id;
        }
        
        // Método 2: Procurar atributos de dados em thumbnails de documentos
        if ($('.document-file-thumbnail').length) {
            const dataId = $('.document-file-thumbnail').data('document-id');
            if (dataId) {
                if (debug) console.log('ID encontrado em .document-file-thumbnail[data-document-id]:', dataId);
                return dataId;
            }
        }
        
        // Método 3: Procurar IDs em inputs ou atributos ocultos
        const attachmentFields = [
            'input[name="document_id"]', 
            '[data-attachment-id]', 
            '[data-document-id]',
            'input[name="attachment_id"]',
            '.tainacan-media-attachment',
            '[data-id]',
            '.document-main-content [data-id]'
        ];
        
        for (const selector of attachmentFields) {
            const $field = $(selector).first();
            if ($field.length) {
                const id = $field.val() || $field.data('attachment-id') || $field.data('document-id') || $field.data('id');
                if (id) {
                    if (debug) console.log(`ID encontrado em ${selector}:`, id);
                    return id;
                }
            }
        }
        
        // Método 4: Procurar atributos específicos do Tainacan
        const $documentDisplay = $('.tainacan-item-document-container, .document-display, .document-thumbnail');
        if ($documentDisplay.length) {
            const attributes = [
                'data-document-id', 
                'data-attachment-id', 
                'data-id',
                'data-item-document-id'
            ];
            
            for (const attr of attributes) {
                const id = $documentDisplay.attr(attr) || $documentDisplay.data(attr.replace('data-', ''));
                if (id) {
                    if (debug) console.log(`ID encontrado em elemento de documento [${attr}]:`, id);
                    return id;
                }
            }
        }
        
        // Método 5: Procurar na URL do iframe de documentos
        const $documentIframe = $('.document-field-content iframe, .document-field iframe, .tainacan-item-document-container iframe');
        if ($documentIframe.length) {
            if (debug) console.log('Iframe de documento encontrado. src:', $documentIframe.attr('src'));
            const src = $documentIframe.attr('src');
            if (src) {
                // Tenta vários padrões de URL
                const patterns = [
                    /\/(document|attachment)\/(\d+)/,
                    /id=(\d+)/,
                    /\/(documents?|attachments?)\/(\d+)/,
                    /post=(\d+)/
                ];
                
                for (const pattern of patterns) {
                    const matches = src.match(pattern);
                    if (matches && matches[1]) {
                        const idIndex = pattern.toString().indexOf('(\\d+)') === pattern.toString().indexOf('(\\d+)') ? 1 : 2;
                        if (debug) console.log(`ID encontrado no iframe src usando pattern ${pattern}:`, matches[idIndex]);
                        return matches[idIndex];
                    }
                }
            }
        }
        
        // Método 6: Tentar extrair do HTML da página
        const pageHtml = $('body').html();
        const patterns = [
            /document[_\-]id["\s:=]+["']?(\d+)/i,
            /attachment[_\-]id["\s:=]+["']?(\d+)/i,
            /(?:wp-image-|document_id=|document-id=)(\d+)/i,
            /tainacan[_\-]item[_\-]document[_\-]id["\s:=]+["']?(\d+)/i
        ];
        
        for (const pattern of patterns) {
            const matches = pageHtml.match(pattern);
            if (matches && matches[1]) {
                if (debug) console.log(`ID encontrado no HTML da página usando pattern ${pattern}:`, matches[1]);
                return matches[1];
            }
        }
        
        if (debug) {
            // Método 7: Verificar o console do navegador para ver a estrutura da página
            console.log('---------- DEBUG DOM ----------');
            console.log('Elementos documento encontrados:');
            console.log('.document-field-content:', $('.document-field-content').length);
            console.log('.field-type-document:', $('.field-type-document').length);
            console.log('.document-field:', $('.document-field').length);
            console.log('.tainacan-item-document-container:', $('.tainacan-item-document-container').length);
            
            // Método 8: Se tudo falhar, tentar obter dados do documento do Vue
            if (typeof window.tainacan_plugin !== 'undefined' && window.tainacan_plugin.item_metadata) {
                console.log('Encontrou objeto tainacan_plugin, tentando extrair document_id');
                console.log('tainacan_plugin:', window.tainacan_plugin);
            }
            
            console.log('Nenhum ID de anexo encontrado!');
        }
        
        return null;
    }
    
/**
 * Analisa um anexo
 */
function analyzeAttachment(attachmentId, forceRefresh, analysisType = 'auto') {
    const debug = TainacanChatGPT.debug_enabled === true;
    
    // Verificar cache em memória se não for forçada atualização
    const cacheKey = `${attachmentId}_${analysisType}`;
    if (!forceRefresh && memoryCache[cacheKey]) {
        $('#tainacan-chatgpt-loading').hide();
        renderResults(memoryCache[cacheKey], true);
        return;
    }
    
    if (debug) {
        console.log('Analisando anexo ID:', attachmentId);
        console.log('Tipo de análise:', analysisType);
    }
    
    $('#tainacan-chatgpt-loading').show();
    $('#tainacan-chatgpt-results').html('');
    
    try {
        // Atualizar para a etapa de extração
        updateProgressIndicator('extraction');
        
        $.ajax({
            url: TainacanChatGPT.ajaxUrl,
            type: 'POST',
            data: {
                action: 'tainacan_chatgpt_analyze_attachment',
                nonce: TainacanChatGPT.nonce,
                attachment_id: attachmentId,
                force_refresh: forceRefresh,
                analysis_type: analysisType
            },
			
			  beforeSend: function() {
        // Simular progressão pelas etapas intermediárias
        setTimeout(function() { 
            updateProgressIndicator('verification'); 
        }, 1500);
        
        setTimeout(function() { 
            updateProgressIndicator('validation'); 
        }, 3000);
    },
			
			
            complete: function(jqXHR, textStatus) {
                if (debug) {
                    console.log('AJAX status:', textStatus);
                    console.log('Response:', jqXHR.responseText);
                }
            },
            success: function(response) {
                if (debug) {
                    console.log('AJAX success:', response);
                }
                
                $('#tainacan-chatgpt-loading').hide();
                
                // Atualize para a etapa final quando a análise for concluída
                updateProgressIndicator('completion');
                
                if (response.success) {
                    // Armazenar no cache em memória
                    memoryCache[cacheKey] = response.data;
                    renderResults(response.data, response.data.from_cache);
                } else {
                    $('#tainacan-chatgpt-results').html(`
                        <div class="tainacan-chatgpt-error">
                            <p>${response.data}</p>
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                if (debug) {
                    console.error('Erro ao analisar anexo:', error);
                    console.error('Status:', status);
                    console.error('Resposta:', xhr.responseText);
                }
                
                $('#tainacan-chatgpt-loading').hide();
                $('#tainacan-chatgpt-results').html(`
                    <div class="tainacan-chatgpt-error">
                        <p>${TainacanChatGPT.texts.errorOccurred}</p>
                    </div>
                `);
            }
        });
    } catch (error) {
        if (debug) {
            console.error('Erro AJAX geral:', error);
        }
        
        $('#tainacan-chatgpt-loading').hide();
        $('#tainacan-chatgpt-results').html(`
            <div class="tainacan-chatgpt-error">
                <p>Erro ao enviar requisição: ${error.message}</p>
            </div>
        `);
    }
}
    
    /**
     * Cria a sidebar para mostrar os resultados
     */
    function createSidebar() {
        const $sidebar = $(`
            <div id="tainacan-chatgpt-sidebar" class="tainacan-chatgpt-sidebar">
                <div class="tainacan-chatgpt-sidebar-header">
                    <h2>${TainacanChatGPT.texts.metadataResults}</h2>
                    <div class="tainacan-chatgpt-dropdown">
                        <label for="tainacan-chatgpt-analysis-type">
                            ${TainacanChatGPT.texts.analysisType}:
                        </label>
                        <select id="tainacan-chatgpt-analysis-type">
                            <option value="auto">${TainacanChatGPT.texts.analysisTypeAuto}</option>
                            <option value="pdf">${TainacanChatGPT.texts.analysisTypePdf}</option>
                            <option value="image">${TainacanChatGPT.texts.analysisTypeImage}</option>
                        </select>
                    </div>
                    <div class="tainacan-chatgpt-sidebar-actions">
                        <button id="tainacan-chatgpt-refresh" class="button button-secondary" title="${TainacanChatGPT.texts.refreshTooltip}">
                            <span class="dashicons dashicons-update"></span>
                            ${TainacanChatGPT.texts.refreshAnalysis}
                        </button>
                        <button id="tainacan-chatgpt-clear-cache" class="button button-secondary" title="${TainacanChatGPT.texts.clearCacheTooltip}">
                            <span class="dashicons dashicons-trash"></span>
                            ${TainacanChatGPT.texts.clearCache}
                        </button>
                        <button id="tainacan-chatgpt-close" class="button button-secondary">
                            <span class="dashicons dashicons-no"></span>
                            ${TainacanChatGPT.texts.closePanel}
                        </button>
                    </div>
                </div>
                <div class="tainacan-chatgpt-sidebar-content">
                    <div id="tainacan-chatgpt-progress" class="tainacan-chatgpt-progress">
                        <div class="tainacan-chatgpt-progress-step active" data-step="extraction">
                            <span class="step-number">1</span>
                            <span class="step-label">${TainacanChatGPT.texts.stepExtraction}</span>
                        </div>
                        <div class="tainacan-chatgpt-progress-step" data-step="verification">
                            <span class="step-number">2</span>
                            <span class="step-label">${TainacanChatGPT.texts.stepVerification}</span>
                        </div>
                        <div class="tainacan-chatgpt-progress-step" data-step="validation">
                            <span class="step-number">3</span>
                            <span class="step-label">${TainacanChatGPT.texts.stepValidation}</span>
                        </div>
                        <div class="tainacan-chatgpt-progress-step" data-step="completion">
                            <span class="step-number">4</span>
                            <span class="step-label">${TainacanChatGPT.texts.stepCompletion}</span>
                        </div>
                    </div>
                    <div id="tainacan-chatgpt-loading" class="tainacan-chatgpt-loading">
                        <div class="spinner is-active"></div>
                        <p>${TainacanChatGPT.texts.analyzing}</p>
                    </div>
                    <div id="tainacan-chatgpt-results" class="tainacan-chatgpt-results"></div>
                </div>
            </div>
        `);
        
        $('body').append($sidebar);
        
        // Adiciona eventos
        $('#tainacan-chatgpt-close').off('click').on('click', function(e) {
            e.preventDefault();
            closeSidebar();
        });
        
        // Analisar novamente (usa cache se existir)
        $('#tainacan-chatgpt-refresh').off('click').on('click', function(e) {
            e.preventDefault();
            const attachmentId = findAttachmentId();
            if (attachmentId) {
                const analysisType = $('#tainacan-chatgpt-analysis-type').val();
                // false = não força atualização, usa cache se existir
                analyzeAttachment(attachmentId, false, analysisType);
            } else {
                $('#tainacan-chatgpt-results').html(`
                    <div class="tainacan-chatgpt-error">
                        <p>${TainacanChatGPT.texts.noDocumentFound}</p>
                    </div>
                `);
            }
        });
        
        // Limpar cache e analisar novamente
        $('#tainacan-chatgpt-clear-cache').off('click').on('click', function(e) {
            e.preventDefault();
            const attachmentId = findAttachmentId();
            if (attachmentId) {
                clearItemCache(attachmentId);
            } else {
                $('#tainacan-chatgpt-results').html(`
                    <div class="tainacan-chatgpt-error">
                        <p>${TainacanChatGPT.texts.noDocumentFound}</p>
                    </div>
                `);
            }
        });
    }
    
    /**
     * Limpa o cache de um item específico
     */
    function clearItemCache(attachmentId) {
        $('#tainacan-chatgpt-loading').show();
        $('#tainacan-chatgpt-results').html('');
        
        const debug = TainacanChatGPT.debug_enabled === true;
        if (debug) console.log('Limpando cache para ID:', attachmentId);
        
        $.ajax({
            url: TainacanChatGPT.ajaxUrl,
            type: 'POST',
            data: {
                action: 'tainacan_chatgpt_clear_item_cache',
                nonce: TainacanChatGPT.nonce,
                attachment_id: attachmentId
            },
success: function(response) {
    if (debug) console.log('Resposta limpeza de cache:', response);
    
    if (response.success) {
        // Limpar também o cache em memória
        const cacheKey = `${attachmentId}_${$('#tainacan-chatgpt-analysis-type').val()}`;
        if (memoryCache[cacheKey]) {
            delete memoryCache[cacheKey];
        }
        
        // Notificação de sucesso temporária
        const $notification = $(`
            <div class="tainacan-chatgpt-notification success">
                <span class="dashicons dashicons-yes"></span>
                ${TainacanChatGPT.texts.cacheCleared}
            </div>
        `);
        
        $('#tainacan-chatgpt-sidebar').append($notification);
        
        setTimeout(function() {
            $notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 2000);
                    
                    // Após limpar o cache, analisa novamente com force_refresh=true
                    const analysisType = $('#tainacan-chatgpt-analysis-type').val();
                    analyzeAttachment(attachmentId, true, analysisType);
                } else {
                    $('#tainacan-chatgpt-loading').hide();
                    $('#tainacan-chatgpt-results').html(`
                        <div class="tainacan-chatgpt-error">
                            <p>${response.data}</p>
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                if (debug) {
                    console.error('Erro ao limpar cache:', error);
                    console.error('Status:', status);
                    console.error('Resposta:', xhr.responseText);
                }
                
                $('#tainacan-chatgpt-loading').hide();
                $('#tainacan-chatgpt-results').html(`
                    <div class="tainacan-chatgpt-error">
                        <p>${TainacanChatGPT.texts.errorOccurred}</p>
                    </div>
                `);
            }
        });
    }
    
    /**
     * Abre a sidebar
     */
function openSidebar() {
    const $sidebar = $('#tainacan-chatgpt-sidebar');
    
    // Se não existir, crie a sidebar
    if ($sidebar.length === 0) {
        createSidebar();
    } else {
        // Apenas mostre a sidebar existente
        $sidebar.addClass('open');
        $sidebar.attr('style', 'right: 0 !important; display: block !important; z-index: 999999 !important;');
    }
    
    $('body').addClass('tainacan-chatgpt-sidebar-open');
    
    // Reposicionar como filho direto do body se necessário
    if ($sidebar.parent().prop('tagName') !== 'BODY') {
        $sidebar.detach().appendTo('body');
    }
    
    // Apenas limpe resultados e mostre loading se não houver resultados já exibidos
    if ($('#tainacan-chatgpt-results').children().length === 0) {
        $('#tainacan-chatgpt-results').html('');
        $('#tainacan-chatgpt-loading').show();
    }
}
    
    /**
     * Fecha a sidebar
     */
    function closeSidebar() {
        const $sidebar = $('#tainacan-chatgpt-sidebar');
        
        // Remover estilos inline e classes
        $sidebar.removeClass('open')
               .attr('style', 'right: -450px !important; display: none !important;');
        
        $('body').removeClass('tainacan-chatgpt-sidebar-open');
        
        // Forçar fechamento
        setTimeout(function() {
            if ($sidebar.hasClass('open')) {
                $sidebar.removeClass('open').hide();
            }
        }, 100);
    }
    
    /**
     * Renderiza os resultados
     */
    function renderResults(data, fromCache) {
        const $results = $('#tainacan-chatgpt-results');
        const debug = TainacanChatGPT.debug_enabled === true;
        
        // Log para debug
        if (debug) console.log('Dados recebidos para renderização:', data);
        
        // Atualizar para a etapa final
        updateProgressIndicator('completion');
        
        // Não avançar se os dados não existirem
        if (!data || !data.metadata) {
            if (debug) console.log('Dados inválidos recebidos:', data);
            
            // Adiciona mensagem de erro
            $results.html(`
                <div class="tainacan-chatgpt-error">
                    <p>${TainacanChatGPT.texts.errorOccurred}</p>
                </div>
            `);
            return;
        }
        
        let html = '';
        
        // Adiciona indicador de cache se necessário
        if (fromCache) {
            html += `<div class="tainacan-chatgpt-cache-notice">
                <span class="dashicons dashicons-database"></span>
                ${TainacanChatGPT.texts.fromCache}
            </div>`;
        }
        
        // Adiciona aviso de revisão humana se necessário
        if (data.needs_human_review) {
            html += `<div class="tainacan-chatgpt-review-notice">${TainacanChatGPT.texts.needsHumanReview}</div>`;
        }
        
        // Verifica se há metadados válidos
        let hasValidMetadata = false;
        
        // Itera sobre os metadados
        for (const key in data.metadata) {
            if (data.metadata.hasOwnProperty(key)) {
                const value = data.metadata[key];
                
                // Pula propriedades vazias ou null ou INFORMAÇÃO AUSENTE
                if (value === null || value === undefined || value === '' || value === 'INFORMAÇÃO AUSENTE') {
                    continue;
                }
                
                hasValidMetadata = true;
                
                // Verifica se há informações de validação para este campo
                let validationClass = '';
                let validationIcon = '';
                
                if (data.validation && data.validation[key]) {
                    validationClass = data.validation[key].valid ? 'valid' : 'invalid';
                    validationIcon = data.validation[key].valid ? 
                        '<span class="dashicons dashicons-yes-alt"></span>' : 
                        '<span class="dashicons dashicons-warning"></span>';
                }
                
                html += `
                    <div class="tainacan-chatgpt-metadata-item ${validationClass}">
                        <div class="tainacan-chatgpt-metadata-label">
                            ${formatKeyName(key)} ${validationIcon}
                        </div>
                        <div class="tainacan-chatgpt-metadata-value">
                            ${formatValue(value)}
                            <div class="tainacan-chatgpt-metadata-actions">
                                <button class="tainacan-chatgpt-copy-btn" data-value="${encodeURIComponent(value)}">
                                    <span class="dashicons dashicons-clipboard"></span>
                                    ${TainacanChatGPT.texts.copyValue}
                                </button>
                                ${data.evidence && data.evidence[key] ? `
                                    <button class="tainacan-chatgpt-evidence-btn" data-field="${key}">
                                        <span class="dashicons dashicons-visibility"></span>
                                        ${TainacanChatGPT.texts.showEvidence}
                                    </button>
                                ` : ''}
                            </div>
                            ${data.evidence && data.evidence[key] ? `
                                <div class="tainacan-chatgpt-evidence" id="evidence-${key}" style="display: none;">
                                    <h4>${TainacanChatGPT.texts.evidence}:</h4>
                                    <blockquote>${data.evidence[key]}</blockquote>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `;
            }
        }
        
        // Se não houver metadados válidos
        if (!hasValidMetadata) {
            html += `
                <div class="tainacan-chatgpt-error">
                    <p>${TainacanChatGPT.texts.errorOccurred}</p>
                </div>
            `;
        }
        
        $results.html(html);
        
        // Adiciona evento de clique nos botões de cópia
        $('.tainacan-chatgpt-copy-btn').on('click', function(e) {
            e.preventDefault();
            
            const value = decodeURIComponent($(this).data('value'));
            const $button = $(this);
            
            // Copia para a área de transferência
            navigator.clipboard.writeText(value).then(function() {
                // Feedback visual
                $button.addClass('copied');
                $button.html(`<span class="dashicons dashicons-yes"></span> ${TainacanChatGPT.texts.copied}`);
                
                // Restaura o texto original após 2 segundos
                setTimeout(function() {
                    $button.removeClass('copied');
                    $button.html(`<span class="dashicons dashicons-clipboard"></span> ${TainacanChatGPT.texts.copyValue}`);
                }, 2000);
            });
        });
        
        // Adiciona evento de clique nos botões de evidência
        $('.tainacan-chatgpt-evidence-btn').on('click', function(e) {
            e.preventDefault();
            
            const field = $(this).data('field');
            const $evidence = $(`#evidence-${field}`);
            const $button = $(this);
            
            if ($evidence.is(':visible')) {
                $evidence.slideUp();
                $button.html(`<span class="dashicons dashicons-visibility"></span> ${TainacanChatGPT.texts.showEvidence}`);
            } else {
                $evidence.slideDown();
                $button.html(`<span class="dashicons dashicons-hidden"></span> ${TainacanChatGPT.texts.hideEvidence}`);
            }
        });
    }
    
    /**
     * Formata o nome da chave para exibição
     */
    function formatKeyName(key) {
        // Converte camelCase/snake_case em texto legível
        return key
            .replace(/_/g, ' ')
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, function(str) { return str.toUpperCase(); });
    }
    
    /**
     * Formata o valor para exibição
     */
    function formatValue(value) {
        if (Array.isArray(value)) {
            // Formata arrays como lista
            return `<ul>${value.map(item => `<li>${formatValue(item)}</li>`).join('')}</ul>`;
        } else if (typeof value === 'object' && value !== null) {
            // Formata objetos aninhados
            let html = '<div class="tainacan-chatgpt-nested-object">';
            
            for (const key in value) {
                if (value.hasOwnProperty(key)) {
                    html += `
                        <div class="tainacan-chatgpt-nested-item">
                            <strong>${formatKeyName(key)}:</strong> ${formatValue(value[key])}
                        </div>
                    `;
                }
            }
            
            html += '</div>';
            return html;
        } else {
            // Formata valores simples
            return String(value)
                .replace(/\n/g, '<br>')
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>');
        }
    }
    
    // Inicia a aplicação quando o DOM estiver pronto
    $(document).ready(function() {
        const debug = TainacanChatGPT.debug_enabled === true;
        
        if (debug) {
            console.log('Tainacan ChatGPT: Script inicializado');
        }
        
        // Registra o evento delegado apenas uma vez durante inicialização
        if (!eventRegistered) {
            $(document).on('click', '.tainacan-chatgpt-analyze-button', handleAnalyzeButtonClick);
            eventRegistered = true;
            
            if (debug) {
                console.log('Tainacan ChatGPT: Eventos delegados registrados');
            }
        }
        
        // Se a página for do Tainacan
        if (window.location.href.indexOf('tainacan') > -1 || 
            window.location.href.indexOf('page=tainacan_admin') > -1 || 
            window.location.href.indexOf('tainacan/admin') > -1 || 
            $('.tainacan-admin-container').length > 0) {
            
            if (debug) {
                console.log('Tainacan ChatGPT: Página do Tainacan detectada');
            }
            
            // Tenta adicionar o botão imediatamente
            addAnalyzeButton();
            
            // Tenta novamente após alguns instantes para garantir
            setTimeout(addAnalyzeButton, 2000);
            setTimeout(addAnalyzeButton, 4000);
            
            // Observa mudanças no DOM para adicionar o botão quando necessário
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                        // Verifica se a interface de item foi carregada
                        const hasDocumentField = Array.from(mutation.addedNodes).some(node => {
                            return node.nodeType === 1 && (
                                $(node).hasClass('document-field-content') || 
                                $(node).find('.document-field-content, .field-type-document, .document-field').length > 0
                            );
                        });
                        
                        if (hasDocumentField) {
                            if (debug) {
                                console.log('Tainacan ChatGPT: Campo de documento detectado, adicionando botão');
                            }
                            addAnalyzeButton();
                        }
                    }
                });
            });
            
            observer.observe(document.body, { 
                childList: true, 
                subtree: true 
            });
        }
    });
})(jQuery);