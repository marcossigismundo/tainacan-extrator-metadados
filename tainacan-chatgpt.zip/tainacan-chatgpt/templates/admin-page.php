<?php
/**
 * Template da página administrativa
 * @var array $options
 * @var array $stats
 */

if (!defined('ABSPATH')) {
    exit;
}

$is_configured = !empty($options['api_key']);

// Verificar dependências
$has_exif = function_exists('exif_read_data');
$has_pdfparser = class_exists('\Smalot\PdfParser\Parser') || file_exists(TAINACAN_CHATGPT_PLUGIN_DIR . 'vendor/autoload.php');

// Verificar capacidades de análise PDF visual
$has_imagick = extension_loaded('imagick');
$has_imagick_pdf = false;
if ($has_imagick) {
    try {
        $imagick = new \Imagick();
        $formats = $imagick->queryFormats('PDF');
        $has_imagick_pdf = !empty($formats);
    } catch (\Exception $e) {
        $has_imagick_pdf = false;
    }
}

// Verificar Ghostscript
$has_ghostscript = false;
$gs_path = null;
if (function_exists('shell_exec')) {
    if (PHP_OS_FAMILY === 'Windows') {
        $output = @shell_exec('where gswin64c 2>nul');
        if (empty($output)) {
            $output = @shell_exec('where gswin32c 2>nul');
        }
        if (!empty($output)) {
            $has_ghostscript = true;
            $gs_path = trim($output);
        }
    } else {
        $output = @shell_exec('which gs 2>/dev/null');
        if (!empty($output)) {
            $has_ghostscript = true;
            $gs_path = trim($output);
        }
    }
}

// Parser embutido sempre disponível
$has_builtin_parser = true;
?>

<div class="wrap tainacan-page-container-content tainacan-chatgpt-admin">
    <div class="tainacan-fixed-subheader">
        <h1 class="tainacan-page-title">
            <svg class="tainacan-chatgpt-title-icon" viewBox="0 0 24 24" width="32" height="32" fill="currentColor">
                <path d="M22.282 9.821a5.985 5.985 0 0 0-.516-4.91 6.046 6.046 0 0 0-6.51-2.9A6.065 6.065 0 0 0 4.981 4.18a5.985 5.985 0 0 0-3.998 2.9 6.046 6.046 0 0 0 .743 7.097 5.98 5.98 0 0 0 .51 4.911 6.051 6.051 0 0 0 6.515 2.9A5.985 5.985 0 0 0 13.26 24a6.056 6.056 0 0 0 5.772-4.206 5.99 5.99 0 0 0 3.997-2.9 6.056 6.056 0 0 0-.747-7.073z"/>
            </svg>
            <?php _e('Extrator de Metadados IA', 'tainacan-chatgpt'); ?>
            <span class="tainacan-chatgpt-version">v<?php echo TAINACAN_CHATGPT_VERSION; ?></span>
        </h1>
    </div>

    <!-- Stats Cards -->
    <?php if ($is_configured && !empty($stats)): ?>
    <div class="tainacan-chatgpt-stats-grid">
        <div class="tainacan-chatgpt-stat-card">
            <div class="tainacan-chatgpt-stat-icon">
                <span class="dashicons dashicons-chart-bar"></span>
            </div>
            <div class="tainacan-chatgpt-stat-content">
                <span class="tainacan-chatgpt-stat-value"><?php echo number_format($stats['total_analyses']); ?></span>
                <span class="tainacan-chatgpt-stat-label"><?php _e('Análises (30 dias)', 'tainacan-chatgpt'); ?></span>
            </div>
        </div>

        <div class="tainacan-chatgpt-stat-card">
            <div class="tainacan-chatgpt-stat-icon">
                <span class="dashicons dashicons-performance"></span>
            </div>
            <div class="tainacan-chatgpt-stat-content">
                <span class="tainacan-chatgpt-stat-value"><?php echo number_format($stats['total_tokens']); ?></span>
                <span class="tainacan-chatgpt-stat-label"><?php _e('Tokens Utilizados', 'tainacan-chatgpt'); ?></span>
            </div>
        </div>

        <div class="tainacan-chatgpt-stat-card">
            <div class="tainacan-chatgpt-stat-icon success">
                <span class="dashicons dashicons-yes-alt"></span>
            </div>
            <div class="tainacan-chatgpt-stat-content">
                <span class="tainacan-chatgpt-stat-value"><?php echo $stats['success_rate']; ?>%</span>
                <span class="tainacan-chatgpt-stat-label"><?php _e('Taxa de Sucesso', 'tainacan-chatgpt'); ?></span>
            </div>
        </div>

        <div class="tainacan-chatgpt-stat-card">
            <div class="tainacan-chatgpt-stat-icon">
                <span class="dashicons dashicons-money-alt"></span>
            </div>
            <div class="tainacan-chatgpt-stat-content">
                <span class="tainacan-chatgpt-stat-value">$<?php echo number_format($stats['total_cost'], 4); ?></span>
                <span class="tainacan-chatgpt-stat-label"><?php _e('Custo Estimado', 'tainacan-chatgpt'); ?></span>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="tainacan-chatgpt-admin-content">
        <form method="post" action="options.php" class="tainacan-chatgpt-form">
            <?php settings_fields('tainacan_chatgpt_options'); ?>

            <!-- Seção: Conexão API -->
            <div class="tainacan-chatgpt-card">
                <div class="tainacan-chatgpt-card-header">
                    <div class="tainacan-chatgpt-card-title">
                        <span class="dashicons dashicons-admin-network"></span>
                        <h2><?php _e('Conexão com OpenAI', 'tainacan-chatgpt'); ?></h2>
                    </div>
                    <?php if ($is_configured): ?>
                        <span class="tainacan-chatgpt-badge success"><?php _e('Configurado', 'tainacan-chatgpt'); ?></span>
                    <?php else: ?>
                        <span class="tainacan-chatgpt-badge warning"><?php _e('Pendente', 'tainacan-chatgpt'); ?></span>
                    <?php endif; ?>
                </div>
                <div class="tainacan-chatgpt-card-body">
                    <div class="tainacan-chatgpt-field">
                        <label for="api_key">
                            <?php _e('Chave da API OpenAI', 'tainacan-chatgpt'); ?>
                            <span class="required">*</span>
                        </label>
                        <div class="tainacan-chatgpt-input-group">
                            <input
                                type="password"
                                id="api_key"
                                name="tainacan_chatgpt_options[api_key]"
                                value="<?php echo esc_attr($options['api_key'] ?? ''); ?>"
                                class="regular-text"
                                autocomplete="off"
                                placeholder="sk-..."
                            />
                            <button type="button" class="button" id="toggle-api-key" title="<?php esc_attr_e('Mostrar/ocultar', 'tainacan-chatgpt'); ?>">
                                <span class="dashicons dashicons-visibility"></span>
                            </button>
                            <button type="button" class="button button-secondary" id="test-api">
                                <span class="dashicons dashicons-update"></span>
                                <?php _e('Testar', 'tainacan-chatgpt'); ?>
                            </button>
                        </div>
                        <p class="description">
                            <?php printf(
                                __('Obtenha sua chave em %s. A chave começa com "sk-".', 'tainacan-chatgpt'),
                                '<a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com</a>'
                            ); ?>
                        </p>
                        <div id="api-test-result" class="tainacan-chatgpt-notice" style="display: none;"></div>
                    </div>

                    <div class="tainacan-chatgpt-field-row">
                        <div class="tainacan-chatgpt-field">
                            <label for="model"><?php _e('Modelo', 'tainacan-chatgpt'); ?></label>
                            <select id="model" name="tainacan_chatgpt_options[model]">
                                <?php
                                $models = [
                                    'gpt-4o' => 'GPT-4o (Recomendado - Melhor custo/benefício)',
                                    'gpt-4o-mini' => 'GPT-4o Mini (Econômico)',
                                    'gpt-4-turbo' => 'GPT-4 Turbo',
                                    'gpt-4' => 'GPT-4',
                                    'gpt-3.5-turbo' => 'GPT-3.5 Turbo (Básico)',
                                ];
                                $current_model = $options['model'] ?? 'gpt-4o';
                                foreach ($models as $value => $label) {
                                    printf(
                                        '<option value="%s" %s>%s</option>',
                                        esc_attr($value),
                                        selected($current_model, $value, false),
                                        esc_html($label)
                                    );
                                }
                                ?>
                            </select>
                            <p class="description"><?php _e('GPT-4o oferece melhor análise de imagens e documentos.', 'tainacan-chatgpt'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Seção: Prompts Padrão -->
            <div class="tainacan-chatgpt-card">
                <div class="tainacan-chatgpt-card-header">
                    <div class="tainacan-chatgpt-card-title">
                        <span class="dashicons dashicons-edit-page"></span>
                        <h2><?php _e('Prompts de Análise Padrão', 'tainacan-chatgpt'); ?></h2>
                    </div>
                    <button type="button" class="tainacan-chatgpt-toggle-card">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                </div>
                <div class="tainacan-chatgpt-card-body">
                    <div class="tainacan-chatgpt-prompt-info">
                        <span class="dashicons dashicons-info"></span>
                        <p>
                            <?php _e('Os prompts definem como a IA deve analisar os documentos. Use instruções claras e especifique os campos JSON que deseja extrair. Você pode criar prompts específicos por coleção na seção abaixo.', 'tainacan-chatgpt'); ?>
                        </p>
                    </div>

                    <div class="tainacan-chatgpt-field">
                        <label for="default_image_prompt">
                            <span class="dashicons dashicons-format-image"></span>
                            <?php _e('Prompt para Imagens', 'tainacan-chatgpt'); ?>
                        </label>
                        <textarea
                            id="default_image_prompt"
                            name="tainacan_chatgpt_options[default_image_prompt]"
                            rows="8"
                            class="large-text code"
                        ><?php echo esc_textarea($options['default_image_prompt'] ?? ''); ?></textarea>
                        <p class="description"><?php _e('Instrução enviada ao analisar imagens (JPG, PNG, WebP, GIF).', 'tainacan-chatgpt'); ?></p>
                    </div>

                    <div class="tainacan-chatgpt-field">
                        <label for="default_document_prompt">
                            <span class="dashicons dashicons-media-document"></span>
                            <?php _e('Prompt para Documentos', 'tainacan-chatgpt'); ?>
                        </label>
                        <textarea
                            id="default_document_prompt"
                            name="tainacan_chatgpt_options[default_document_prompt]"
                            rows="8"
                            class="large-text code"
                        ><?php echo esc_textarea($options['default_document_prompt'] ?? ''); ?></textarea>
                        <p class="description"><?php _e('Instrução enviada ao analisar PDFs e textos.', 'tainacan-chatgpt'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Seção: Prompts por Coleção -->
            <div class="tainacan-chatgpt-card">
                <div class="tainacan-chatgpt-card-header">
                    <div class="tainacan-chatgpt-card-title">
                        <span class="dashicons dashicons-category"></span>
                        <h2><?php _e('Prompts por Coleção', 'tainacan-chatgpt'); ?></h2>
                    </div>
                    <button type="button" class="tainacan-chatgpt-toggle-card">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                </div>
                <div class="tainacan-chatgpt-card-body tainacan-chatgpt-collapsible">
                    <div class="tainacan-chatgpt-prompt-info">
                        <span class="dashicons dashicons-lightbulb"></span>
                        <p>
                            <?php _e('Configure prompts específicos para cada coleção. Isso permite extrair metadados personalizados de acordo com os campos da coleção. Se não houver prompt personalizado, será usado o prompt padrão.', 'tainacan-chatgpt'); ?>
                        </p>
                    </div>

                    <div class="tainacan-chatgpt-collection-prompts" id="collection-prompts-container">
                        <div class="tainacan-chatgpt-field">
                            <label for="collection-select"><?php _e('Selecione uma Coleção', 'tainacan-chatgpt'); ?></label>
                            <select id="collection-select" class="regular-text">
                                <option value=""><?php _e('-- Selecione --', 'tainacan-chatgpt'); ?></option>
                            </select>
                        </div>

                        <div id="collection-prompt-editor" style="display: none;">
                            <div class="tainacan-chatgpt-field-row">
                                <div class="tainacan-chatgpt-field">
                                    <label><?php _e('Tipo de Prompt', 'tainacan-chatgpt'); ?></label>
                                    <div class="tainacan-chatgpt-radio-group">
                                        <label>
                                            <input type="radio" name="collection_prompt_type" value="image" checked>
                                            <span class="dashicons dashicons-format-image"></span>
                                            <?php _e('Imagem', 'tainacan-chatgpt'); ?>
                                        </label>
                                        <label>
                                            <input type="radio" name="collection_prompt_type" value="document">
                                            <span class="dashicons dashicons-media-document"></span>
                                            <?php _e('Documento', 'tainacan-chatgpt'); ?>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="tainacan-chatgpt-field">
                                <div class="tainacan-chatgpt-field-header">
                                    <label for="collection-prompt-text"><?php _e('Prompt Personalizado', 'tainacan-chatgpt'); ?></label>
                                    <button type="button" class="button button-small" id="generate-prompt-suggestion">
                                        <span class="dashicons dashicons-lightbulb"></span>
                                        <?php _e('Gerar Sugestão', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                                <textarea
                                    id="collection-prompt-text"
                                    rows="10"
                                    class="large-text code"
                                    placeholder="<?php esc_attr_e('Deixe em branco para usar o prompt padrão...', 'tainacan-chatgpt'); ?>"
                                ></textarea>
                                <p class="description">
                                    <?php _e('Clique em "Gerar Sugestão" para criar um prompt baseado nos metadados da coleção.', 'tainacan-chatgpt'); ?>
                                </p>
                            </div>

                            <div class="tainacan-chatgpt-collection-actions">
                                <button type="button" class="button button-primary" id="save-collection-prompt">
                                    <span class="dashicons dashicons-saved"></span>
                                    <?php _e('Salvar Prompt', 'tainacan-chatgpt'); ?>
                                </button>
                                <button type="button" class="button" id="reset-collection-prompt">
                                    <span class="dashicons dashicons-undo"></span>
                                    <?php _e('Resetar para Padrão', 'tainacan-chatgpt'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Seção: Capacidades do Sistema -->
            <div class="tainacan-chatgpt-card">
                <div class="tainacan-chatgpt-card-header">
                    <div class="tainacan-chatgpt-card-title">
                        <span class="dashicons dashicons-admin-plugins"></span>
                        <h2><?php _e('Capacidades do Sistema', 'tainacan-chatgpt'); ?></h2>
                    </div>
                    <button type="button" class="tainacan-chatgpt-toggle-card">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                </div>
                <div class="tainacan-chatgpt-card-body">
                    <div class="tainacan-chatgpt-prompt-info">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <p>
                            <?php _e('<strong>Este plugin já inclui um parser PDF embutido</strong> e funciona sem dependências externas. As bibliotecas abaixo são opcionais e podem melhorar a qualidade da extração em casos específicos.', 'tainacan-chatgpt'); ?>
                        </p>
                    </div>

                    <div class="tainacan-chatgpt-dep-grid">
                        <!-- Parser PDF Embutido (sempre disponível) -->
                        <div class="tainacan-chatgpt-dep-item installed">
                            <div class="tainacan-chatgpt-dep-icon">
                                <span class="dashicons dashicons-yes"></span>
                            </div>
                            <div class="tainacan-chatgpt-dep-content">
                                <div class="tainacan-chatgpt-dep-header">
                                    <span class="tainacan-chatgpt-dep-name"><?php _e('Extração de Texto (Embutido)', 'tainacan-chatgpt'); ?></span>
                                    <span class="tainacan-chatgpt-dep-status"><?php _e('Ativo', 'tainacan-chatgpt'); ?></span>
                                </div>
                                <p class="tainacan-chatgpt-dep-desc">
                                    <?php _e('Parser PDF nativo do plugin. Extrai texto de PDFs com texto selecionável sem necessidade de bibliotecas externas.', 'tainacan-chatgpt'); ?>
                                </p>
                            </div>
                        </div>

                        <!-- Análise Visual de PDFs -->
                        <?php $has_visual = $has_imagick_pdf || $has_ghostscript; ?>
                        <div class="tainacan-chatgpt-dep-item <?php echo $has_visual ? 'installed' : 'missing'; ?>">
                            <div class="tainacan-chatgpt-dep-icon">
                                <span class="dashicons dashicons-<?php echo $has_visual ? 'yes' : 'warning'; ?>"></span>
                            </div>
                            <div class="tainacan-chatgpt-dep-content">
                                <div class="tainacan-chatgpt-dep-header">
                                    <span class="tainacan-chatgpt-dep-name"><?php _e('Análise Visual de PDFs', 'tainacan-chatgpt'); ?></span>
                                    <span class="tainacan-chatgpt-dep-status">
                                        <?php
                                        if ($has_imagick_pdf && $has_ghostscript) {
                                            _e('Completo', 'tainacan-chatgpt');
                                        } elseif ($has_imagick_pdf || $has_ghostscript) {
                                            _e('Parcial', 'tainacan-chatgpt');
                                        } else {
                                            _e('Indisponível', 'tainacan-chatgpt');
                                        }
                                        ?>
                                    </span>
                                </div>
                                <p class="tainacan-chatgpt-dep-desc">
                                    <?php _e('Converte PDFs escaneados em imagens para análise visual via GPT-4 Vision. Útil para documentos sem texto selecionável.', 'tainacan-chatgpt'); ?>
                                </p>
                                <div class="tainacan-chatgpt-dep-methods">
                                    <small>
                                        <strong><?php _e('Backends:', 'tainacan-chatgpt'); ?></strong>
                                        <?php if ($has_imagick_pdf): ?>
                                            <span class="tainacan-chatgpt-method-available">Imagick</span>
                                        <?php else: ?>
                                            <span class="tainacan-chatgpt-method-missing">Imagick</span>
                                        <?php endif; ?>
                                        <?php if ($has_ghostscript): ?>
                                            <span class="tainacan-chatgpt-method-available">Ghostscript</span>
                                        <?php else: ?>
                                            <span class="tainacan-chatgpt-method-missing">Ghostscript</span>
                                        <?php endif; ?>
                                    </small>
                                </div>
                            </div>
                        </div>

                        <!-- Extensão EXIF -->
                        <div class="tainacan-chatgpt-dep-item <?php echo $has_exif ? 'installed' : 'missing'; ?>">
                            <div class="tainacan-chatgpt-dep-icon">
                                <span class="dashicons dashicons-<?php echo $has_exif ? 'yes' : 'warning'; ?>"></span>
                            </div>
                            <div class="tainacan-chatgpt-dep-content">
                                <div class="tainacan-chatgpt-dep-header">
                                    <span class="tainacan-chatgpt-dep-name"><?php _e('Extração EXIF', 'tainacan-chatgpt'); ?></span>
                                    <span class="tainacan-chatgpt-dep-status">
                                        <?php echo $has_exif ? __('Ativo', 'tainacan-chatgpt') : __('Ausente', 'tainacan-chatgpt'); ?>
                                    </span>
                                </div>
                                <p class="tainacan-chatgpt-dep-desc">
                                    <?php _e('Extrai metadados técnicos de imagens: câmera, data, GPS, configurações de captura.', 'tainacan-chatgpt'); ?>
                                </p>
                                <?php if (!$has_exif): ?>
                                <div class="tainacan-chatgpt-dep-action">
                                    <button type="button" class="button button-small tainacan-chatgpt-dep-help" data-dep="exif">
                                        <span class="dashicons dashicons-editor-help"></span>
                                        <?php _e('Como ativar', 'tainacan-chatgpt'); ?>
                                    </button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- OpenAI API -->
                        <div class="tainacan-chatgpt-dep-item <?php echo $is_configured ? 'installed' : 'missing'; ?>">
                            <div class="tainacan-chatgpt-dep-icon">
                                <span class="dashicons dashicons-<?php echo $is_configured ? 'yes' : 'warning'; ?>"></span>
                            </div>
                            <div class="tainacan-chatgpt-dep-content">
                                <div class="tainacan-chatgpt-dep-header">
                                    <span class="tainacan-chatgpt-dep-name"><?php _e('API OpenAI', 'tainacan-chatgpt'); ?></span>
                                    <span class="tainacan-chatgpt-dep-status">
                                        <?php echo $is_configured ? __('Configurado', 'tainacan-chatgpt') : __('Requerido', 'tainacan-chatgpt'); ?>
                                    </span>
                                </div>
                                <p class="tainacan-chatgpt-dep-desc">
                                    <?php _e('Serviço de IA para análise inteligente de imagens e documentos (GPT-4 Vision).', 'tainacan-chatgpt'); ?>
                                </p>
                                <?php if (!$is_configured): ?>
                                <div class="tainacan-chatgpt-dep-action">
                                    <a href="https://platform.openai.com/api-keys" target="_blank" class="button button-small">
                                        <span class="dashicons dashicons-external"></span>
                                        <?php _e('Obter chave', 'tainacan-chatgpt'); ?>
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="tainacan-chatgpt-info-box-inline" style="margin-top: 20px;">
                        <h4>
                            <span class="dashicons dashicons-lightbulb"></span>
                            <?php _e('Como Funciona a Análise de PDFs', 'tainacan-chatgpt'); ?>
                        </h4>
                        <ol>
                            <li><?php _e('<strong>1. Extração de Texto:</strong> O plugin tenta extrair texto do PDF usando o parser embutido. Se o PDF tiver texto selecionável, este é enviado para a IA analisar.', 'tainacan-chatgpt'); ?></li>
                            <li><?php _e('<strong>2. Análise Visual:</strong> Se o texto extraído for insuficiente (PDFs escaneados), o plugin converte as páginas em imagens e envia para análise visual via GPT-4 Vision.', 'tainacan-chatgpt'); ?></li>
                            <li><?php _e('<strong>3. Fallback Inteligente:</strong> Se nenhum método estiver disponível, o plugin informa o problema e sugere soluções.', 'tainacan-chatgpt'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>

            <!-- Seção: Funcionalidades -->
            <div class="tainacan-chatgpt-card">
                <div class="tainacan-chatgpt-card-header">
                    <div class="tainacan-chatgpt-card-title">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <h2><?php _e('Funcionalidades', 'tainacan-chatgpt'); ?></h2>
                    </div>
                </div>
                <div class="tainacan-chatgpt-card-body">
                    <div class="tainacan-chatgpt-checkbox-grid">
                        <label class="tainacan-chatgpt-checkbox">
                            <input
                                type="checkbox"
                                name="tainacan_chatgpt_options[extract_exif]"
                                value="1"
                                <?php checked(!empty($options['extract_exif'])); ?>
                            />
                            <span class="tainacan-chatgpt-checkbox-content">
                                <span class="tainacan-chatgpt-checkbox-title">
                                    <span class="dashicons dashicons-camera"></span>
                                    <?php _e('Extrair Dados EXIF', 'tainacan-chatgpt'); ?>
                                </span>
                                <span class="tainacan-chatgpt-checkbox-desc">
                                    <?php _e('Extrai metadados técnicos de imagens (câmera, data, GPS, etc.)', 'tainacan-chatgpt'); ?>
                                </span>
                            </span>
                        </label>

                        <label class="tainacan-chatgpt-checkbox">
                            <input
                                type="checkbox"
                                name="tainacan_chatgpt_options[log_enabled]"
                                value="1"
                                <?php checked(!empty($options['log_enabled'])); ?>
                            />
                            <span class="tainacan-chatgpt-checkbox-content">
                                <span class="tainacan-chatgpt-checkbox-title">
                                    <span class="dashicons dashicons-list-view"></span>
                                    <?php _e('Registrar Uso', 'tainacan-chatgpt'); ?>
                                </span>
                                <span class="tainacan-chatgpt-checkbox-desc">
                                    <?php _e('Mantém histórico de análises para estatísticas e auditoria', 'tainacan-chatgpt'); ?>
                                </span>
                            </span>
                        </label>

                        <label class="tainacan-chatgpt-checkbox">
                            <input
                                type="checkbox"
                                name="tainacan_chatgpt_options[cost_tracking]"
                                value="1"
                                <?php checked(!empty($options['cost_tracking'])); ?>
                            />
                            <span class="tainacan-chatgpt-checkbox-content">
                                <span class="tainacan-chatgpt-checkbox-title">
                                    <span class="dashicons dashicons-money-alt"></span>
                                    <?php _e('Rastrear Custos', 'tainacan-chatgpt'); ?>
                                </span>
                                <span class="tainacan-chatgpt-checkbox-desc">
                                    <?php _e('Calcula custo estimado das análises baseado em tokens', 'tainacan-chatgpt'); ?>
                                </span>
                            </span>
                        </label>

                        <label class="tainacan-chatgpt-checkbox">
                            <input
                                type="checkbox"
                                name="tainacan_chatgpt_options[consent_required]"
                                value="1"
                                <?php checked(!empty($options['consent_required'])); ?>
                            />
                            <span class="tainacan-chatgpt-checkbox-content">
                                <span class="tainacan-chatgpt-checkbox-title">
                                    <span class="dashicons dashicons-shield"></span>
                                    <?php _e('Requer Consentimento', 'tainacan-chatgpt'); ?>
                                </span>
                                <span class="tainacan-chatgpt-checkbox-desc">
                                    <?php _e('Integra com WP Consent API para conformidade GDPR', 'tainacan-chatgpt'); ?>
                                </span>
                            </span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Seção: Configurações Avançadas -->
            <div class="tainacan-chatgpt-card">
                <div class="tainacan-chatgpt-card-header">
                    <div class="tainacan-chatgpt-card-title">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <h2><?php _e('Configurações Avançadas', 'tainacan-chatgpt'); ?></h2>
                    </div>
                    <button type="button" class="tainacan-chatgpt-toggle-card">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                </div>
                <div class="tainacan-chatgpt-card-body tainacan-chatgpt-collapsible collapsed">
                    <div class="tainacan-chatgpt-field-grid">
                        <div class="tainacan-chatgpt-field">
                            <label for="max_tokens"><?php _e('Máximo de Tokens', 'tainacan-chatgpt'); ?></label>
                            <input
                                type="number"
                                id="max_tokens"
                                name="tainacan_chatgpt_options[max_tokens]"
                                value="<?php echo esc_attr($options['max_tokens'] ?? 2000); ?>"
                                min="100"
                                max="8000"
                            />
                            <p class="description"><?php _e('Limite de tokens na resposta da IA (100-8000).', 'tainacan-chatgpt'); ?></p>
                        </div>

                        <div class="tainacan-chatgpt-field">
                            <label for="temperature"><?php _e('Temperatura', 'tainacan-chatgpt'); ?></label>
                            <input
                                type="number"
                                id="temperature"
                                name="tainacan_chatgpt_options[temperature]"
                                value="<?php echo esc_attr($options['temperature'] ?? 0.1); ?>"
                                min="0"
                                max="2"
                                step="0.1"
                            />
                            <p class="description"><?php _e('0 = determinístico (recomendado), 2 = criativo.', 'tainacan-chatgpt'); ?></p>
                        </div>

                        <div class="tainacan-chatgpt-field">
                            <label for="request_timeout"><?php _e('Timeout (segundos)', 'tainacan-chatgpt'); ?></label>
                            <input
                                type="number"
                                id="request_timeout"
                                name="tainacan_chatgpt_options[request_timeout]"
                                value="<?php echo esc_attr($options['request_timeout'] ?? 60); ?>"
                                min="10"
                                max="300"
                            />
                            <p class="description"><?php _e('Tempo máximo de espera por resposta.', 'tainacan-chatgpt'); ?></p>
                        </div>

                        <div class="tainacan-chatgpt-field">
                            <label for="cache_duration"><?php _e('Duração do Cache (segundos)', 'tainacan-chatgpt'); ?></label>
                            <input
                                type="number"
                                id="cache_duration"
                                name="tainacan_chatgpt_options[cache_duration]"
                                value="<?php echo esc_attr($options['cache_duration'] ?? 3600); ?>"
                                min="0"
                                max="604800"
                            />
                            <p class="description"><?php _e('0 para desativar. Recomendado: 3600 (1 hora).', 'tainacan-chatgpt'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ações -->
            <div class="tainacan-chatgpt-actions-bar">
                <?php submit_button(__('Salvar Configurações', 'tainacan-chatgpt'), 'primary large', 'submit', false); ?>
                <button type="button" class="button button-secondary" id="clear-all-cache">
                    <span class="dashicons dashicons-trash"></span>
                    <?php _e('Limpar Cache', 'tainacan-chatgpt'); ?>
                </button>
            </div>
        </form>

        <!-- Info Box -->
        <div class="tainacan-chatgpt-sidebar">
            <div class="tainacan-chatgpt-info-box">
                <h3>
                    <span class="dashicons dashicons-book"></span>
                    <?php _e('Como Usar', 'tainacan-chatgpt'); ?>
                </h3>
                <ol>
                    <li><?php _e('Configure sua chave API da OpenAI', 'tainacan-chatgpt'); ?></li>
                    <li><?php _e('Personalize os prompts de análise', 'tainacan-chatgpt'); ?></li>
                    <li><?php _e('Edite um item no Tainacan', 'tainacan-chatgpt'); ?></li>
                    <li><?php _e('Clique em "Analisar Documento"', 'tainacan-chatgpt'); ?></li>
                    <li><?php _e('Copie os metadados extraídos', 'tainacan-chatgpt'); ?></li>
                </ol>
            </div>

            <div class="tainacan-chatgpt-info-box">
                <h3>
                    <span class="dashicons dashicons-media-default"></span>
                    <?php _e('Formatos Suportados', 'tainacan-chatgpt'); ?>
                </h3>
                <div class="tainacan-chatgpt-formats">
                    <div class="tainacan-chatgpt-format-group">
                        <strong><?php _e('Imagens:', 'tainacan-chatgpt'); ?></strong>
                        <span>JPG, PNG, GIF, WebP</span>
                    </div>
                    <div class="tainacan-chatgpt-format-group">
                        <strong><?php _e('Documentos:', 'tainacan-chatgpt'); ?></strong>
                        <span>PDF, TXT, HTML</span>
                    </div>
                </div>
            </div>

            <div class="tainacan-chatgpt-info-box">
                <h3>
                    <span class="dashicons dashicons-info-outline"></span>
                    <?php _e('Sobre os Prompts', 'tainacan-chatgpt'); ?>
                </h3>
                <p><?php _e('Os prompts são instruções enviadas à IA. Para melhores resultados:', 'tainacan-chatgpt'); ?></p>
                <ul>
                    <li><?php _e('Seja específico sobre os campos desejados', 'tainacan-chatgpt'); ?></li>
                    <li><?php _e('Use formato JSON para estruturar a resposta', 'tainacan-chatgpt'); ?></li>
                    <li><?php _e('Inclua exemplos quando possível', 'tainacan-chatgpt'); ?></li>
                    <li><?php _e('Adapte para o tipo de acervo', 'tainacan-chatgpt'); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
