<?php
/**
 * Classe responsável pela análise de documentos
 */
class Tainacan_ChatGPT_Document_Analyzer {
    /**
     * API do ChatGPT
     */
    private $api;
    
    /**
     * Cache para resultados
     */
    private $cache;
    
    /**
     * Construtor
     */
    public function __construct() {
        $this->api = new Tainacan_ChatGPT_API();
        $this->cache = new Tainacan_ChatGPT_Cache();
    }
    
    /**
     * Analisa um item do Tainacan
     */
    public function analyze_item($item_id, $force_refresh = false) {
        // Verifica cache primeiro se não for forçada atualização
        if (!$force_refresh) {
            $cached_result = $this->cache->get("item_{$item_id}");
            if ($cached_result !== false) {
                return array(
                    'success' => true,
                    'data' => $cached_result,
                    'from_cache' => true
                );
            }
        }
        
        // Obtém detalhes do item
        $item = \Tainacan\Repositories\Items::get_instance()->fetch($item_id);
        
        if (!$item) {
            return array(
                'success' => false,
                'message' => __('Item não encontrado.', 'tainacan-chatgpt')
            );
        }
        
        // Busca o documento anexado ao item
        $document_data = $this->get_document_from_item($item);
        
        if (!$document_data['success']) {
            return $document_data;
        }
        
        // Analisa documento com o tipo apropriado
        if ($document_data['type'] === 'image') {
            $result = $this->api->analyze_image($document_data['url']);
        } else {
            $document_content = $this->extract_document_content($document_data['url'], $document_data['file_path']);
            
            if (!$document_content['success']) {
                return $document_content;
            }
            
            $result = $this->api->analyze_document($document_content['content']);
        }
        
        // Se análise for bem-sucedida, armazena em cache
        if ($result['success']) {
            $this->cache->set("item_{$item_id}", $result['data']);
        }
        
        return $result;
    }
    
    /**
     * Obtém o documento anexado ao item
     */
    private function get_document_from_item($item) {
        // Busca o documento anexado
        $document_type = get_post_meta($item->get_id(), 'document_type', true);
        
        if (empty($document_type) || $document_type === 'none') {
            return array(
                'success' => false,
                'message' => __('Item não possui documento anexado.', 'tainacan-chatgpt')
            );
        }
        
        if ($document_type === 'attachment') {
            $document_id = get_post_meta($item->get_id(), 'document_id', true);
            
            if (empty($document_id)) {
                return array(
                    'success' => false,
                    'message' => __('Documento não encontrado.', 'tainacan-chatgpt')
                );
            }
            
            $file_url = wp_get_attachment_url($document_id);
            $file_path = get_attached_file($document_id);
            $file_type = wp_check_filetype(basename($file_path));
            $mime_type = $file_type['type'];
            
            // Determina o tipo de documento
            $is_image = strpos($mime_type, 'image/') === 0;
            $type = $is_image ? 'image' : 'document';
            
            return array(
                'success' => true,
                'type' => $type,
                'url' => $file_url,
                'file_path' => $file_path,
                'mime_type' => $mime_type
            );
        } elseif ($document_type === 'url') {
            $document_url = get_post_meta($item->get_id(), 'document_url', true);
            
            if (empty($document_url)) {
                return array(
                    'success' => false,
                    'message' => __('URL do documento não encontrada.', 'tainacan-chatgpt')
                );
            }
            
            // Verifica se a URL é uma imagem
            $file_info = wp_check_filetype(basename(parse_url($document_url, PHP_URL_PATH)));
            $mime_type = $file_info['type'];
            $is_image = strpos($mime_type, 'image/') === 0;
            $type = $is_image ? 'image' : 'document';
            
            return array(
                'success' => true,
                'type' => $type,
                'url' => $document_url,
                'file_path' => null,
                'mime_type' => $mime_type
            );
        } else {
            return array(
                'success' => false,
                'message' => __('Tipo de documento não suportado.', 'tainacan-chatgpt')
            );
        }
    }
    
    /**
     * Extrai o conteúdo de um documento
     */
    private function extract_document_content($file_url, $file_path = null) {
        $content = '';
        $file_type = '';
        
        // Se o arquivo estiver disponível localmente
        if ($file_path && file_exists($file_path)) {
            $file_type = wp_check_filetype(basename($file_path));
            $mime_type = $file_type['type'];
            
            if ($mime_type === 'application/pdf') {
                // Extrai texto do PDF usando um método confiável
                if (class_exists('TCPDF_PARSER')) {
                    // Usa TCPDF se disponível
                    $parser = new \TCPDF_PARSER($file_path);
                    $content = $parser->getTextContent();
                } elseif (function_exists('pdf_parser')) {
                    // Usa pdf_parser se disponível
                    $content = pdf_parser($file_path);
                } elseif (class_exists('Smalot\PdfParser\Parser')) {
                    // Usa PDF Parser se disponível
                    $parser = new \Smalot\PdfParser\Parser();
                    $pdf = $parser->parseFile($file_path);
                    $content = $pdf->getText();
                } else {
                    // Tenta usar comandos do sistema operacional
                    if (function_exists('shell_exec')) {
                        // Tenta pdftotext (parte do poppler-utils)
                        $content = shell_exec('pdftotext ' . escapeshellarg($file_path) . ' -');
                        
                        // Se não funcionar, tenta o pdftohtml
                        if (empty($content)) {
$temp_html = tempnam(sys_get_temp_dir(), 'pdf');
                            shell_exec('pdftohtml -i -s -noframes ' . escapeshellarg($file_path) . ' ' . escapeshellarg($temp_html));
                            if (file_exists($temp_html . '.html')) {
                                $content = strip_tags(file_get_contents($temp_html . '.html'));
                                unlink($temp_html . '.html');
                            }
                            unlink($temp_html);
                        }
                    }
                }
            } elseif ($mime_type === 'application/msword' || $mime_type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                // Tenta extrair conteúdo de arquivos Word
                if (class_exists('ZipArchive') && $mime_type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                    $zip = new ZipArchive();
                    if ($zip->open($file_path) === true) {
                        if (($index = $zip->locateName('word/document.xml')) !== false) {
                            $content = $zip->getFromIndex($index);
                            $content = strip_tags($content);
                        }
                        $zip->close();
                    }
                } elseif (function_exists('shell_exec')) {
                    // Tenta usar antiword
                    $content = shell_exec('antiword ' . escapeshellarg($file_path));
                    
                    // Se não funcionar, tenta catdoc
                    if (empty($content)) {
                        $content = shell_exec('catdoc ' . escapeshellarg($file_path));
                    }
                }
            } elseif ($mime_type === 'text/plain' || $mime_type === 'text/html' || $mime_type === 'text/xml') {
                // Lê arquivos de texto diretamente
                $content = file_get_contents($file_path);
                
                if ($mime_type === 'text/html') {
                    $content = strip_tags($content);
                }
            }
        } else {
            // Se o arquivo não estiver disponível localmente, tenta obter conteúdo da URL
            $response = wp_remote_get($file_url);
            
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $content = wp_remote_retrieve_body($response);
                
                // Se for HTML, remove tags
                if (strpos($content, '<!DOCTYPE html>') !== false || strpos($content, '<html') !== false) {
                    $content = strip_tags($content);
                }
            }
        }
        
        // Se não conseguiu extrair conteúdo, retorna erro
        if (empty($content)) {
            return array(
                'success' => false,
                'message' => __('Não foi possível extrair o conteúdo do documento.', 'tainacan-chatgpt')
            );
        }
        
        // Limita o conteúdo a um tamanho máximo para evitar problemas com a API
        $max_chars = 50000; // ~12500 tokens
        if (mb_strlen($content) > $max_chars) {
            $content = mb_substr($content, 0, $max_chars) . '...';
        }
        
        return array(
            'success' => true,
            'content' => $content
        );
    }
}
                