<?php
/**
 * Classe responsável pela integração com a interface de itens do Tainacan
 */
class Tainacan_ChatGPT_Item_Integration {
    /**
     * Construtor
     */
    public function __construct() {
        // Adiciona scripts na interface de admin do Tainacan
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        
        // Adiciona endpoint AJAX para análise de itens
        add_action('wp_ajax_tainacan_chatgpt_analyze_item', array($this, 'ajax_analyze_item'));
    }
    
    /**
     * Carrega scripts e estilos
     */
    public function enqueue_assets($hook) {
        // Carrega apenas nas páginas de edição de itens do Tainacan
        if (strpos($hook, 'tainacan_admin') !== false || strpos($hook, 'page_tainacan_admin') !== false) {
            wp_enqueue_style(
                'tainacan-chatgpt',
                TAINACAN_CHATGPT_PLUGIN_DIR_URL . 'assets/css/tainacan-chatgpt.css',
                array(),
                TAINACAN_CHATGPT_VERSION
            );
            
            wp_enqueue_script(
                'tainacan-chatgpt',
                TAINACAN_CHATGPT_PLUGIN_DIR_URL . 'assets/js/tainacan-chatgpt.js',
                array('jquery'),
                TAINACAN_CHATGPT_VERSION,
                true
            );
            
            wp_localize_script('tainacan-chatgpt', 'TainacanChatGPT', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('tainacan_chatgpt_nonce'),
                'texts' => array(
                    'analyzeWithChatGPT' => __('Analisar com ChatGPT', 'tainacan-chatgpt'),
                    'analyzing' => __('Analisando...', 'tainacan-chatgpt'),
                    'errorOccurred' => __('Ocorreu um erro. Tente novamente.', 'tainacan-chatgpt'),
                    'noDocumentFound' => __('Nenhum documento encontrado neste item.', 'tainacan-chatgpt'),
                    'copyValue' => __('Copiar', 'tainacan-chatgpt'),
                    'copied' => __('Copiado!', 'tainacan-chatgpt'),
                    'closePanel' => __('Fechar', 'tainacan-chatgpt'),
                    'refreshAnalysis' => __('Atualizar análise', 'tainacan-chatgpt'),
                    'metadataResults' => __('Metadados Extraídos', 'tainacan-chatgpt'),
                    'fromCache' => __('(dos resultados em cache)', 'tainacan-chatgpt')
                )
            ));
        }
    }
    
    /**
     * Endpoint AJAX para análise de itens
     */
    public function ajax_analyze_item() {
        check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }
        
        $item_id = isset($_POST['item_id']) ? intval($_POST['item_id']) : 0;
        $force_refresh = isset($_POST['force_refresh']) ? (bool)$_POST['force_refresh'] : false;
        
        if (empty($item_id)) {
            wp_send_json_error(__('ID do item não fornecido.', 'tainacan-chatgpt'));
        }
        
        $analyzer = new Tainacan_ChatGPT_Document_Analyzer();
        $result = $analyzer->analyze_item($item_id, $force_refresh);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'metadata' => $result['data'],
                'from_cache' => isset($result['from_cache']) ? $result['from_cache'] : false
            ));
        } else {
            wp_send_json_error($result['message']);
        }
    }
}
