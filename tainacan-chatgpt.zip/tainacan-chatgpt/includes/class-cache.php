<?php
/**
 * Classe responsável pelo gerenciamento de cache
 */
class Tainacan_ChatGPT_Cache {
    /**
     * Prefixo para chaves de cache
     */
    private $prefix = 'tainacan_chatgpt_';
    
    /**
     * Opções do plugin
     */
    private $options;
    
    /**
     * Construtor
     */
    public function __construct() {
        $this->options = get_option('tainacan_chatgpt_options');
    }
    
    /**
     * Obtém um valor do cache
     */
    public function get($key) {
        return get_transient($this->prefix . $key);
    }
    
    /**
     * Armazena um valor no cache
     */
    public function set($key, $value) {
        $duration = isset($this->options['cache_duration']) ? intval($this->options['cache_duration']) : 3600; // 1 hora por padrão
        
        // Mínimo de 5 minutos
        $duration = max(300, $duration);
        
        return set_transient($this->prefix . $key, $value, $duration);
    }
    
    /**
     * Remove um valor do cache
     */
    public function delete($key) {
        return delete_transient($this->prefix . $key);
    }
    
    /**
     * Limpa todo o cache
     */
    public function clear_all() {
        global $wpdb;
        
        $transients = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
                '_transient_' . $this->prefix . '%',
                '_transient_timeout_' . $this->prefix . '%'
            )
        );
        
        $count = 0;
        foreach ($transients as $transient) {
            $key = str_replace(array('_transient_', '_transient_timeout_'), '', $transient);
            if (delete_option($transient)) {
                $count++;
            }
        }
        
        return $count > 0;
    }
}
