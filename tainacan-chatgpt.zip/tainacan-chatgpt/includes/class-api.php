<?php
/**
 * Classe responsável pela comunicação com a API do ChatGPT
 */
class Tainacan_ChatGPT_API {
    /**
     * Opções do plugin
     */
    private $options;
    
    /**
     * Logger para registrar eventos
     */
    private $logger;
    
    /**
     * Construtor
     */
    public function __construct() {
        // Valores padrão
        $default_options = array(
            'api_key' => '',
            'model' => 'gpt-4o',
            'image_prompt' => __('Analise esta imagem museológica e extraia os seguintes metadados: título, autor, data de criação, técnica utilizada, dimensões, estado de conservação, descrição visual detalhada. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
            'text_prompt' => __('Analise este documento e extraia os seguintes metadados: título, autor(es), ano de publicação, resumo, palavras-chave, metodologia, instituição, área de conhecimento. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
            'max_tokens' => 1000,
            'temperature' => 0.7,
            'request_timeout' => 30,
            'cache_duration' => 3600,
        );
        
        // Obtém opções salvas ou usa valores padrão
        $this->options = wp_parse_args(get_option('tainacan_chatgpt_options', array()), $default_options);
        $this->logger = new Tainacan_ChatGPT_Logger();
    }
    
    /**
     * Testa a conexão com a API OpenAI
     */
    public function test_connection() {
        if (empty($this->options['api_key'])) {
            return array(
                'success' => false,
                'message' => __('Chave da API não configurada.', 'tainacan-chatgpt')
            );
        }
        
        $response = wp_remote_get('https://api.openai.com/v1/models', array(
            'timeout' => 15,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->options['api_key'],
                'Content-Type' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            
            $this->logger->log_error('Erro de conexão: ' . $error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de conexão: %s', 'tainacan-chatgpt'), $error_message)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($response_code === 200) {
            return array(
                'success' => true,
                'message' => __('Conexão estabelecida com sucesso!', 'tainacan-chatgpt')
            );
        } else {
            $error_message = isset($response_body['error']['message']) 
                ? $response_body['error']['message'] 
                : __('Erro desconhecido.', 'tainacan-chatgpt');
            
            $this->logger->log_error('Erro de API: ' . $error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de API (%d): %s', 'tainacan-chatgpt'), $response_code, $error_message)
            );
        }
    }
    
    /**
     * Analisa uma imagem usando a API do ChatGPT
     */
    public function analyze_image($image_url, $custom_prompt = '') {
        if (empty($this->options['api_key'])) {
            return array(
                'success' => false,
                'message' => __('Chave da API não configurada.', 'tainacan-chatgpt')
            );
        }
        
        $prompt = !empty($custom_prompt) ? $custom_prompt : $this->options['image_prompt'];
        $model = !empty($this->options['model']) ? $this->options['model'] : 'gpt-4o';
        
        // Verifica se o modelo suporta análise de imagem
        if (!$this->model_supports_vision($model)) {
            $model = 'gpt-4o'; // Fallback para gpt-4o
        }
        
        // Prepara os dados para a API
        $request_data = array(
            'model' => $model,
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => __('Você é um assistente especializado em análise visual e extração de metadados para acervos museológicos e culturais. Responda apenas em português do Brasil.', 'tainacan-chatgpt')
                ),
                array(
                    'role' => 'user',
                    'content' => array(
                        array(
                            'type' => 'text',
                            'text' => $prompt
                        ),
                        array(
                            'type' => 'image_url',
                            'image_url' => array(
                                'url' => $image_url,
                                'detail' => 'high'
                            )
                        )
                    )
                )
            ),
            'max_tokens' => intval($this->options['max_tokens']),
            'temperature' => floatval($this->options['temperature']),
            'response_format' => array('type' => 'json_object')
        );
        
        return $this->send_request('https://api.openai.com/v1/chat/completions', $request_data, 'image');
    }
    
    /**
     * Analisa um documento usando a API do ChatGPT
     */
    public function analyze_document($document_content, $custom_prompt = '') {
        if (empty($this->options['api_key'])) {
            return array(
                'success' => false,
                'message' => __('Chave da API não configurada.', 'tainacan-chatgpt')
            );
        }
        
        $prompt = !empty($custom_prompt) ? $custom_prompt : $this->options['text_prompt'];
        $model = !empty($this->options['model']) ? $this->options['model'] : 'gpt-4o';
        
        // Prepara os dados para a API
        $request_data = array(
            'model' => $model,
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => __('Você é um assistente especializado em análise de documentos acadêmicos e extração de metadados para acervos digitais. Responda apenas em português do Brasil.', 'tainacan-chatgpt')
                ),
                array(
                    'role' => 'user',
                    'content' => $prompt . "\n\nDocumento:\n" . $document_content
                )
            ),
            'max_tokens' => intval($this->options['max_tokens']),
            'temperature' => floatval($this->options['temperature']),
            'response_format' => array('type' => 'json_object')
        );
        
        return $this->send_request('https://api.openai.com/v1/chat/completions', $request_data, 'document');
    }
    
    /**
     * Envia requisição para a API OpenAI
     */
    private function send_request($url, $data, $content_type) {
        // Registra início da requisição
        $this->logger->log_request_start($data['model'], $content_type);
        
        $timeout = isset($this->options['request_timeout']) ? intval($this->options['request_timeout']) : 30;
        
        $response = wp_remote_post($url, array(
            'timeout' => $timeout,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->options['api_key'],
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($data)
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            
            $this->logger->log_request_error($error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de conexão: %s', 'tainacan-chatgpt'), $error_message)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($response_code === 200 && isset($response_body['choices'][0]['message']['content'])) {
            // Registra sucesso da requisição
            $usage = array(
                'prompt_tokens' => isset($response_body['usage']['prompt_tokens']) ? $response_body['usage']['prompt_tokens'] : 0,
                'completion_tokens' => isset($response_body['usage']['completion_tokens']) ? $response_body['usage']['completion_tokens'] : 0,
                'total_tokens' => isset($response_body['usage']['total_tokens']) ? $response_body['usage']['total_tokens'] : 0
            );
            
            $this->logger->log_request_success($data['model'], $usage);
            
            // Tenta decodificar o conteúdo como JSON
            $content = $response_body['choices'][0]['message']['content'];
            $content_decoded = json_decode($content, true);
            
            return array(
                'success' => true,
                'data' => $content_decoded ?: $content,
                'raw_data' => $content,
                'usage' => $usage
            );
        } else {
            $error_message = isset($response_body['error']['message']) 
                ? $response_body['error']['message'] 
                : __('Erro desconhecido.', 'tainacan-chatgpt');
            
            $this->logger->log_request_error($error_message);
            
            return array(
                'success' => false,
                'message' => sprintf(__('Erro de API (%d): %s', 'tainacan-chatgpt'), $response_code, $error_message)
            );
        }
    }
    
    /**
     * Verifica se o modelo suporta análise de imagem
     */
    private function model_supports_vision($model) {
        $vision_models = array(
            'gpt-4o',
            'gpt-4-vision-preview',
            'gpt-4-turbo'
        );
        
        return in_array($model, $vision_models);
    }
}