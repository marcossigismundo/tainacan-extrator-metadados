<?php
/**
 * Arquivo executado quando o plugin é desinstalado
 */

// Se o arquivo não for chamado pelo WordPress, aborta
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Remove todas as opções
delete_option('tainacan_chatgpt_options');
delete_option('tainacan_chatgpt_logs');

// Remove todos os metadados de revisão humana
global $wpdb;
$wpdb->query("DELETE FROM $wpdb->postmeta WHERE meta_key = '_tainacan_chatgpt_needs_review'");

// Remove todos os transients (cache)
$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_tainacan_chatgpt_%'");
$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_tainacan_chatgpt_%'");
