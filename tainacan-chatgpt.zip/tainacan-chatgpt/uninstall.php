<?php
/**
 * Uninstall - Remove dados do plugin
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Remove opções
delete_option('tainacan_chatgpt_options');

// Remove transients (cache)
global $wpdb;
$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_tainacan_chatgpt_%'");
$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_tainacan_chatgpt_%'");
