<?php
/**
 * Plugin Name: Tainacan ChatGPT
 * Plugin URI: https://github.com/seu-usuario/tainacan-chatgpt
 * Description: Extração automatizada de metadados no Tainacan utilizando a API do ChatGPT
 * Version: 1.0.0
 * Author: Sigismundo
 * Author URI: https://seu-site.com
 * Text Domain: tainacan-chatgpt
 * Domain Path: /languages
 * License: GPL v2 or later
 */

// Se este arquivo for chamado diretamente, aborta.
if (!defined('WPINC')) {
    die;
}

add_action('plugins_loaded', function() {
  if (class_exists('\Smalot\PdfParser\Parser')) {
    error_log('PDF Parser disponível');
  } else {
    error_log('PDF Parser NÃO disponível');
  }
});

// Define constantes do plugin
define('TAINACAN_CHATGPT_VERSION', '1.0.0');
define('TAINACAN_CHATGPT_PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));
define('TAINACAN_CHATGPT_PLUGIN_DIR_URL', plugin_dir_url(__FILE__));
define('TAINACAN_CHATGPT_DOMAIN', 'tainacan-chatgpt');

/**
 * Função executada na ativação do plugin
 */
function tainacan_chatgpt_activate() {
    // Verifica versão mínima do PHP
    if (version_compare(PHP_VERSION, '7.4', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('Tainacan ChatGPT requer PHP 7.4 ou superior.', 'tainacan-chatgpt'));
    }
	
// Carrega o autoloader do Composer
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
    error_log('Autoloader do Composer carregado');
} else {
    error_log('Autoloader do Composer não encontrado');
}
    
    // Verifica e cria diretórios
    tainacan_chatgpt_check_directories();
    
    // Configura valores padrões
    $default_options = [
        'api_key' => '',
        'model' => 'gpt-4o',
        'image_prompt' => __('Analise esta imagem museológica e extraia os seguintes metadados: título, autor, data de criação, técnica utilizada, dimensões, estado de conservação, descrição visual detalhada. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
        'text_prompt' => __('Analise este documento e extraia os seguintes metadados: título, autor(es), ano de publicação, resumo, palavras-chave, metodologia, instituição, área de conhecimento. Formate a resposta como um JSON com esses campos.', 'tainacan-chatgpt'),
        'max_tokens' => 1000,
        'temperature' => 0.1,
        'request_timeout' => 30,
        'cache_duration' => 3600, // 1 hora em segundos
    ];
    
    // Verifica se já existe opção configurada e mescla com valores padrão
    $existing_options = get_option('tainacan_chatgpt_options', array());
    $merged_options = wp_parse_args($existing_options, $default_options);
    
    update_option('tainacan_chatgpt_options', $merged_options);
}

/**
 * Verifica e cria diretórios necessários para o plugin
 */
function tainacan_chatgpt_check_directories() {
    $directories = array(
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'admin',
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'admin/js',
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'admin/css',
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'assets/js',
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'assets/css',
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'src',
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'tests',
        TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'languages'
    );
    
    foreach ($directories as $dir) {
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }
    }
}

/**
 * Função executada na desativação do plugin
 */
function tainacan_chatgpt_deactivate() {
    // Limpa dados temporários
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_tainacan_chatgpt_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_tainacan_chatgpt_%'");
}

// Registra funções de ativação/desativação
register_activation_hook(__FILE__, 'tainacan_chatgpt_activate');
register_deactivation_hook(__FILE__, 'tainacan_chatgpt_deactivate');

/**
 * Carrega arquivos de idioma
 */
function tainacan_chatgpt_load_textdomain() {
    load_plugin_textdomain('tainacan-chatgpt', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'tainacan_chatgpt_load_textdomain');

/**
 * Carrega o autoloader do Composer se existir
 */
function tainacan_chatgpt_load_autoloader() {
    // Carrega o Composer autoloader se existir
    if (file_exists(TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'vendor/autoload.php')) {
        require_once TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'vendor/autoload.php';
    } else {
        // Autoloader manual de fallback
        spl_autoload_register(function ($class) {
            // Prefixo do namespace do projeto
            $prefix = 'Tainacan\\ChatGPT\\';
            
            // Diretório base para o prefixo do namespace
            $base_dir = TAINACAN_CHATGPT_PLUGIN_DIR_PATH . 'src/';
            
            // Verifica se a classe usa o prefixo do namespace
            $len = strlen($prefix);
            if (strncmp($prefix, $class, $len) !== 0) {
                return;
            }
            
            // Obtém o nome da classe relativa
            $relative_class = substr($class, $len);
            
            // Substitui separadores de namespace por separadores de diretório
            $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
            
            // Carrega o arquivo se existir
            if (file_exists($file)) {
                require $file;
            }
        });
    }
}
add_action('plugins_loaded', 'tainacan_chatgpt_load_autoloader', 5);

/**
 * Verifica dependências do plugin
 */
function tainacan_chatgpt_check_dependencies() {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    
    // Verificar se o Tainacan está ativo
    if (!is_plugin_active('tainacan/tainacan.php')) {
        // Desativa este plugin se o Tainacan não estiver ativo
        deactivate_plugins(plugin_basename(__FILE__));
        
        // Exibe mensagem de erro
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error is-dismissible"><p>';
            echo esc_html__('O plugin Tainacan precisa estar ativo para usar o Tainacan ChatGPT. O plugin foi desativado.', 'tainacan-chatgpt');
            echo '</p></div>';
        });
        
        // Se o usuário estiver tentando ativar o plugin, redireciona para evitar mensagem de "Plugin ativado"
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
            wp_redirect(admin_url('plugins.php'));
            exit;
        }
        
        return false;
    }
    
    // Verificar se as classes necessárias do Tainacan estão disponíveis
    if (!class_exists('\Tainacan\Repositories\Items')) {
        // Exibe aviso mas não desativa
        add_action('admin_notices', function() {
            echo '<div class="notice notice-warning is-dismissible"><p>';
            echo esc_html__('Atenção: O Tainacan ChatGPT pode não funcionar corretamente pois não encontrou todas as classes necessárias do Tainacan.', 'tainacan-chatgpt');
            echo '</p></div>';
        });
    }
    
    return true;
}
add_action('plugins_loaded', 'tainacan_chatgpt_check_dependencies', 10);

/**
 * Inicializa o plugin
 */
function tainacan_chatgpt_init() {
    // Só inicializa se as dependências estiverem satisfeitas
    if (!tainacan_chatgpt_check_dependencies()) {
        return;
    }
    
    // Inicializa componentes
    $item_integration = new \Tainacan\ChatGPT\ItemIntegration();
    
    // Carrega administração se estiver no painel admin
    if (is_admin()) {
        $admin = new \Tainacan\ChatGPT\Admin();
    }
}
add_action('init', 'tainacan_chatgpt_init');

/**
 * Adiciona link para configurações na listagem de plugins
 */
function tainacan_chatgpt_add_settings_link($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=tainacan-chatgpt') . '">' . __('Configurações', 'tainacan-chatgpt') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'tainacan_chatgpt_add_settings_link');