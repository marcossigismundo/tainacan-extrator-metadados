<?php
/**
 * PDF Parser Leve - Extração de Texto de PDFs
 *
 * Implementação standalone que não requer dependências externas.
 * Suporta PDFs com texto selecionável (não escaneados).
 *
 * @package Tainacan_ChatGPT
 * @since 3.1.0
 */

namespace Tainacan\ChatGPT\PdfParser;

class PdfParser {

    private string $content;
    private array $objects = [];
    private array $pages = [];

    /**
     * Parseia um arquivo PDF
     */
    public function parseFile(string $filePath): self {
        if (!file_exists($filePath)) {
            throw new \Exception("Arquivo não encontrado: {$filePath}");
        }

        $this->content = file_get_contents($filePath);
        $this->parseObjects();

        return $this;
    }

    /**
     * Parseia conteúdo PDF direto
     */
    public function parseContent(string $content): self {
        $this->content = $content;
        $this->parseObjects();

        return $this;
    }

    /**
     * Extrai todo o texto do PDF
     */
    public function getText(): string {
        $text = '';

        // Método 1: Extrai de streams de conteúdo
        $text .= $this->extractFromStreams();

        // Método 2: Extrai texto entre parênteses (PDF text objects)
        if (empty(trim($text))) {
            $text .= $this->extractTextObjects();
        }

        // Método 3: Extrai strings hexadecimais
        if (empty(trim($text))) {
            $text .= $this->extractHexStrings();
        }

        // Limpa o texto
        $text = $this->cleanText($text);

        return $text;
    }

    /**
     * Retorna número de páginas (estimativa)
     */
    public function getPageCount(): int {
        preg_match_all('/\/Type\s*\/Page[^s]/i', $this->content, $matches);
        return count($matches[0]);
    }

    /**
     * Parseia objetos do PDF
     */
    private function parseObjects(): void {
        // Encontra todos os objetos
        preg_match_all('/(\d+)\s+(\d+)\s+obj(.*?)endobj/s', $this->content, $matches, PREG_SET_ORDER);

        foreach ($matches as $match) {
            $objNum = $match[1];
            $objGen = $match[2];
            $objContent = $match[3];

            $this->objects["{$objNum}_{$objGen}"] = $objContent;
        }
    }

    /**
     * Extrai texto de streams comprimidos
     */
    private function extractFromStreams(): string {
        $text = '';

        // Encontra todos os streams
        preg_match_all('/stream\s*(.*?)\s*endstream/s', $this->content, $streams);

        foreach ($streams[1] as $stream) {
            $decoded = $this->decodeStream($stream);

            if (!empty($decoded)) {
                // Extrai texto do conteúdo decodificado
                $extracted = $this->extractTextFromContent($decoded);
                if (!empty($extracted)) {
                    $text .= $extracted . "\n";
                }
            }
        }

        return $text;
    }

    /**
     * Decodifica stream (FlateDecode/deflate)
     */
    private function decodeStream(string $stream): string {
        // Remove espaços em branco iniciais/finais
        $stream = trim($stream);

        // Tenta decodificar com zlib (FlateDecode)
        $decoded = @gzuncompress($stream);
        if ($decoded !== false) {
            return $decoded;
        }

        // Tenta inflate (sem header zlib)
        $decoded = @gzinflate($stream);
        if ($decoded !== false) {
            return $decoded;
        }

        // Tenta raw deflate
        $decoded = @gzinflate(substr($stream, 2));
        if ($decoded !== false) {
            return $decoded;
        }

        // Se não conseguir decodificar, retorna o stream original
        // (pode ser um stream não comprimido)
        if (strpos($stream, 'BT') !== false || strpos($stream, 'Tj') !== false) {
            return $stream;
        }

        return '';
    }

    /**
     * Extrai texto de conteúdo de página PDF
     */
    private function extractTextFromContent(string $content): string {
        $text = '';

        // Encontra blocos de texto (entre BT e ET)
        preg_match_all('/BT(.*?)ET/s', $content, $textBlocks);

        foreach ($textBlocks[1] as $block) {
            // Extrai strings entre parênteses (Tj, TJ, ', ")
            preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)?\)\s*Tj/s', $block, $tjMatches);
            foreach ($tjMatches[1] as $match) {
                $text .= $this->decodeTextString($match) . ' ';
            }

            // Extrai arrays de texto (TJ)
            preg_match_all('/\[(.*?)\]\s*TJ/s', $block, $tjArrayMatches);
            foreach ($tjArrayMatches[1] as $arrayContent) {
                preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)?\)/', $arrayContent, $arrayStrings);
                foreach ($arrayStrings[1] as $str) {
                    $text .= $this->decodeTextString($str);
                }
                $text .= ' ';
            }

            // Operadores ' e "
            preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)?\)\s*[\'"]/s', $block, $quoteMatches);
            foreach ($quoteMatches[1] as $match) {
                $text .= $this->decodeTextString($match) . ' ';
            }
        }

        return $text;
    }

    /**
     * Extrai objetos de texto diretamente
     */
    private function extractTextObjects(): string {
        $text = '';

        // Busca padrões de texto em todo o conteúdo
        foreach ($this->objects as $obj) {
            // Texto literal entre parênteses
            preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)\)/', $obj, $matches);
            foreach ($matches[1] as $match) {
                $decoded = $this->decodeTextString($match);
                // Filtra texto válido (pelo menos 3 caracteres alfanuméricos)
                if (preg_match('/[a-zA-Z0-9]{3,}/', $decoded)) {
                    $text .= $decoded . ' ';
                }
            }
        }

        return $text;
    }

    /**
     * Extrai strings hexadecimais
     */
    private function extractHexStrings(): string {
        $text = '';

        // Busca strings hex <...>
        preg_match_all('/<([0-9A-Fa-f\s]+)>/', $this->content, $matches);

        foreach ($matches[1] as $hex) {
            $hex = preg_replace('/\s/', '', $hex);
            if (strlen($hex) >= 4) {
                $decoded = $this->hexToString($hex);
                if (!empty($decoded) && preg_match('/[a-zA-Z0-9]{2,}/', $decoded)) {
                    $text .= $decoded . ' ';
                }
            }
        }

        return $text;
    }

    /**
     * Decodifica string de texto PDF
     */
    private function decodeTextString(string $str): string {
        // Decodifica escapes
        $str = str_replace('\\n', "\n", $str);
        $str = str_replace('\\r', "\r", $str);
        $str = str_replace('\\t', "\t", $str);
        $str = str_replace('\\(', '(', $str);
        $str = str_replace('\\)', ')', $str);
        $str = str_replace('\\\\', '\\', $str);

        // Decodifica escapes octais
        $str = preg_replace_callback('/\\\\([0-7]{1,3})/', function($m) {
            return chr(octdec($m[1]));
        }, $str);

        return $str;
    }

    /**
     * Converte hex para string
     */
    private function hexToString(string $hex): string {
        $str = '';
        $len = strlen($hex);

        for ($i = 0; $i < $len; $i += 2) {
            if ($i + 1 < $len) {
                $byte = hexdec(substr($hex, $i, 2));
                if ($byte >= 32 && $byte <= 126) {
                    $str .= chr($byte);
                } elseif ($byte === 10 || $byte === 13) {
                    $str .= ' ';
                }
            }
        }

        return $str;
    }

    /**
     * Limpa texto extraído
     */
    private function cleanText(string $text): string {
        // Converte para UTF-8 se necessário
        if (!mb_check_encoding($text, 'UTF-8')) {
            // Tenta detectar encoding e converter
            $detected = mb_detect_encoding($text, ['UTF-8', 'ISO-8859-1', 'Windows-1252', 'ASCII'], true);
            if ($detected) {
                $text = mb_convert_encoding($text, 'UTF-8', $detected);
            } else {
                // Fallback: força conversão de ISO-8859-1
                $text = mb_convert_encoding($text, 'UTF-8', 'ISO-8859-1');
            }
        }

        // Remove caracteres de controle (mantém tab e newline)
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text);

        // Remove bytes inválidos de UTF-8
        $text = mb_convert_encoding($text, 'UTF-8', 'UTF-8');

        // Normaliza quebras de linha
        $text = str_replace(["\r\n", "\r"], "\n", $text);

        // Remove múltiplos espaços
        $text = preg_replace('/[ \t]+/', ' ', $text);

        // Remove linhas vazias múltiplas
        $text = preg_replace('/\n{3,}/', "\n\n", $text);

        // Remove espaços antes de pontuação
        $text = preg_replace('/\s+([.,;:!?])/', '$1', $text);

        // Trim
        $text = trim($text);

        return $text;
    }
}
