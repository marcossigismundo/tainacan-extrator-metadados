<?php
namespace Tainacan\ChatGPT;

/**
 * Integração com formulário de itens do Tainacan
 *
 * Adiciona botão de análise IA no formulário de edição de itens,
 * permitindo extração automática de metadados.
 */
class ItemFormHook {

    public function __construct() {
        add_action('tainacan-register-admin-hooks', [$this, 'register_hook']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);

        // AJAX endpoints
        add_action('wp_ajax_tainacan_chatgpt_analyze', [$this, 'ajax_analyze']);
        add_action('wp_ajax_tainacan_chatgpt_get_item_document', [$this, 'ajax_get_item_document']);
        add_action('wp_ajax_tainacan_chatgpt_clear_item_cache', [$this, 'ajax_clear_item_cache']);
        add_action('wp_ajax_tainacan_chatgpt_apply_metadata', [$this, 'ajax_apply_metadata']);
    }

    /**
     * Registra hook no formulário de item
     */
    public function register_hook(): void {
        if (function_exists('tainacan_register_admin_hook')) {
            tainacan_register_admin_hook(
                'item',
                [$this, 'render_form'],
                'begin-right'
            );
        }
    }

    /**
     * Renderiza o formulário com botão de análise
     */
    public function render_form(): string {
        if (!function_exists('tainacan_get_api_postdata')) {
            return '';
        }

        $options = \Tainacan_ChatGPT::get_options();
        $is_configured = !empty($options['api_key']);

        ob_start();
        ?>
        <div class="field tainacan-chatgpt-section" id="tainacan-chatgpt-widget">
            <div class="tainacan-chatgpt-header">
                <div class="tainacan-chatgpt-header-left">
                    <svg class="tainacan-chatgpt-icon" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M22.282 9.821a5.985 5.985 0 0 0-.516-4.91 6.046 6.046 0 0 0-6.51-2.9A6.065 6.065 0 0 0 4.981 4.18a5.985 5.985 0 0 0-3.998 2.9 6.046 6.046 0 0 0 .743 7.097 5.98 5.98 0 0 0 .51 4.911 6.051 6.051 0 0 0 6.515 2.9A5.985 5.985 0 0 0 13.26 24a6.056 6.056 0 0 0 5.772-4.206 5.99 5.99 0 0 0 3.997-2.9 6.056 6.056 0 0 0-.747-7.073zM13.26 22.43a4.476 4.476 0 0 1-2.876-1.04l.141-.081 4.779-2.758a.795.795 0 0 0 .392-.681v-6.737l2.02 1.168a.071.071 0 0 1 .038.052v5.583a4.504 4.504 0 0 1-4.494 4.494zM3.6 18.304a4.47 4.47 0 0 1-.535-3.014l.142.085 4.783 2.759a.771.771 0 0 0 .78 0l5.843-3.369v2.332a.08.08 0 0 1-.033.062L9.74 19.95a4.5 4.5 0 0 1-6.14-1.646zM2.34 7.896a4.485 4.485 0 0 1 2.366-1.973V11.6a.766.766 0 0 0 .388.676l5.815 3.355-2.02 1.168a.076.076 0 0 1-.071 0l-4.83-2.786A4.504 4.504 0 0 1 2.34 7.872zm16.597 3.855l-5.833-3.387L15.119 7.2a.076.076 0 0 1 .071 0l4.83 2.791a4.494 4.494 0 0 1-.676 8.105v-5.678a.79.79 0 0 0-.407-.667zm2.01-3.023l-.141-.085-4.774-2.782a.776.776 0 0 0-.785 0L9.409 9.23V6.897a.066.066 0 0 1 .028-.061l4.83-2.787a4.5 4.5 0 0 1 6.68 4.66zm-12.64 4.135l-2.02-1.164a.08.08 0 0 1-.038-.057V6.075a4.5 4.5 0 0 1 7.375-3.453l-.142.08L8.704 5.46a.795.795 0 0 0-.393.681zm1.097-2.365l2.602-1.5 2.607 1.5v2.999l-2.597 1.5-2.607-1.5z"/>
                    </svg>
                    <h4><?php _e('Extrator de Metadados IA', 'tainacan-chatgpt'); ?></h4>
                </div>
                <?php if ($is_configured): ?>
                    <span class="tainacan-chatgpt-status-badge success">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <?php _e('Configurado', 'tainacan-chatgpt'); ?>
                    </span>
                <?php else: ?>
                    <span class="tainacan-chatgpt-status-badge warning">
                        <span class="dashicons dashicons-warning"></span>
                        <?php _e('Não configurado', 'tainacan-chatgpt'); ?>
                    </span>
                <?php endif; ?>
            </div>

            <hr class="tainacan-chatgpt-divider">

            <?php if (!$is_configured): ?>
                <div class="tainacan-chatgpt-notice warning">
                    <p>
                        <?php printf(
                            __('Configure sua chave API em %sTainacan > ChatGPT%s para usar a extração automática.', 'tainacan-chatgpt'),
                            '<a href="' . admin_url('admin.php?page=tainacan_chatgpt') . '">',
                            '</a>'
                        ); ?>
                    </p>
                </div>
            <?php else: ?>
                <p class="tainacan-chatgpt-description">
                    <?php _e('Analise o documento deste item com inteligência artificial para extrair metadados automaticamente.', 'tainacan-chatgpt'); ?>
                </p>

                <!-- Info do documento detectado -->
                <div class="tainacan-chatgpt-document-info" id="tainacan-chatgpt-document-info" style="display: none;">
                    <span class="tainacan-chatgpt-document-type" id="tainacan-chatgpt-doc-type"></span>
                    <span class="tainacan-chatgpt-document-name" id="tainacan-chatgpt-doc-name"></span>
                </div>

                <!-- Botões de ação -->
                <div class="tainacan-chatgpt-actions">
                    <button type="button" class="button button-primary tainacan-chatgpt-analyze-btn" id="tainacan-chatgpt-analyze">
                        <span class="tainacan-chatgpt-btn-icon">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                        </span>
                        <span class="tainacan-chatgpt-btn-text"><?php _e('Analisar Documento', 'tainacan-chatgpt'); ?></span>
                    </button>

                    <button type="button" class="button tainacan-chatgpt-refresh-btn" id="tainacan-chatgpt-refresh" title="<?php esc_attr_e('Forçar nova análise (ignorar cache)', 'tainacan-chatgpt'); ?>">
                        <span class="dashicons dashicons-update"></span>
                    </button>
                </div>

                <!-- Status / Loading -->
                <div class="tainacan-chatgpt-status" id="tainacan-chatgpt-status" style="display: none;">
                    <div class="tainacan-chatgpt-loading">
                        <div class="tainacan-chatgpt-spinner"></div>
                        <div class="tainacan-chatgpt-loading-text">
                            <span class="tainacan-chatgpt-loading-title"><?php _e('Analisando documento...', 'tainacan-chatgpt'); ?></span>
                            <span class="tainacan-chatgpt-loading-subtitle"><?php _e('Isso pode levar alguns segundos', 'tainacan-chatgpt'); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Resultados -->
                <div class="tainacan-chatgpt-results" id="tainacan-chatgpt-results" style="display: none;">
                    <!-- Tabs -->
                    <div class="tainacan-chatgpt-tabs">
                        <button type="button" class="tainacan-chatgpt-tab active" data-tab="ai">
                            <span class="dashicons dashicons-welcome-learn-more"></span>
                            <?php _e('Metadados IA', 'tainacan-chatgpt'); ?>
                        </button>
                        <button type="button" class="tainacan-chatgpt-tab" data-tab="exif" id="tainacan-chatgpt-tab-exif" style="display: none;">
                            <span class="dashicons dashicons-camera"></span>
                            <?php _e('Dados EXIF', 'tainacan-chatgpt'); ?>
                        </button>
                    </div>

                    <!-- Conteúdo AI -->
                    <div class="tainacan-chatgpt-tab-content active" id="tainacan-chatgpt-content-ai">
                        <div class="tainacan-chatgpt-results-header">
                            <h5><?php _e('Metadados Extraídos', 'tainacan-chatgpt'); ?></h5>
                            <div class="tainacan-chatgpt-results-actions">
                                <span class="tainacan-chatgpt-cache-badge" id="tainacan-chatgpt-cache-badge" style="display: none;">
                                    <?php _e('Cache', 'tainacan-chatgpt'); ?>
                                </span>
                                <button type="button" class="button button-small" id="tainacan-chatgpt-copy-all" title="<?php esc_attr_e('Copiar todos', 'tainacan-chatgpt'); ?>">
                                    <span class="dashicons dashicons-clipboard"></span>
                                </button>
                            </div>
                        </div>
                        <div class="tainacan-chatgpt-results-content" id="tainacan-chatgpt-results-content"></div>
                    </div>

                    <!-- Conteúdo EXIF -->
                    <div class="tainacan-chatgpt-tab-content" id="tainacan-chatgpt-content-exif">
                        <div class="tainacan-chatgpt-results-header">
                            <h5><?php _e('Dados Técnicos da Imagem', 'tainacan-chatgpt'); ?></h5>
                        </div>
                        <div class="tainacan-chatgpt-exif-content" id="tainacan-chatgpt-exif-content"></div>
                    </div>

                    <!-- Info da análise -->
                    <div class="tainacan-chatgpt-analysis-info" id="tainacan-chatgpt-analysis-info">
                        <span class="tainacan-chatgpt-model" id="tainacan-chatgpt-model"></span>
                        <span class="tainacan-chatgpt-tokens" id="tainacan-chatgpt-tokens"></span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Carrega assets
     */
    public function enqueue_assets(string $hook): void {
        // Verifica se está em páginas do Tainacan
        if (strpos($hook, 'tainacan') === false && strpos($hook, 'post.php') === false) {
            return;
        }

        wp_enqueue_style(
            'tainacan-chatgpt-item',
            TAINACAN_CHATGPT_PLUGIN_URL . 'assets/css/item-form.css',
            [],
            TAINACAN_CHATGPT_VERSION
        );

        wp_enqueue_script(
            'tainacan-chatgpt-item',
            TAINACAN_CHATGPT_PLUGIN_URL . 'assets/js/item-form.js',
            ['jquery'],
            TAINACAN_CHATGPT_VERSION,
            true
        );

        $options = \Tainacan_ChatGPT::get_options();

        wp_localize_script('tainacan-chatgpt-item', 'TainacanChatGPT', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'restUrl' => rest_url('tainacan-chatgpt/v1/'),
            'nonce' => wp_create_nonce('tainacan_chatgpt_nonce'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'debug' => defined('WP_DEBUG') && WP_DEBUG,
            'autoMapMetadata' => !empty($options['auto_map_metadata']),
            'texts' => [
                'analyzing' => __('Analisando...', 'tainacan-chatgpt'),
                'analyzeBtn' => __('Analisar Documento', 'tainacan-chatgpt'),
                'error' => __('Erro ao analisar. Tente novamente.', 'tainacan-chatgpt'),
                'noDocument' => __('Nenhum documento encontrado neste item. Adicione uma imagem ou arquivo primeiro.', 'tainacan-chatgpt'),
                'copy' => __('Copiar', 'tainacan-chatgpt'),
                'copied' => __('Copiado!', 'tainacan-chatgpt'),
                'copyAll' => __('Copiar Todos', 'tainacan-chatgpt'),
                'allCopied' => __('Todos copiados!', 'tainacan-chatgpt'),
                'apply' => __('Aplicar', 'tainacan-chatgpt'),
                'applied' => __('Aplicado!', 'tainacan-chatgpt'),
                'cacheCleared' => __('Cache limpo!', 'tainacan-chatgpt'),
                'clearing' => __('Limpando...', 'tainacan-chatgpt'),
                'tokens' => __('tokens', 'tainacan-chatgpt'),
                'model' => __('Modelo', 'tainacan-chatgpt'),
                'image' => __('Imagem', 'tainacan-chatgpt'),
                'pdf' => __('PDF', 'tainacan-chatgpt'),
                'text' => __('Texto', 'tainacan-chatgpt'),
                'detecting' => __('Detectando documento...', 'tainacan-chatgpt'),
            ]
        ]);
    }

    /**
     * AJAX: Analisa documento do item
     */
    public function ajax_analyze(): void {
        try {
            check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
            }

            $item_id = absint($_POST['item_id'] ?? 0);
            $attachment_id = absint($_POST['attachment_id'] ?? 0);
            $collection_id = absint($_POST['collection_id'] ?? 0);
            $force_refresh = filter_var($_POST['force_refresh'] ?? false, FILTER_VALIDATE_BOOLEAN);

            if (empty($item_id) && empty($attachment_id)) {
                wp_send_json_error(__('ID do item ou anexo não fornecido.', 'tainacan-chatgpt'));
            }

            // Obtém documento do item se não tiver attachment_id
            if (empty($attachment_id) && !empty($item_id)) {
                $document_data = $this->get_item_document($item_id);
                if (!$document_data) {
                    wp_send_json_error(__('Nenhum documento encontrado neste item.', 'tainacan-chatgpt'));
                }
                $attachment_id = $document_data['id'];
            }

            // Obtém collection_id do item se não fornecido
            if (empty($collection_id) && !empty($item_id)) {
                $collection_id = $this->get_item_collection_id($item_id);
            }

            // Verifica cache
            $cache_key = 'tainacan_chatgpt_' . $attachment_id;
            if (!$force_refresh) {
                $cached = get_transient($cache_key);
                if ($cached !== false) {
                    wp_send_json_success([
                        'result' => $cached,
                        'from_cache' => true,
                    ]);
                }
            }

            // Analisa documento
            $analyzer = new DocumentAnalyzer();
            $analyzer->set_context($collection_id, $item_id);
            $result = $analyzer->analyze($attachment_id);

            if (is_wp_error($result)) {
                wp_send_json_error($result->get_error_message());
            }

            // Salva no cache
            $options = \Tainacan_ChatGPT::get_options();
            $cache_duration = $options['cache_duration'] ?? 3600;
            if ($cache_duration > 0) {
                set_transient($cache_key, $result, $cache_duration);
            }

            wp_send_json_success([
                'result' => $result,
                'from_cache' => false,
            ]);
        } catch (\Throwable $e) {
            // Captura qualquer erro/exceção e retorna mensagem amigável
            $error_message = $e->getMessage();
            $error_file = basename($e->getFile());
            $error_line = $e->getLine();

            // Log detalhado para debug
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[TainacanChatGPT] Error in ajax_analyze: {$error_message} in {$error_file}:{$error_line}");
                error_log("[TainacanChatGPT] Stack trace: " . $e->getTraceAsString());
            }

            wp_send_json_error(
                sprintf(__('Erro ao analisar documento: %s', 'tainacan-chatgpt'), $error_message)
            );
        }
    }

    /**
     * AJAX: Obtém documento do item
     */
    public function ajax_get_item_document(): void {
        check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');

        $item_id = absint($_POST['item_id'] ?? 0);

        if (empty($item_id)) {
            wp_send_json_error(__('ID do item não fornecido.', 'tainacan-chatgpt'));
        }

        $document = $this->get_item_document($item_id);

        if ($document) {
            wp_send_json_success($document);
        } else {
            wp_send_json_error(__('Documento não encontrado.', 'tainacan-chatgpt'));
        }
    }

    /**
     * AJAX: Limpa cache do item
     */
    public function ajax_clear_item_cache(): void {
        check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');

        $attachment_id = absint($_POST['attachment_id'] ?? 0);

        if (empty($attachment_id)) {
            wp_send_json_error(__('ID do anexo não fornecido.', 'tainacan-chatgpt'));
        }

        delete_transient('tainacan_chatgpt_' . $attachment_id);

        wp_send_json_success(__('Cache limpo!', 'tainacan-chatgpt'));
    }

    /**
     * AJAX: Aplica metadados ao item
     */
    public function ajax_apply_metadata(): void {
        check_ajax_referer('tainacan_chatgpt_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Permissão negada.', 'tainacan-chatgpt'));
        }

        $item_id = absint($_POST['item_id'] ?? 0);
        $metadata_id = absint($_POST['metadata_id'] ?? 0);
        $value = sanitize_text_field($_POST['value'] ?? '');

        if (empty($item_id) || empty($metadata_id)) {
            wp_send_json_error(__('Dados insuficientes.', 'tainacan-chatgpt'));
        }

        if (!class_exists('\Tainacan\Repositories\Item_Metadata')) {
            wp_send_json_error(__('Tainacan não encontrado.', 'tainacan-chatgpt'));
        }

        try {
            $items_repo = \Tainacan\Repositories\Items::get_instance();
            $metadata_repo = \Tainacan\Repositories\Metadata::get_instance();
            $item_metadata_repo = \Tainacan\Repositories\Item_Metadata::get_instance();

            $item = $items_repo->fetch($item_id);
            $metadata = $metadata_repo->fetch($metadata_id);

            if (!$item || !$metadata) {
                wp_send_json_error(__('Item ou metadado não encontrado.', 'tainacan-chatgpt'));
            }

            $item_metadata = new \Tainacan\Entities\Item_Metadata_Entity($item, $metadata);
            $item_metadata->set_value($value);

            if ($item_metadata->validate()) {
                $item_metadata_repo->insert($item_metadata);
                wp_send_json_success(__('Metadado aplicado com sucesso!', 'tainacan-chatgpt'));
            } else {
                wp_send_json_error(__('Valor inválido para este metadado.', 'tainacan-chatgpt'));
            }
        } catch (\Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Obtém documento de um item Tainacan
     */
    private function get_item_document(int $item_id): ?array {
        // Método 1: Via API do Tainacan
        if (class_exists('\Tainacan\Repositories\Items')) {
            $items_repo = \Tainacan\Repositories\Items::get_instance();
            $item = $items_repo->fetch($item_id);

            if ($item) {
                // Documento principal
                $document_type = $item->get_document_type();
                $document = $item->get_document();

                if ($document_type === 'attachment' && !empty($document) && is_numeric($document)) {
                    return $this->get_attachment_info((int) $document);
                }

                // URL do documento
                if ($document_type === 'url' && !empty($document)) {
                    // Tenta buscar attachment por URL
                    $attachment_id = attachment_url_to_postid($document);
                    if ($attachment_id) {
                        return $this->get_attachment_info($attachment_id);
                    }
                }
            }
        }

        // Método 2: Via post_meta
        $document_id = get_post_meta($item_id, 'document', true);
        if (!empty($document_id) && is_numeric($document_id)) {
            return $this->get_attachment_info((int) $document_id);
        }

        // Método 3: Via thumbnail
        $thumbnail_id = get_post_thumbnail_id($item_id);
        if ($thumbnail_id) {
            return $this->get_attachment_info((int) $thumbnail_id);
        }

        // Método 4: Primeiro attachment do post
        $attachments = get_posts([
            'post_type' => 'attachment',
            'posts_per_page' => 1,
            'post_parent' => $item_id,
            'post_status' => 'inherit',
            'orderby' => 'menu_order',
            'order' => 'ASC',
        ]);

        if (!empty($attachments)) {
            return $this->get_attachment_info($attachments[0]->ID);
        }

        return null;
    }

    /**
     * Obtém informações de um attachment
     */
    private function get_attachment_info(int $attachment_id): array {
        $mime_type = get_post_mime_type($attachment_id);
        $title = get_the_title($attachment_id);
        $url = wp_get_attachment_url($attachment_id);

        // Determina tipo
        $type = 'unknown';
        if (strpos($mime_type, 'image/') === 0) {
            $type = 'image';
        } elseif ($mime_type === 'application/pdf') {
            $type = 'pdf';
        } elseif (strpos($mime_type, 'text/') === 0) {
            $type = 'text';
        }

        // Thumbnail para imagens
        $thumbnail = null;
        if ($type === 'image') {
            $thumb = wp_get_attachment_image_src($attachment_id, 'thumbnail');
            $thumbnail = $thumb ? $thumb[0] : null;
        }

        return [
            'id' => $attachment_id,
            'title' => $title,
            'url' => $url,
            'mime_type' => $mime_type,
            'type' => $type,
            'thumbnail' => $thumbnail,
        ];
    }

    /**
     * Obtém ID da coleção de um item
     */
    private function get_item_collection_id(int $item_id): ?int {
        if (!class_exists('\Tainacan\Repositories\Items')) {
            return null;
        }

        $items_repo = \Tainacan\Repositories\Items::get_instance();
        $item = $items_repo->fetch($item_id);

        if ($item && method_exists($item, 'get_collection_id')) {
            return $item->get_collection_id();
        }

        return null;
    }
}
